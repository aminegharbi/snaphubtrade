--
-- PostgreSQL database dump
--

\restrict Kk8yphEyhgmKn5chdIRKGBttTXOmSWCVbTKIKnADYbv9zxnPhxZQAofttRBMVqt

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AffiliatePayment; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public."AffiliatePayment" (
    id text NOT NULL,
    broker_id text NOT NULL,
    amount_aed numeric(12,2) DEFAULT 0 NOT NULL,
    deals_count integer DEFAULT 0 NOT NULL,
    period_start timestamp(3) without time zone NOT NULL,
    period_end timestamp(3) without time zone NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    payment_method text,
    payment_ref text,
    notes text,
    paid_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."AffiliatePayment" OWNER TO dubaiauto;

--
-- Name: CrmActivity; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public."CrmActivity" (
    id text NOT NULL,
    contact_id text NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    body text,
    direction text,
    duration_min integer,
    outcome text,
    scheduled_at timestamp(3) without time zone,
    completed boolean DEFAULT false NOT NULL,
    completed_at timestamp(3) without time zone,
    created_by text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."CrmActivity" OWNER TO dubaiauto;

--
-- Name: CrmContact; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public."CrmContact" (
    id text NOT NULL,
    type text DEFAULT 'lead'::text NOT NULL,
    full_name text NOT NULL,
    email text,
    phone text,
    whatsapp text,
    company text,
    country text,
    city text,
    source text,
    owner text,
    score integer DEFAULT 0 NOT NULL,
    tags text[],
    status text DEFAULT 'new'::text NOT NULL,
    last_activity_at timestamp(3) without time zone,
    notes text,
    ref_dealer_id text,
    ref_broker_id text,
    ref_user_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CrmContact" OWNER TO dubaiauto;

--
-- Name: CrmDeal; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public."CrmDeal" (
    id text NOT NULL,
    contact_id text NOT NULL,
    title text NOT NULL,
    value_aed numeric(12,2) DEFAULT 0 NOT NULL,
    stage text DEFAULT 'lead'::text NOT NULL,
    probability_pct integer DEFAULT 10 NOT NULL,
    expected_close timestamp(3) without time zone,
    owner text,
    source text,
    notes text,
    lost_reason text,
    won_at timestamp(3) without time zone,
    lost_at timestamp(3) without time zone,
    plan_interest text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CrmDeal" OWNER TO dubaiauto;

--
-- Name: EmailCampaign; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public."EmailCampaign" (
    id text NOT NULL,
    name text NOT NULL,
    subject_a text NOT NULL,
    subject_b text,
    preview_text text,
    from_name text DEFAULT 'DubaiAuto'::text NOT NULL,
    from_email text DEFAULT 'noreply@dubaiauto.ae'::text NOT NULL,
    reply_to text,
    segment text DEFAULT 'all_dealers'::text NOT NULL,
    blocks jsonb DEFAULT '[]'::jsonb NOT NULL,
    html_body text,
    status text DEFAULT 'draft'::text NOT NULL,
    type text DEFAULT 'one_off'::text NOT NULL,
    ab_test boolean DEFAULT false NOT NULL,
    ab_split_pct integer DEFAULT 50 NOT NULL,
    ab_winner text,
    scheduled_at timestamp(3) without time zone,
    sent_at timestamp(3) without time zone,
    total_recipients integer DEFAULT 0 NOT NULL,
    tags text[],
    created_by text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."EmailCampaign" OWNER TO dubaiauto;

--
-- Name: EmailLink; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public."EmailLink" (
    id text NOT NULL,
    campaign_id text NOT NULL,
    tracking_id text NOT NULL,
    original_url text NOT NULL,
    link_id text NOT NULL,
    clicks integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."EmailLink" OWNER TO dubaiauto;

--
-- Name: EmailSend; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public."EmailSend" (
    id text NOT NULL,
    campaign_id text NOT NULL,
    recipient_email text NOT NULL,
    recipient_name text,
    subject text NOT NULL,
    variant text DEFAULT 'a'::text NOT NULL,
    status text DEFAULT 'queued'::text NOT NULL,
    provider_id text,
    tracking_id text NOT NULL,
    opened boolean DEFAULT false NOT NULL,
    opened_at timestamp(3) without time zone,
    open_count integer DEFAULT 0 NOT NULL,
    clicked boolean DEFAULT false NOT NULL,
    clicked_at timestamp(3) without time zone,
    click_count integer DEFAULT 0 NOT NULL,
    bounced boolean DEFAULT false NOT NULL,
    bounce_reason text,
    unsubscribed boolean DEFAULT false NOT NULL,
    sent_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."EmailSend" OWNER TO dubaiauto;

--
-- Name: EmailTemplate; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public."EmailTemplate" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    category text DEFAULT 'general'::text NOT NULL,
    thumbnail text,
    blocks jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    usage_count integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."EmailTemplate" OWNER TO dubaiauto;

--
-- Name: EmailUnsubscribe; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public."EmailUnsubscribe" (
    id text NOT NULL,
    email text NOT NULL,
    reason text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."EmailUnsubscribe" OWNER TO dubaiauto;

--
-- Name: ExecMeeting; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public."ExecMeeting" (
    id text NOT NULL,
    title text NOT NULL,
    attendees text[],
    date timestamp(3) without time zone NOT NULL,
    duration_min integer DEFAULT 30 NOT NULL,
    type text DEFAULT 'internal'::text NOT NULL,
    notes text,
    link text,
    status text DEFAULT 'scheduled'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ExecMeeting" OWNER TO dubaiauto;

--
-- Name: ExecTask; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public."ExecTask" (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    priority text DEFAULT 'medium'::text NOT NULL,
    status text DEFAULT 'todo'::text NOT NULL,
    due_date timestamp(3) without time zone,
    assignee text,
    category text DEFAULT 'general'::text NOT NULL,
    created_by text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ExecTask" OWNER TO dubaiauto;

--
-- Name: KpiSnapshot; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public."KpiSnapshot" (
    id text NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    mrr_aed numeric(14,2) DEFAULT 0 NOT NULL,
    arr_aed numeric(14,2) DEFAULT 0 NOT NULL,
    active_dealers integer DEFAULT 0 NOT NULL,
    new_dealers_month integer DEFAULT 0 NOT NULL,
    total_vehicles integer DEFAULT 0 NOT NULL,
    deals_month integer DEFAULT 0 NOT NULL,
    revenue_month_aed numeric(14,2) DEFAULT 0 NOT NULL,
    health_score integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."KpiSnapshot" OWNER TO dubaiauto;

--
-- Name: MarketingSpend; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public."MarketingSpend" (
    id text NOT NULL,
    month timestamp(3) without time zone NOT NULL,
    channel text NOT NULL,
    amount_aed numeric(12,2) DEFAULT 0 NOT NULL,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MarketingSpend" OWNER TO dubaiauto;

--
-- Name: PushCampaign; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public."PushCampaign" (
    id text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    image_url text,
    action_url text,
    action_label text,
    type text DEFAULT 'announcement'::text NOT NULL,
    audience text DEFAULT 'all'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    scheduled_at timestamp(3) without time zone,
    sent_at timestamp(3) without time zone,
    total_sent integer DEFAULT 0 NOT NULL,
    total_clicked integer DEFAULT 0 NOT NULL,
    created_by text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PushCampaign" OWNER TO dubaiauto;

--
-- Name: PushSend; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public."PushSend" (
    id text NOT NULL,
    campaign_id text NOT NULL,
    recipient_type text NOT NULL,
    recipient_id text NOT NULL,
    notification_id text,
    clicked boolean DEFAULT false NOT NULL,
    clicked_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PushSend" OWNER TO dubaiauto;

--
-- Name: active_sessions; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.active_sessions (
    id text NOT NULL,
    session_token text NOT NULL,
    profile_type text NOT NULL,
    profile_id text,
    display_name text NOT NULL,
    avatar_label text,
    email text,
    current_page text,
    last_seen_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.active_sessions OWNER TO dubaiauto;

--
-- Name: ai_credits; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.ai_credits (
    id text NOT NULL,
    dealer_id text NOT NULL,
    credits_total integer DEFAULT 0 NOT NULL,
    credits_used integer DEFAULT 0 NOT NULL,
    credits_reset_at timestamp(3) without time zone,
    reset_period text DEFAULT 'monthly'::character varying NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.ai_credits OWNER TO dubaiauto;

--
-- Name: alert_notifications; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.alert_notifications (
    id text NOT NULL,
    alert_id text NOT NULL,
    vehicle_id text,
    title text NOT NULL,
    message text,
    channel text DEFAULT 'email'::character varying NOT NULL,
    status text DEFAULT 'pending'::character varying NOT NULL,
    sent_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.alert_notifications OWNER TO dubaiauto;

--
-- Name: alert_subscriptions; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.alert_subscriptions (
    id text NOT NULL,
    user_id text,
    email text NOT NULL,
    phone text,
    alert_type text NOT NULL,
    filters jsonb DEFAULT '{}'::jsonb NOT NULL,
    channel text[] DEFAULT ARRAY['email'::text],
    is_active boolean DEFAULT true NOT NULL,
    last_triggered timestamp(3) without time zone,
    trigger_count integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.alert_subscriptions OWNER TO dubaiauto;

--
-- Name: broker_deals; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.broker_deals (
    id text NOT NULL,
    broker_id text NOT NULL,
    dealer_id text NOT NULL,
    vehicle_id text,
    buyer_name text,
    buyer_country text,
    deal_price_aed numeric(12,2) NOT NULL,
    commission_rate numeric(4,3) NOT NULL,
    commission_aed numeric(10,2) NOT NULL,
    status text DEFAULT 'pending'::character varying NOT NULL,
    paid_at timestamp(3) without time zone,
    notes text,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    currency text DEFAULT 'AED'::text NOT NULL
);


ALTER TABLE public.broker_deals OWNER TO dubaiauto;

--
-- Name: broker_referrals; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.broker_referrals (
    id text NOT NULL,
    broker_id text NOT NULL,
    referred_type text NOT NULL,
    referred_id text,
    referral_code text,
    reward_aed numeric(10,2) DEFAULT 0 NOT NULL,
    recurring_pct numeric(4,3) DEFAULT 0 NOT NULL,
    status text DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.broker_referrals OWNER TO dubaiauto;

--
-- Name: brokers; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.brokers (
    id text NOT NULL,
    user_id text,
    full_name text NOT NULL,
    email text NOT NULL,
    phone text,
    whatsapp text,
    company_name text,
    broker_type text DEFAULT 'independent'::character varying NOT NULL,
    affiliate_code text NOT NULL,
    tier text DEFAULT 'Starter'::character varying NOT NULL,
    commission_rate numeric(4,3) DEFAULT 0.015 NOT NULL,
    status text DEFAULT 'pending'::character varying NOT NULL,
    country text,
    city text,
    languages text[],
    specialties text[],
    referred_by text,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    country_id text
);


ALTER TABLE public.brokers OWNER TO dubaiauto;

--
-- Name: collaboration_messages; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.collaboration_messages (
    id text NOT NULL,
    vehicle_id text NOT NULL,
    from_dealer_id text,
    to_dealer_id text,
    msg_type text NOT NULL,
    content text,
    offer_price_aed numeric(12,2),
    status text DEFAULT 'pending'::character varying NOT NULL,
    expires_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.collaboration_messages OWNER TO dubaiauto;

--
-- Name: countries; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.countries (
    id text NOT NULL,
    code character varying(2) NOT NULL,
    name text NOT NULL,
    name_ar text,
    currency_code character varying(3) NOT NULL,
    phone_prefix text NOT NULL,
    vat_rate numeric(4,3) DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.countries OWNER TO dubaiauto;

--
-- Name: dealer_group_members; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.dealer_group_members (
    group_id text NOT NULL,
    dealer_id text NOT NULL,
    role text DEFAULT 'member'::character varying NOT NULL,
    joined_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dealer_group_members OWNER TO dubaiauto;

--
-- Name: dealer_groups; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.dealer_groups (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    created_by text,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dealer_groups OWNER TO dubaiauto;

--
-- Name: dealer_reports; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.dealer_reports (
    id text NOT NULL,
    dealer_id text NOT NULL,
    report_type text DEFAULT 'weekly'::character varying NOT NULL,
    week_start date NOT NULL,
    week_end date NOT NULL,
    status text DEFAULT 'generating'::character varying NOT NULL,
    total_units integer DEFAULT 0 NOT NULL,
    available_units integer DEFAULT 0 NOT NULL,
    sold_this_week integer DEFAULT 0 NOT NULL,
    total_views integer DEFAULT 0 NOT NULL,
    avg_price_aed numeric(12,2),
    market_avg_price numeric(12,2),
    price_position text,
    price_diff_pct numeric(5,2),
    ai_summary text,
    ai_recommendations jsonb DEFAULT '[]'::jsonb NOT NULL,
    ai_alerts jsonb DEFAULT '[]'::jsonb NOT NULL,
    market_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    competitor_data jsonb DEFAULT '[]'::jsonb NOT NULL,
    generated_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dealer_reports OWNER TO dubaiauto;

--
-- Name: dealer_reviews; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.dealer_reviews (
    id text NOT NULL,
    dealer_id text NOT NULL,
    user_id text,
    rating integer NOT NULL,
    comment text,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    CONSTRAINT dealer_reviews_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


ALTER TABLE public.dealer_reviews OWNER TO dubaiauto;

--
-- Name: dealer_subscriptions; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.dealer_subscriptions (
    id text NOT NULL,
    dealer_id text NOT NULL,
    plan_id text NOT NULL,
    status text DEFAULT 'active'::character varying NOT NULL,
    billing_cycle text DEFAULT 'monthly'::character varying NOT NULL,
    current_period_start timestamp(3) without time zone DEFAULT now() NOT NULL,
    current_period_end timestamp(3) without time zone,
    trial_start timestamp(3) without time zone,
    trial_end timestamp(3) without time zone,
    cancelled_at timestamp(3) without time zone,
    cancel_reason text,
    auto_renew boolean DEFAULT true NOT NULL,
    stripe_subscription_id text,
    stripe_customer_id text,
    coupon_id text,
    discount_pct integer DEFAULT 0 NOT NULL,
    grace_period_ends timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.dealer_subscriptions OWNER TO dubaiauto;

--
-- Name: dealers; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.dealers (
    id text NOT NULL,
    user_id text,
    company_name text NOT NULL,
    slug text NOT NULL,
    description text,
    logo_url text,
    cover_url text,
    phone text,
    whatsapp text,
    email text,
    website text,
    address text,
    free_zone_license text,
    languages text[],
    export_destinations text[],
    certifications text[],
    verified boolean DEFAULT false NOT NULL,
    verified_at timestamp(3) without time zone,
    rating numeric(3,2) DEFAULT 0 NOT NULL,
    review_count integer DEFAULT 0 NOT NULL,
    subscription_tier text DEFAULT 'free'::character varying NOT NULL,
    subscription_ends timestamp(3) without time zone,
    stripe_customer_id text,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    city text,
    country_id text,
    free_zone_id text
);


ALTER TABLE public.dealers OWNER TO dubaiauto;

--
-- Name: favorites; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.favorites (
    user_id text NOT NULL,
    vehicle_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.favorites OWNER TO dubaiauto;

--
-- Name: feature_flag_logs; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.feature_flag_logs (
    id text NOT NULL,
    flag_id text NOT NULL,
    flag_key text NOT NULL,
    action text NOT NULL,
    old_value jsonb,
    new_value jsonb,
    actor text,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.feature_flag_logs OWNER TO dubaiauto;

--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.feature_flags (
    id text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    description text,
    category text DEFAULT 'general'::character varying NOT NULL,
    icon text,
    is_enabled boolean DEFAULT false NOT NULL,
    rollout_pct integer DEFAULT 0 NOT NULL,
    target_plans text[],
    target_roles text[],
    target_zones text[],
    enabled_at timestamp(3) without time zone,
    scheduled_on timestamp(3) without time zone,
    scheduled_off timestamp(3) without time zone,
    tags text[],
    notes text,
    created_by text,
    updated_by text,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.feature_flags OWNER TO dubaiauto;

--
-- Name: free_zones; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.free_zones (
    id text NOT NULL,
    country_id text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    city text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.free_zones OWNER TO dubaiauto;

--
-- Name: invoice_line_items; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.invoice_line_items (
    id text NOT NULL,
    invoice_id text NOT NULL,
    description text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    total numeric(12,2) NOT NULL
);


ALTER TABLE public.invoice_line_items OWNER TO dubaiauto;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.invoices (
    id text NOT NULL,
    dealer_id text NOT NULL,
    broker_id text,
    vehicle_id text,
    quote_id text,
    buyer_name text NOT NULL,
    buyer_email text,
    buyer_phone text,
    buyer_country text,
    invoice_number text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    currency text DEFAULT 'AED'::text NOT NULL,
    subtotal_aed numeric(12,2) NOT NULL,
    discount_aed numeric(12,2) DEFAULT 0 NOT NULL,
    tax_aed numeric(12,2) DEFAULT 0 NOT NULL,
    total_aed numeric(12,2) NOT NULL,
    due_date timestamp(3) without time zone,
    paid_at timestamp(3) without time zone,
    sent_at timestamp(3) without time zone,
    notes text,
    terms text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.invoices OWNER TO dubaiauto;

--
-- Name: lead_activities; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.lead_activities (
    id text NOT NULL,
    lead_id text NOT NULL,
    type text NOT NULL,
    note text,
    created_by text,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lead_activities OWNER TO dubaiauto;

--
-- Name: leads; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.leads (
    id text NOT NULL,
    dealer_id text NOT NULL,
    vehicle_id text,
    buyer_name text,
    buyer_email text,
    buyer_phone text,
    buyer_whatsapp text,
    stage text DEFAULT 'new'::character varying NOT NULL,
    channel text DEFAULT 'website'::character varying NOT NULL,
    notes text,
    offer_price numeric(12,2),
    source_url text,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.leads OWNER TO dubaiauto;

--
-- Name: market_analysis_config; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.market_analysis_config (
    id text DEFAULT 'default'::text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    sources jsonb DEFAULT '["dubizzle", "dubicars"]'::jsonb NOT NULL,
    auto_refresh_enabled boolean DEFAULT true NOT NULL,
    refresh_interval_hours integer DEFAULT 24 NOT NULL,
    min_confidence_pct integer DEFAULT 60 NOT NULL,
    tracked_models jsonb DEFAULT '[]'::jsonb NOT NULL,
    last_refreshed_at timestamp(3) without time zone,
    last_refresh_status text DEFAULT 'never_run'::character varying NOT NULL,
    last_refresh_summary text,
    ai_model text DEFAULT 'claude-sonnet-4-6'::character varying NOT NULL,
    updated_by text,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.market_analysis_config OWNER TO dubaiauto;

--
-- Name: market_analysis_runs; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.market_analysis_runs (
    id text NOT NULL,
    triggered_by text,
    status text DEFAULT 'running'::character varying NOT NULL,
    models_requested integer DEFAULT 0 NOT NULL,
    models_updated integer DEFAULT 0 NOT NULL,
    models_failed integer DEFAULT 0 NOT NULL,
    sources_used jsonb DEFAULT '[]'::jsonb NOT NULL,
    summary text,
    error_detail text,
    started_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    completed_at timestamp(3) without time zone
);


ALTER TABLE public.market_analysis_runs OWNER TO dubaiauto;

--
-- Name: market_competitor_data; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.market_competitor_data (
    id text NOT NULL,
    make text NOT NULL,
    model text NOT NULL,
    year integer NOT NULL,
    source text NOT NULL,
    avg_price_aed numeric(12,2) NOT NULL,
    min_price_aed numeric(12,2),
    max_price_aed numeric(12,2),
    listing_count integer DEFAULT 0 NOT NULL,
    avg_days_listed integer,
    demand_level text,
    trend_pct numeric(5,2),
    confidence_pct integer DEFAULT 70 NOT NULL,
    source_url text,
    raw_ai_notes text,
    fetched_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    expires_at timestamp(3) without time zone DEFAULT (now() + '7 days'::interval) NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.market_competitor_data OWNER TO dubaiauto;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    dealer_id text,
    broker_id text,
    type text NOT NULL,
    category text DEFAULT 'general'::character varying NOT NULL,
    title text NOT NULL,
    body text,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    read_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_notifications_recipient CHECK (((dealer_id IS NOT NULL) OR (broker_id IS NOT NULL)))
);


ALTER TABLE public.notifications OWNER TO dubaiauto;

--
-- Name: plan_features; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.plan_features (
    id text NOT NULL,
    plan_id text NOT NULL,
    feature_id text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    limit_value integer,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.plan_features OWNER TO dubaiauto;

--
-- Name: plan_limits; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.plan_limits (
    id text NOT NULL,
    plan_id text NOT NULL,
    limit_key text NOT NULL,
    limit_name text NOT NULL,
    limit_value integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.plan_limits OWNER TO dubaiauto;

--
-- Name: price_history; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.price_history (
    id text NOT NULL,
    vehicle_id text NOT NULL,
    price_aed numeric(12,2) NOT NULL,
    changed_by text,
    changed_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.price_history OWNER TO dubaiauto;

--
-- Name: promotions; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.promotions (
    id text NOT NULL,
    dealer_id text,
    vehicle_id text NOT NULL,
    type text DEFAULT 'price_reduction'::character varying NOT NULL,
    original_price numeric(12,2) NOT NULL,
    promo_price numeric(12,2) NOT NULL,
    label text,
    starts_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    ends_at timestamp(3) without time zone,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.promotions OWNER TO dubaiauto;

--
-- Name: quote_line_items; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.quote_line_items (
    id text NOT NULL,
    quote_id text NOT NULL,
    description text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    total numeric(12,2) NOT NULL
);


ALTER TABLE public.quote_line_items OWNER TO dubaiauto;

--
-- Name: quotes; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.quotes (
    id text NOT NULL,
    dealer_id text NOT NULL,
    broker_id text,
    vehicle_id text,
    buyer_name text NOT NULL,
    buyer_email text,
    buyer_phone text,
    buyer_country text,
    quote_number text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    currency text DEFAULT 'AED'::text NOT NULL,
    subtotal_aed numeric(12,2) NOT NULL,
    discount_pct integer DEFAULT 0 NOT NULL,
    discount_aed numeric(12,2) DEFAULT 0 NOT NULL,
    tax_pct integer DEFAULT 5 NOT NULL,
    tax_aed numeric(12,2) DEFAULT 0 NOT NULL,
    total_aed numeric(12,2) NOT NULL,
    valid_until timestamp(3) without time zone,
    notes text,
    terms text,
    sent_at timestamp(3) without time zone,
    accepted_at timestamp(3) without time zone,
    rejected_at timestamp(3) without time zone,
    converted_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.quotes OWNER TO dubaiauto;

--
-- Name: scan_events; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.scan_events (
    id text NOT NULL,
    vehicle_id text,
    dealer_id text,
    scan_type text NOT NULL,
    scan_data text,
    action_taken text,
    source text DEFAULT 'mobile'::character varying NOT NULL,
    lat numeric(10,7),
    lng numeric(10,7),
    scanned_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.scan_events OWNER TO dubaiauto;

--
-- Name: share_permissions; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.share_permissions (
    id text NOT NULL,
    share_id text NOT NULL,
    dealer_id text NOT NULL,
    can_view boolean DEFAULT true NOT NULL,
    can_propose boolean DEFAULT false NOT NULL,
    can_reserve boolean DEFAULT false NOT NULL,
    can_transfer boolean DEFAULT false NOT NULL,
    can_negotiate boolean DEFAULT false NOT NULL,
    starts_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    ends_at timestamp(3) without time zone,
    revoked_at timestamp(3) without time zone,
    revoked_by text,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.share_permissions OWNER TO dubaiauto;

--
-- Name: stock_transactions; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.stock_transactions (
    id text NOT NULL,
    vehicle_id text NOT NULL,
    dealer_id text,
    txn_type text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    quantity_before integer DEFAULT 0 NOT NULL,
    quantity_after integer DEFAULT 0 NOT NULL,
    note text,
    actor_id text,
    source text DEFAULT 'manual'::character varying NOT NULL,
    occurred_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.stock_transactions OWNER TO dubaiauto;

--
-- Name: subscription_coupons; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.subscription_coupons (
    id text NOT NULL,
    code text NOT NULL,
    name text,
    discount_type text DEFAULT 'percentage'::character varying NOT NULL,
    discount_value numeric(10,2) NOT NULL,
    max_uses integer,
    current_uses integer DEFAULT 0 NOT NULL,
    valid_from timestamp(3) without time zone DEFAULT now() NOT NULL,
    valid_until timestamp(3) without time zone,
    min_amount numeric(10,2) DEFAULT 0 NOT NULL,
    applicable_plans text[],
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subscription_coupons OWNER TO dubaiauto;

--
-- Name: subscription_features; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.subscription_features (
    id text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    description text,
    icon text,
    category text DEFAULT 'general'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_premium boolean DEFAULT false NOT NULL,
    is_visible boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subscription_features OWNER TO dubaiauto;

--
-- Name: subscription_history; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.subscription_history (
    id text NOT NULL,
    dealer_id text NOT NULL,
    subscription_id text,
    event_type text NOT NULL,
    from_plan_id text,
    to_plan_id text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subscription_history OWNER TO dubaiauto;

--
-- Name: subscription_invoices; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.subscription_invoices (
    id text NOT NULL,
    subscription_id text NOT NULL,
    dealer_id text NOT NULL,
    invoice_number text NOT NULL,
    status text DEFAULT 'draft'::character varying NOT NULL,
    amount_subtotal numeric(10,2) NOT NULL,
    amount_discount numeric(10,2) DEFAULT 0 NOT NULL,
    amount_tax numeric(10,2) DEFAULT 0 NOT NULL,
    amount_total numeric(10,2) NOT NULL,
    currency text DEFAULT 'AED'::character varying NOT NULL,
    billing_cycle text,
    period_start timestamp(3) without time zone,
    period_end timestamp(3) without time zone,
    paid_at timestamp(3) without time zone,
    due_date timestamp(3) without time zone,
    stripe_invoice_id text,
    pdf_url text,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subscription_invoices OWNER TO dubaiauto;

--
-- Name: subscription_payments; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.subscription_payments (
    id text NOT NULL,
    invoice_id text NOT NULL,
    dealer_id text NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'AED'::character varying NOT NULL,
    status text DEFAULT 'pending'::character varying NOT NULL,
    gateway text DEFAULT 'stripe'::character varying NOT NULL,
    gateway_payment_id text,
    gateway_response jsonb DEFAULT '{}'::jsonb NOT NULL,
    failure_reason text,
    refunded_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subscription_payments OWNER TO dubaiauto;

--
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.subscription_plans (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    tagline text,
    color text DEFAULT '#6B7280'::character varying NOT NULL,
    badge text,
    is_active boolean DEFAULT true NOT NULL,
    is_visible boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    price_monthly numeric(10,2) DEFAULT 0 NOT NULL,
    price_quarterly numeric(10,2) DEFAULT 0 NOT NULL,
    price_yearly numeric(10,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'AED'::character varying NOT NULL,
    trial_days integer DEFAULT 0 NOT NULL,
    stripe_price_monthly_id text,
    stripe_price_yearly_id text,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscription_plans OWNER TO dubaiauto;

--
-- Name: subscription_usage; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.subscription_usage (
    id text NOT NULL,
    dealer_id text NOT NULL,
    usage_key text NOT NULL,
    period_year integer NOT NULL,
    period_month integer NOT NULL,
    value integer DEFAULT 0 NOT NULL,
    reset_at timestamp(3) without time zone,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscription_usage OWNER TO dubaiauto;

--
-- Name: users; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    password_hash text,
    full_name text NOT NULL,
    phone text,
    whatsapp text,
    avatar_url text,
    role text DEFAULT 'buyer'::character varying NOT NULL,
    mfa_secret text,
    mfa_enabled boolean DEFAULT false NOT NULL,
    email_verified boolean DEFAULT false NOT NULL,
    preferred_lang text DEFAULT 'en'::character varying NOT NULL,
    last_login_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO dubaiauto;

--
-- Name: valuation_config; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.valuation_config (
    id text DEFAULT 'default'::text NOT NULL,
    weight_mileage numeric(4,3) DEFAULT 0.20 NOT NULL,
    weight_year numeric(4,3) DEFAULT 0.15 NOT NULL,
    weight_market_demand numeric(4,3) DEFAULT 0.25 NOT NULL,
    weight_comparable_sales numeric(4,3) DEFAULT 0.30 NOT NULL,
    weight_condition numeric(4,3) DEFAULT 0.10 NOT NULL,
    depreciation_year1 numeric(4,3) DEFAULT 0.15 NOT NULL,
    depreciation_year2 numeric(4,3) DEFAULT 0.12 NOT NULL,
    depreciation_year3 numeric(4,3) DEFAULT 0.10 NOT NULL,
    depreciation_year4plus numeric(4,3) DEFAULT 0.08 NOT NULL,
    mileage_baseline_km integer DEFAULT 15000 NOT NULL,
    mileage_penalty_pct numeric(4,3) DEFAULT 0.02 NOT NULL,
    excellent_deal_below numeric(4,3) DEFAULT 0.88 NOT NULL,
    good_deal_below numeric(4,3) DEFAULT 0.95 NOT NULL,
    fair_price_below numeric(4,3) DEFAULT 1.05 NOT NULL,
    above_market_below numeric(4,3) DEFAULT 1.15 NOT NULL,
    active_currencies text[] DEFAULT ARRAY['AED'::text, 'USD'::text, 'EUR'::text, 'GBP'::text, 'NGN'::text],
    active_countries text[] DEFAULT ARRAY['UAE'::text, 'Nigeria'::text, 'Ghana'::text, 'Kenya'::text, 'UK'::text, 'France'::text],
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.valuation_config OWNER TO dubaiauto;

--
-- Name: vehicle_images; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.vehicle_images (
    id text NOT NULL,
    vehicle_id text NOT NULL,
    s3_key text NOT NULL,
    cdn_url text,
    thumb_url text,
    is_primary boolean DEFAULT false NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.vehicle_images OWNER TO dubaiauto;

--
-- Name: vehicle_qr_codes; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.vehicle_qr_codes (
    id text NOT NULL,
    vehicle_id text NOT NULL,
    qr_token text NOT NULL,
    qr_url text,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.vehicle_qr_codes OWNER TO dubaiauto;

--
-- Name: vehicle_reservations; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.vehicle_reservations (
    id text NOT NULL,
    vehicle_id text NOT NULL,
    dealer_id text NOT NULL,
    broker_id text,
    reserved_by_name text,
    reserved_by_contact text,
    status text DEFAULT 'active'::character varying NOT NULL,
    note text,
    expires_at timestamp(3) without time zone NOT NULL,
    cancelled_at timestamp(3) without time zone,
    converted_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.vehicle_reservations OWNER TO dubaiauto;

--
-- Name: vehicle_shares; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.vehicle_shares (
    id text NOT NULL,
    vehicle_id text NOT NULL,
    owner_dealer_id text NOT NULL,
    visibility text DEFAULT 'private'::character varying NOT NULL,
    group_id text,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.vehicle_shares OWNER TO dubaiauto;

--
-- Name: vehicle_timeline; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.vehicle_timeline (
    id text NOT NULL,
    vehicle_id text NOT NULL,
    event_type text NOT NULL,
    event_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    actor_id text,
    actor_type text DEFAULT 'dealer'::character varying NOT NULL,
    note text,
    occurred_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.vehicle_timeline OWNER TO dubaiauto;

--
-- Name: vehicle_valuations; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.vehicle_valuations (
    id text NOT NULL,
    vehicle_id text,
    make text NOT NULL,
    model text NOT NULL,
    year integer NOT NULL,
    "trim" text,
    mileage_km integer DEFAULT 0 NOT NULL,
    estimated_value_aed numeric(12,2) NOT NULL,
    value_min_aed numeric(12,2),
    value_max_aed numeric(12,2),
    confidence_score integer DEFAULT 85 NOT NULL,
    deal_rating text,
    deal_score integer,
    market_demand text,
    demand_score integer,
    avg_days_to_sell integer,
    price_trend_pct numeric(5,2),
    price_trend_direction text,
    market_score integer,
    investment_score integer,
    dealer_confidence integer,
    export_score integer,
    comparable_count integer DEFAULT 0 NOT NULL,
    comparable_sources text[],
    ai_reasoning text,
    ai_strengths jsonb DEFAULT '[]'::jsonb NOT NULL,
    ai_risks jsonb DEFAULT '[]'::jsonb NOT NULL,
    computed_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    expires_at timestamp(3) without time zone DEFAULT (now() + '24:00:00'::interval) NOT NULL,
    is_stale boolean DEFAULT false NOT NULL
);


ALTER TABLE public.vehicle_valuations OWNER TO dubaiauto;

--
-- Name: vehicles; Type: TABLE; Schema: public; Owner: dubaiauto
--

CREATE TABLE public.vehicles (
    id text NOT NULL,
    dealer_id text NOT NULL,
    vin text,
    make text NOT NULL,
    model text NOT NULL,
    year integer NOT NULL,
    generation text,
    "trim" text,
    body_type text,
    fuel_type text,
    transmission text,
    engine text,
    horsepower integer,
    torque integer,
    doors integer,
    seats integer,
    mileage_km integer DEFAULT 0 NOT NULL,
    color_exterior text,
    color_interior text,
    wheels text,
    country_origin text,
    specs jsonb DEFAULT '{}'::jsonb NOT NULL,
    features text[],
    price_aed numeric(12,2) NOT NULL,
    price_min_aed numeric(12,2),
    price_suggested_aed numeric(12,2),
    negotiable boolean DEFAULT true NOT NULL,
    status text DEFAULT 'available'::text NOT NULL,
    export_eligible boolean DEFAULT false NOT NULL,
    title text,
    description text,
    seo_keywords text,
    ai_confidence numeric(4,3),
    ai_raw_result jsonb,
    duplicate_hash text,
    view_count integer DEFAULT 0 NOT NULL,
    favorite_count integer DEFAULT 0 NOT NULL,
    es_indexed_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    stock_quantity integer DEFAULT 1 NOT NULL,
    plate_number text,
    specs_origin text DEFAULT 'GCC'::character varying NOT NULL,
    currency text DEFAULT 'AED'::text NOT NULL,
    sold_units integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.vehicles OWNER TO dubaiauto;

--
-- Data for Name: AffiliatePayment; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public."AffiliatePayment" (id, broker_id, amount_aed, deals_count, period_start, period_end, status, payment_method, payment_ref, notes, paid_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: CrmActivity; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public."CrmActivity" (id, contact_id, type, title, body, direction, duration_min, outcome, scheduled_at, completed, completed_at, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: CrmContact; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public."CrmContact" (id, type, full_name, email, phone, whatsapp, company, country, city, source, owner, score, tags, status, last_activity_at, notes, ref_dealer_id, ref_broker_id, ref_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: CrmDeal; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public."CrmDeal" (id, contact_id, title, value_aed, stage, probability_pct, expected_close, owner, source, notes, lost_reason, won_at, lost_at, plan_interest, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: EmailCampaign; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public."EmailCampaign" (id, name, subject_a, subject_b, preview_text, from_name, from_email, reply_to, segment, blocks, html_body, status, type, ab_test, ab_split_pct, ab_winner, scheduled_at, sent_at, total_recipients, tags, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: EmailLink; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public."EmailLink" (id, campaign_id, tracking_id, original_url, link_id, clicks, created_at) FROM stdin;
\.


--
-- Data for Name: EmailSend; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public."EmailSend" (id, campaign_id, recipient_email, recipient_name, subject, variant, status, provider_id, tracking_id, opened, opened_at, open_count, clicked, clicked_at, click_count, bounced, bounce_reason, unsubscribed, sent_at, created_at) FROM stdin;
\.


--
-- Data for Name: EmailTemplate; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public."EmailTemplate" (id, name, description, category, thumbnail, blocks, is_system, usage_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: EmailUnsubscribe; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public."EmailUnsubscribe" (id, email, reason, created_at) FROM stdin;
\.


--
-- Data for Name: ExecMeeting; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public."ExecMeeting" (id, title, attendees, date, duration_min, type, notes, link, status, created_at) FROM stdin;
\.


--
-- Data for Name: ExecTask; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public."ExecTask" (id, title, description, priority, status, due_date, assignee, category, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: KpiSnapshot; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public."KpiSnapshot" (id, date, mrr_aed, arr_aed, active_dealers, new_dealers_month, total_vehicles, deals_month, revenue_month_aed, health_score) FROM stdin;
\.


--
-- Data for Name: MarketingSpend; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public."MarketingSpend" (id, month, channel, amount_aed, notes, created_at) FROM stdin;
\.


--
-- Data for Name: PushCampaign; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public."PushCampaign" (id, title, body, image_url, action_url, action_label, type, audience, status, scheduled_at, sent_at, total_sent, total_clicked, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: PushSend; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public."PushSend" (id, campaign_id, recipient_type, recipient_id, notification_id, clicked, clicked_at, created_at) FROM stdin;
\.


--
-- Data for Name: active_sessions; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.active_sessions (id, session_token, profile_type, profile_id, display_name, avatar_label, email, current_page, last_seen_at, created_at) FROM stdin;
\.


--
-- Data for Name: ai_credits; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.ai_credits (id, dealer_id, credits_total, credits_used, credits_reset_at, reset_period, updated_at) FROM stdin;
\.


--
-- Data for Name: alert_notifications; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.alert_notifications (id, alert_id, vehicle_id, title, message, channel, status, sent_at, created_at) FROM stdin;
\.


--
-- Data for Name: alert_subscriptions; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.alert_subscriptions (id, user_id, email, phone, alert_type, filters, channel, is_active, last_triggered, trigger_count, created_at) FROM stdin;
\.


--
-- Data for Name: broker_deals; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.broker_deals (id, broker_id, dealer_id, vehicle_id, buyer_name, buyer_country, deal_price_aed, commission_rate, commission_aed, status, paid_at, notes, created_at, currency) FROM stdin;
823c3ba3-078f-43d8-92e7-a169dd09bd80	broker-001	dealer-jafza-001	\N	Emeka Okonkwo	Nigeria	228000.00	0.025	5700.00	paid	2026-06-29 23:34:43.888	\N	2026-07-04 23:34:43.888	AED
8648c917-6198-4231-9a98-b9de90c886b2	broker-001	dealer-dubai-003	\N	Kwame Asante	Ghana	298000.00	0.025	7450.00	paid	2026-06-22 23:34:43.888	\N	2026-07-04 23:34:43.888	AED
19801413-1b5a-4011-8af8-c601672619ac	broker-001	dealer-dubai-007	\N	Mohamed Hassan	Kenya	88000.00	0.025	2200.00	paid	2026-06-16 23:34:43.888	\N	2026-07-04 23:34:43.888	AED
a80183b4-4ea3-49c7-a55a-447a5716cf1d	broker-001	dealer-dubai-008	\N	Tariq Al Farsi	UAE	695000.00	0.025	17375.00	pending	\N	\N	2026-07-04 23:34:43.888	AED
0998109e-8768-4b18-bbf4-93d9760cacb3	broker-001	dealer-dubai-011	\N	Li Wei	China	112000.00	0.025	2800.00	processing	\N	\N	2026-07-04 23:34:43.888	AED
4057a7ce-d3f2-4acb-b1ae-1932ac6a50ba	broker-002	dealer-jafza-001	\N	Chidi Okeke	Nigeria	228000.00	0.020	4560.00	paid	2026-06-26 23:34:43.888	\N	2026-07-04 23:34:43.888	AED
a1f673f1-fdbd-47ef-83de-b1a0662b626b	broker-002	dealer-dubai-007	\N	Biodun Adeyemi	Nigeria	92000.00	0.020	1840.00	paid	2026-06-19 23:34:43.888	\N	2026-07-04 23:34:43.888	AED
f6a8f576-d171-4e13-a2d6-1ee398868db5	broker-002	dealer-jafza-001	\N	Femi Adeleke	Nigeria	128000.00	0.020	2560.00	pending	\N	\N	2026-07-04 23:34:43.888	AED
20bf59bb-3f13-4455-b120-fd6f62ef888f	broker-006	dealer-dubai-007	\N	Segun Bakare	Nigeria	128000.00	0.030	3840.00	paid	2026-07-01 23:34:43.888	\N	2026-07-04 23:34:43.888	AED
3d089401-e701-49cd-a8e8-9e7b03331b17	broker-006	dealer-jafza-001	\N	Tunde Fashola	Nigeria	228000.00	0.030	6840.00	paid	2026-06-27 23:34:43.888	\N	2026-07-04 23:34:43.888	AED
9331abff-53d7-408e-9922-f29ddcbe69a3	broker-006	dealer-sharjah-005	\N	Nnamdi Obi	Nigeria	92000.00	0.030	2760.00	paid	2026-06-24 23:34:43.888	\N	2026-07-04 23:34:43.888	AED
d619e70d-b5e4-4c95-b3e7-35d06de7791c	broker-006	dealer-dubai-012	\N	Akin Williams	Nigeria	88000.00	0.030	2640.00	paid	2026-06-20 23:34:43.888	\N	2026-07-04 23:34:43.888	AED
6d2c76b9-8391-4a01-abbf-d3a5c82a4fa6	broker-006	dealer-jafza-002	\N	Dele Momodu	Nigeria	112000.00	0.030	3360.00	pending	\N	\N	2026-07-04 23:34:43.888	AED
a4fbc434-91b1-4bd5-875c-06fa2e425b29	broker-004	dealer-dubai-011	\N	Zhang Wei	China	165000.00	0.025	4125.00	paid	2026-06-28 23:34:43.888	\N	2026-07-04 23:34:43.888	AED
877f740d-b253-4817-88c2-18e7f05bbe50	broker-004	dealer-dubai-011	\N	Wang Fang	China	112000.00	0.025	2800.00	paid	2026-06-23 23:34:43.888	\N	2026-07-04 23:34:43.888	AED
26f38f78-a233-4cdf-8331-76aafee3f81a	broker-004	dealer-dubai-004	\N	Kim Park	South Korea	348000.00	0.025	8700.00	pending	\N	\N	2026-07-04 23:34:43.888	AED
169b8cf0-686b-49b0-9262-161c66812261	broker-003	dealer-dubai-003	\N	Emeka Nwosu	Nigeria	198000.00	0.015	2970.00	paid	2026-06-25 23:34:43.888	\N	2026-07-04 23:34:43.888	AED
17c7a0bd-60a1-494c-8b53-e82ebf75a865	broker-003	dealer-sharjah-001	\N	Amaka Eze	Nigeria	78000.00	0.015	1170.00	paid	2026-06-14 23:34:43.888	\N	2026-07-04 23:34:43.888	AED
de25f148-2d0e-4b25-adf3-daaa7fff20cd	broker-008	dealer-jafza-001	\N	Amadou Diallo	Senegal	228000.00	0.025	5700.00	paid	2026-06-30 23:34:43.888	\N	2026-07-04 23:34:43.888	AED
178fa73d-006f-4ea9-8f4e-72e7caee547c	broker-008	dealer-dubai-007	\N	Oumar Ba	Senegal	88000.00	0.025	2200.00	paid	2026-06-21 23:34:43.888	\N	2026-07-04 23:34:43.888	AED
83d8edc8-e588-429b-9fd0-f213937ca251	broker-008	dealer-sharjah-005	\N	Ibrahima Sow	Guinea	62000.00	0.025	1550.00	processing	\N	\N	2026-07-04 23:34:43.888	AED
e4b22c23-9d8f-4592-ae64-877cb5c6bc8f	broker-001	dealer-001	\N	Yusuf Bello	Nigeria	215000.00	0.025	5375.00	paid	2026-07-02 23:34:43.888	\N	2026-07-04 23:34:43.888	AED
66b2903a-e585-499a-84d6-892d8480d863	broker-006	dealer-001	\N	Grace Mensah	Ghana	142000.00	0.030	4260.00	paid	2026-06-28 23:34:43.888	\N	2026-07-04 23:34:43.888	AED
6aa7ae51-d191-4ca5-a7f5-9b8fb30ff777	broker-002	dealer-001	\N	Daniel Owusu	Ghana	98000.00	0.020	1960.00	pending	\N	\N	2026-07-04 23:34:43.888	AED
c1e1ef01-9c7a-49a8-8f35-2d8cf1402f47	broker-004	dealer-001	\N	Li Na	China	176000.00	0.025	4400.00	paid	2026-06-24 23:34:43.888	\N	2026-07-04 23:34:43.888	AED
\.


--
-- Data for Name: broker_referrals; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.broker_referrals (id, broker_id, referred_type, referred_id, referral_code, reward_aed, recurring_pct, status, created_at) FROM stdin;
\.


--
-- Data for Name: brokers; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.brokers (id, user_id, full_name, email, phone, whatsapp, company_name, broker_type, affiliate_code, tier, commission_rate, status, country, city, languages, specialties, referred_by, created_at, updated_at, country_id) FROM stdin;
broker-002	\N	Ibrahim Yusuf	ibrahim@broker.ng	+2348012345678	+2348012345678	IbrahimAuto Ltd	export_agent	IBRA-9MK3	Active	0.020	active	Nigeria	Lagos	{Hausa,English}	{"Export / Africa","Pickup Trucks","SUV & 4x4"}	\N	2026-07-04 23:34:43.884	2026-07-04 23:34:43.884	\N
broker-003	\N	Emmanuel Obi	emmanuel@carsng.com	+2348098765432	+2348098765432	CarSales Nigeria	intermediary	EMMA-5KR1	Starter	0.015	active	Nigeria	Abuja	{English,Hausa}	{"Export / Africa","SUV & 4x4"}	\N	2026-07-04 23:34:43.884	2026-07-04 23:34:43.884	\N
broker-004	\N	Chen Wei	chen@autoasia.com	+8613912345678	+8613912345678	Asia Auto Partners	export_agent	CHEN-7NX4	Pro	0.025	active	China	Shanghai	{Chinese,English}	{"Electric Vehicles","Export / Asia","Luxury & Supercar"}	\N	2026-07-04 23:34:43.884	2026-07-04 23:34:43.884	\N
broker-005	\N	Fatima Al Zahra	fatima@broker.ma	+212612345678	+212612345678	\N	independent	FATI-2PL8	Active	0.020	active	Morocco	Casablanca	{Arabic,French}	{"Luxury & Supercar",Sedan}	\N	2026-07-04 23:34:43.884	2026-07-04 23:34:43.884	\N
broker-006	\N	James Okafor	james@nigeriaexport.com	+2349012345678	+2349012345678	Nigeria Export Auto	export_agent	JAME-3LK9	Elite	0.030	active	Nigeria	Lagos	{English,Yoruba}	{"Export / Africa","Pickup Trucks","Commercial Vans"}	\N	2026-07-04 23:34:43.884	2026-07-04 23:34:43.884	\N
broker-007	\N	Rajesh Sharma	rajesh@indiacar.in	+919812345678	+919812345678	India Car Imports	dealer_affiliate	RAJE-6MP2	Active	0.020	active	India	Mumbai	{Hindi,English}	{"Export / Asia","SUV & 4x4"}	\N	2026-07-04 23:34:43.884	2026-07-04 23:34:43.884	\N
broker-008	\N	Moussa Diallo	moussa@westafricaauto.com	+22376123456	+22376123456	West Africa Auto	export_agent	MOUS-8QR5	Pro	0.025	active	Senegal	Dakar	{French,Wolof,English}	{"Export / Africa","Pickup Trucks","SUV & 4x4"}	\N	2026-07-04 23:34:43.884	2026-07-04 23:34:43.884	\N
broker-001	broker-user-001	Ahmed Al Mansouri	ahmed@dubaiauto.ae	+971501234567	+971501234567	\N	independent	AHMED-X7K2	Pro	0.025	active	UAE	Dubai	{Arabic,English}	{"SUV & 4x4","Export / Africa","Luxury & Supercar"}	\N	2026-07-04 23:34:43.884	2026-07-04 23:34:43.884	\N
\.


--
-- Data for Name: collaboration_messages; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.collaboration_messages (id, vehicle_id, from_dealer_id, to_dealer_id, msg_type, content, offer_price_aed, status, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.countries (id, code, name, name_ar, currency_code, phone_prefix, vat_rate, is_active, created_at) FROM stdin;
country_ae	AE	United Arab Emirates	الإمارات العربية المتحدة	AED	+971	0.050	t	2026-07-04 23:34:49.586
country_sa	SA	Saudi Arabia	المملكة العربية السعودية	SAR	+966	0.150	t	2026-07-04 23:34:49.586
country_qa	QA	Qatar	قطر	QAR	+974	0.000	t	2026-07-04 23:34:49.586
country_bh	BH	Bahrain	البحرين	BHD	+973	0.100	t	2026-07-04 23:34:49.586
country_kw	KW	Kuwait	الكويت	KWD	+965	0.000	t	2026-07-04 23:34:49.586
country_om	OM	Oman	عُمان	OMR	+968	0.050	t	2026-07-04 23:34:49.586
\.


--
-- Data for Name: dealer_group_members; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.dealer_group_members (group_id, dealer_id, role, joined_at) FROM stdin;
\.


--
-- Data for Name: dealer_groups; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.dealer_groups (id, name, description, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: dealer_reports; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.dealer_reports (id, dealer_id, report_type, week_start, week_end, status, total_units, available_units, sold_this_week, total_views, avg_price_aed, market_avg_price, price_position, price_diff_pct, ai_summary, ai_recommendations, ai_alerts, market_data, competitor_data, generated_at, created_at) FROM stdin;
\.


--
-- Data for Name: dealer_reviews; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.dealer_reviews (id, dealer_id, user_id, rating, comment, created_at) FROM stdin;
\.


--
-- Data for Name: dealer_subscriptions; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.dealer_subscriptions (id, dealer_id, plan_id, status, billing_cycle, current_period_start, current_period_end, trial_start, trial_end, cancelled_at, cancel_reason, auto_renew, stripe_subscription_id, stripe_customer_id, coupon_id, discount_pct, grace_period_ends, created_at, updated_at) FROM stdin;
01541317-dd8b-4462-8765-c3b7c20d32ee	dealer-001	plan-pro	active	monthly	2026-07-04 23:34:43.29	2026-08-03 23:34:43.29	\N	\N	\N	\N	t	\N	\N	\N	0	\N	2026-07-04 23:34:43.29	2026-07-04 23:34:43.29
\.


--
-- Data for Name: dealers; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.dealers (id, user_id, company_name, slug, description, logo_url, cover_url, phone, whatsapp, email, website, address, free_zone_license, languages, export_destinations, certifications, verified, verified_at, rating, review_count, subscription_tier, subscription_ends, stripe_customer_id, created_at, updated_at, city, country_id, free_zone_id) FROM stdin;
dealer-jafza-010	ja-user-010	Desert Auto Export JAFZA	desert-auto-export-jafza	Off-road and 4x4 specialist in Jebel Ali Free Zone. Land Rover Defender, Toyota FJ Cruiser, Mercedes G-Class, Nissan Patrol. Modified and stock vehicles. Safari preparation available. Export to Middle East, Africa and worldwide.	\N	\N	+97148850000	+971503456789	sales@desertauto.ae	\N	Jebel Ali Free Zone, Zone B, Plot 15, JAFZA, Dubai, UAE	JAFZA-2024-DAE010	{en,ar,fr}	{"North Africa","Middle East","East Africa"}	{}	t	\N	4.40	78	starter	\N	\N	2026-07-04 23:34:43.73	2026-07-04 23:34:43.73	\N	country_ae	\N
dealer-sharjah-002	sh-user-002	Al Majid Motors Sharjah	al-majid-motors-sharjah	Sharjah-based authorized dealer with 200+ pre-owned vehicles. Toyota and Lexus specialist. Fleet management company partnerships. Export to GCC countries and East Africa. Free inspection report on every vehicle.	\N	\N	+97165444333	+971554001122	cars@almajidauto.ae	\N	Industrial Area 17, King Faisal Road, Sharjah, UAE	SAIF-2024-AM002	{en,ar,ur}	{GCC,"East Africa","South Asia"}	{}	t	\N	4.60	213	pro	\N	\N	2026-07-04 23:34:43.731	2026-07-04 23:34:43.731	\N	country_ae	\N
dealer-001	dealer-user-001	Al Rashid Motors LLC	al-rashid-motors	Premium car dealer in Dubai Free Zone. Specializing in luxury SUVs and sports cars for export worldwide.	\N	\N	+971501234567	+971501234567	dealer@demo.ae	\N	\N	\N	{en,ar,fr}	{Africa,Europe,Asia}	{}	t	\N	4.80	47	pro	\N	\N	2026-07-04 23:34:43.022	2026-07-04 23:34:43.022	\N	country_ae	\N
dealer-dubai-001	du-user-001	Al Nabooda Automobiles LLC	al-nabooda-automobiles	Official dealer for Volkswagen, Audi and Porsche in the UAE since 1971. Dubai Free Zone flagship showroom with over 500 vehicles in stock. Specializing in premium German brands export to GCC, Africa and CIS countries. Full after-sales service center.	\N	\N	+97143408000	+97143408000	info@alnabooda.ae	https://www.alnabooda.ae	Sheikh Zayed Road, Dubai Free Zone, Al Quoz Industrial Area 1, Dubai, UAE	DCCA-2024-AN001	{en,ar}	{GCC,Africa,Europe,Asia}	{}	t	\N	4.80	312	enterprise	\N	\N	2026-07-04 23:34:43.727	2026-07-04 23:34:43.727	\N	country_ae	\N
dealer-dubai-002	du-user-002	Al Habtoor Motors	al-habtoor-motors	Established 1971, Al Habtoor Motors is the exclusive dealer for Mercedes-Benz, Mitsubishi and Foton commercial vehicles in UAE. Dubai Free Zone showroom on Sheikh Zayed Road. Export division handling Africa and CIS markets.	\N	\N	+97143242000	+97143242000	sales@alhabtoor.ae	https://www.alhabtoor-motors.com	Sheikh Zayed Road, Business Bay, Dubai Free Zone, Dubai, UAE	DCCA-2024-AH002	{en,ar,ru}	{GCC,Africa,CIS,Europe}	{}	t	\N	4.70	287	enterprise	\N	\N	2026-07-04 23:34:43.727	2026-07-04 23:34:43.727	\N	country_ae	\N
dealer-dubai-003	du-user-003	Al Ain Class Automobiles	al-ain-class-automobiles	Dubai Free Zone used car specialist with over 1,200 vehicles in stock. Largest selection of Toyota Land Cruisers in UAE. Export specialists to West Africa, East Africa and Middle East. Bulk fleet purchases welcome.	\N	\N	+97142663555	+971504123456	cars@alain.ae	https://www.alainclass.ae	Al Quoz Industrial Area 4, Dubai Free Zone, Dubai, UAE	DCCA-2024-AC003	{en,ar,fr}	{"West Africa","East Africa",GCC,Europe}	{}	t	\N	4.60	198	enterprise	\N	\N	2026-07-04 23:34:43.727	2026-07-04 23:34:43.727	\N	country_ae	\N
dealer-dubai-004	du-user-004	AGMC — BMW, MINI & Rolls-Royce	agmc-bmw	Arabian German Motorcars Co. Official BMW, MINI and Rolls-Royce dealer in Dubai. Luxury vehicle export specialists with dedicated export team for Africa, Asia and CIS. Bespoke ordering service for international clients.	\N	\N	+97143430000	+97143430000	info@agmc.ae	https://www.agmc.ae	Sheikh Zayed Road, DIFC Area, Dubai Free Zone, Dubai, UAE	DCCA-2024-AG004	{en,ar,de,zh}	{Africa,Asia,CIS,Europe,Americas}	{}	t	\N	4.90	445	enterprise	\N	\N	2026-07-04 23:34:43.727	2026-07-04 23:34:43.727	\N	country_ae	\N
dealer-dubai-005	du-user-005	Manheim Middle East — Dubai	manheim-middle-east-dubai	The world largest automotive auction company. Dubai Free Zone facility handles 5,000+ vehicles per month. Weekly auctions open to registered dealers. Export clearance and logistics support for all destinations.	\N	\N	+97148118000	+971506001234	export@manheim.ae	https://www.manheim.ae	Jebel Ali Free Zone — JAFZA South, Dubai, UAE	JAFZA-2024-MAN005	{en,ar}	{"Global — all destinations"}	{}	t	\N	4.50	156	enterprise	\N	\N	2026-07-04 23:34:43.727	2026-07-04 23:34:43.727	\N	country_ae	\N
dealer-dubai-006	du-user-006	Al Fardan Automobiles	al-fardan-automobiles	Premium automobile dealer in Dubai Free Zone. Specializing in luxury SUVs, sports cars and limited edition vehicles. Rolls-Royce, Bentley and McLaren authorized service. Private import and export service for UHNWI clients.	\N	\N	+97144558555	+971558112233	info@alfardan.ae	https://www.alfardan-automobiles.com	Al Safa Street, Jumeirah, Dubai Free Zone, Dubai, UAE	DCCA-2024-AF006	{en,ar,ru,zh}	{GCC,Europe,Asia,Americas}	{}	t	\N	4.90	89	pro	\N	\N	2026-07-04 23:34:43.727	2026-07-04 23:34:43.727	\N	country_ae	\N
dealer-dubai-007	du-user-007	Premier Motors Dubai	premier-motors-dubai	Independent used car dealer in Dubai Free Zone with 300+ vehicles. Specializing in Japanese and American pickups for African export. Toyota Hilux, Nissan Navara, Ford Ranger expert. WhatsApp catalog updated daily.	\N	\N	+971501234789	+971501234789	sales@premiermotors.ae	https://www.premiermotors.ae	Al Quoz Industrial Area 2, Dubai Free Zone, Dubai, UAE	DCCA-2024-PM007	{en,ar,fr,sw}	{"East Africa","West Africa","Horn of Africa"}	{}	t	\N	4.70	203	pro	\N	\N	2026-07-04 23:34:43.727	2026-07-04 23:34:43.727	\N	country_ae	\N
dealer-dubai-008	du-user-008	Gargash Enterprises — Mercedes-Benz	gargash-enterprises	Official Mercedes-Benz dealer in UAE since 1960. Dubai flagship showroom on Sheikh Zayed Road. Complete model range from A-Class to Maybach and AMG. Export service for GCC, Africa and Asia.	\N	\N	+97143377777	+97143377777	export@gargash.ae	https://www.gargash.ae	Sheikh Zayed Road, Al Quoz, Dubai Free Zone, Dubai, UAE	DCCA-2024-GE008	{en,ar,de}	{GCC,Africa,Asia,Europe}	{}	t	\N	4.80	521	enterprise	\N	\N	2026-07-04 23:34:43.727	2026-07-04 23:34:43.727	\N	country_ae	\N
dealer-dubai-009	du-user-009	Al Rostamani Automobiles	al-rostamani-automobiles	Exclusive Honda and Suzuki dealer in UAE. Dubai Free Zone facility with comprehensive used car center. Export specialists for Japanese brands across Africa and South Asia. Fleet sales and bulk export available.	\N	\N	+97142954444	+97142954444	cars@alrostamani.ae	https://www.alrostamani.ae	Al Garhoud, Airport Road, Dubai Free Zone, Dubai, UAE	DCCA-2024-AR009	{en,ar,ur,hi}	{"South Asia","East Africa",GCC}	{}	t	\N	4.60	167	pro	\N	\N	2026-07-04 23:34:43.727	2026-07-04 23:34:43.727	\N	country_ae	\N
dealer-dubai-010	du-user-010	Emirates Motors — Ford & Lincoln	emirates-motors	Official Ford and Lincoln dealer in UAE. Specializing in F-150, Bronco, Explorer and Expedition export. Raptor specialist with dedicated performance vehicle department. Export logistics to all destinations.	\N	\N	+97142822000	+97142822000	info@emiratesmotors.ae	https://www.emiratesmotors.ae	Sheikh Zayed Road, Al Quoz, Dubai Free Zone, Dubai, UAE	DCCA-2024-EM010	{en,ar}	{GCC,Africa,Americas,Europe}	{}	t	\N	4.70	234	pro	\N	\N	2026-07-04 23:34:43.727	2026-07-04 23:34:43.727	\N	country_ae	\N
dealer-dubai-011	du-user-011	AutoZone Dubai	autozone-dubai	Used car export specialist in Dubai Free Zone. 400+ vehicles always in stock. Focus on Chinese brands: BYD, MG, Chery, Haval for export to Africa and Asia. New EV export department launched 2024.	\N	\N	+971554123456	+971554123456	sales@autozone.ae	\N	Dubai Cars & Automotive Zone, DCAA, Al Awir, Dubai, UAE	DCCA-2024-AZ011	{en,ar,zh,fr}	{Africa,Asia,"Middle East"}	{}	t	\N	4.40	98	pro	\N	\N	2026-07-04 23:34:43.727	2026-07-04 23:34:43.727	\N	country_ae	\N
dealer-dubai-012	du-user-012	Dubai Export Cars LLC	dubai-export-cars	Wholesale export dealer operating from Dubai Autodrome Area. Minimum order 5 vehicles. Container loading service. Documentation and customs clearance included. Specialized in volume export to Nigeria, Ghana, Senegal, Tanzania.	\N	\N	+971505678901	+971505678901	info@dubaiexportcars.ae	https://www.dubaiexportcars.ae	Al Awir Used Car Complex, Ras Al Khor, Dubai, UAE	DCCA-2024-DEC012	{en,ar,fr,yo,ha}	{Nigeria,Ghana,Senegal,"Ivory Coast",Tanzania,Kenya}	{}	t	\N	4.50	312	pro	\N	\N	2026-07-04 23:34:43.727	2026-07-04 23:34:43.727	\N	country_ae	\N
dealer-dubai-013	du-user-013	Al Masaood Automobiles	al-masaood-automobiles	Official Nissan and Infiniti dealer in UAE. Al Masaood Group — over 50 years serving UAE automotive market. Dubai and Abu Dhabi showrooms. Export division for GCC and Africa with dedicated fleet pricing.	\N	\N	+97126214444	+97126214444	trading@almasaood.ae	https://www.almasaoodautomobiles.com	Al Muroor Road, Abu Dhabi — Dubai Branch: Sheikh Zayed Rd, Dubai, UAE	DCCA-2024-AM013	{en,ar}	{GCC,Africa,Asia}	{}	t	\N	4.70	389	enterprise	\N	\N	2026-07-04 23:34:43.727	2026-07-04 23:34:43.727	\N	country_ae	\N
dealer-dubai-014	du-user-014	Luxury Wheels Dubai	luxury-wheels-dubai	Ultra-luxury and supercar specialist in Dubai. Ferrari, Lamborghini, Bugatti, Pagani — new and pre-owned. Discreet private sales service. International delivery worldwide. Investment-grade collector cars.	\N	\N	+971558901234	+971558901234	info@luxurywheels.ae	https://www.luxurywheels.ae	DIFC Gate Village, Dubai International Financial Centre, Dubai, UAE	DCCA-2024-LW014	{en,ar,fr,it,zh,ru}	{"Global — all destinations"}	{}	t	\N	5.00	45	pro	\N	\N	2026-07-04 23:34:43.727	2026-07-04 23:34:43.727	\N	country_ae	\N
dealer-dubai-015	du-user-015	Cars4Export DMCC	cars4export-dmcc	DMCC-licensed wholesale export company. Specializing in bulk vehicle export: 10–500 units per shipment. Full RoRo and container loading from Jebel Ali Port. All destinations served. FOB Jebel Ali pricing available.	\N	\N	+971506789012	+971506789012	sales@cars4export.ae	https://www.cars4export.ae	DMCC Business Centre, JLT, Jumeirah Lakes Towers, Dubai, UAE	DMCC-2024-C4E015	{en,ar,fr,pt,es}	{Africa,Americas,Asia,Europe,CIS}	{}	t	\N	4.60	127	pro	\N	\N	2026-07-04 23:34:43.727	2026-07-04 23:34:43.727	\N	country_ae	\N
dealer-jafza-001	ja-user-001	JAFZA Auto Export LLC	jafza-auto-export	Jebel Ali Free Zone based export company specializing in RoRo shipments to all global ports. Direct access to Jebel Ali Port — world 9th largest. Weekly sailings to West Africa, East Africa and CIS. 800+ vehicles in JAFZA yard.	\N	\N	+97148836000	+971506001122	export@jafzaauto.ae	https://www.jafzaautoexport.ae	Jebel Ali Free Zone, Plot J-01, Gate 5, JAFZA South, Dubai, UAE	JAFZA-2024-JAE001	{en,ar,fr,sw,ru}	{"West Africa","East Africa",CIS,"South Asia",Americas}	{}	t	\N	4.70	445	enterprise	\N	\N	2026-07-04 23:34:43.73	2026-07-04 23:34:43.73	\N	country_ae	\N
dealer-jafza-002	ja-user-002	Gulf Japan Auto Trading	gulf-japan-auto-trading	Japan-UAE joint venture operating from Jebel Ali Free Zone. Direct import from Japan auctions (USS, TAA, JAA). Toyota, Nissan, Honda, Subaru specialists. Fresh Japan import vehicles with auction sheets. Competitive prices for African and Asian markets.	\N	\N	+97148812200	+971554987654	info@gulfjapanauto.ae	https://www.gulfjapanauto.com	Jebel Ali Free Zone, Plot J-05, JAFZA North, Dubai, UAE	JAFZA-2024-GJA002	{en,ar,ja}	{"East Africa","West Africa",Pacific,"South Asia"}	{}	t	\N	4.80	234	pro	\N	\N	2026-07-04 23:34:43.73	2026-07-04 23:34:43.73	\N	country_ae	\N
dealer-jafza-003	ja-user-003	Arabian Stars Auto LLC	arabian-stars-auto	Established JAFZA dealer with 15 years experience. Specialists in SUV export: Toyota Land Cruiser 70 Series, 200 Series, 300 Series and Nissan Patrol. Stock always available. Financing assistance for approved international buyers.	\N	\N	+97148815555	+971507654321	sales@arabianstars.ae	\N	Jebel Ali Free Zone, Warehouse 5, Street 5A, JAFZA, Dubai, UAE	JAFZA-2024-ASA003	{en,ar,fr}	{Africa,"Middle East",Asia}	{}	t	\N	4.60	178	pro	\N	\N	2026-07-04 23:34:43.73	2026-07-04 23:34:43.73	\N	country_ae	\N
dealer-jafza-004	ja-user-004	Mid East Auto Export	mid-east-auto-export	JAFZA-based wholesale exporter. American and European brands specialist: Ford F-150, Chevrolet Silverado, GMC Sierra, RAM. Pickup trucks export to Africa and Americas. Full container loads at wholesale prices. RoRo from Jebel Ali weekly.	\N	\N	+97148812345	+97148812345	cars@mideastexport.ae	https://www.mideastexport.com	Jebel Ali Free Zone, Zone E, Street 12, JAFZA, Dubai, UAE	JAFZA-2024-MAE004	{en,ar,es,pt}	{Africa,Americas,Caribbean}	{}	t	\N	4.50	156	pro	\N	\N	2026-07-04 23:34:43.73	2026-07-04 23:34:43.73	\N	country_ae	\N
dealer-jafza-005	ja-user-005	Pacific Motors JAFZA	pacific-motors-jafza	Specializing in right-hand and left-hand drive vehicles for Pacific and Asian markets. Japanese, Korean and Chinese brands. Toyota HiAce, Coaster, Land Cruiser stock. Container stuffing at JAFZA yard. Direct shipping to Pacific Island nations.	\N	\N	+97148820000	+971502345678	info@pacificmotors.ae	\N	Jebel Ali Free Zone, Block A, Unit 12, JAFZA, Dubai, UAE	JAFZA-2024-PAC005	{en,ar,zh,ms,tl}	{"Pacific Islands","South East Asia",Australia}	{}	t	\N	4.40	89	pro	\N	\N	2026-07-04 23:34:43.73	2026-07-04 23:34:43.73	\N	country_ae	\N
dealer-jafza-006	ja-user-006	Al Wafa Auto Trading JAFZA	al-wafa-auto-trading-jafza	Family-run JAFZA trading company with 20 years experience. Trusted by African importers across 35 countries. Toyota, Mitsubishi, Isuzu commercial vehicles. Fleet pricing from 10 units. LC, TT and cash accepted.	\N	\N	+97148833444	+97148833444	trading@alwafaauto.ae	https://www.alwafaauto.ae	Jebel Ali Free Zone, South Zone, Road 4, JAFZA, Dubai, UAE	JAFZA-2024-AWA006	{en,ar,fr,sw,ha}	{Nigeria,Ghana,Kenya,Tanzania,Uganda,Ethiopia,Senegal,Cameroon}	{}	t	\N	4.70	312	pro	\N	\N	2026-07-04 23:34:43.73	2026-07-04 23:34:43.73	\N	country_ae	\N
dealer-jafza-007	ja-user-007	Continental Auto JAFZA	continental-auto-jafza	European car specialist in Jebel Ali Free Zone. BMW, Mercedes, Audi, Volkswagen pre-owned vehicles. Certified pre-owned program with mechanical inspection. Export to CIS countries, Libya, Egypt and Levant. Russian-speaking team available.	\N	\N	+97148830000	+971555432198	info@continentalauto.ae	\N	Jebel Ali Free Zone, Zone F, Warehouse 8, JAFZA, Dubai, UAE	JAFZA-2024-CAJ007	{en,ar,ru,de}	{CIS,Libya,Egypt,Levant,Ukraine}	{}	t	\N	4.50	134	pro	\N	\N	2026-07-04 23:34:43.73	2026-07-04 23:34:43.73	\N	country_ae	\N
dealer-jafza-008	ja-user-008	Triangle Auto Export JAFZA	triangle-auto-export-jafza	Volume exporter from JAFZA. Minimum 3 units per order. Specializing in economy and mid-range vehicles for emerging markets. Toyota Corolla, Camry, Yaris — Honda Civic, Accord. Best prices for Senegal, Mali, Burkina Faso markets.	\N	\N	+97148840000	+971508765432	export@triangleauto.ae	\N	Jebel Ali Free Zone, East Zone, Street 8, JAFZA, Dubai, UAE	JAFZA-2024-TAE008	{en,ar,fr,wo}	{"West Africa","Francophone Africa"}	{}	t	\N	4.30	67	starter	\N	\N	2026-07-04 23:34:43.73	2026-07-04 23:34:43.73	\N	country_ae	\N
dealer-jafza-009	ja-user-009	Global Cars Trading LLC	global-cars-trading-jafza	JAFZA registered global vehicle trading company. New Chinese brands specialist: BYD, MG, Chery, Geely, Haval, Tank export to Africa. Growing EV and hybrid export program. Direct factory relationships for bulk orders.	\N	\N	+97148845678	+97148845678	info@globalcarstrading.ae	https://www.globalcarstrading.ae	Jebel Ali Free Zone, New Area, Building G12, JAFZA, Dubai, UAE	JAFZA-2024-GCT009	{en,ar,zh,fr}	{Africa,Asia,"Middle East"}	{}	t	\N	4.60	89	pro	\N	\N	2026-07-04 23:34:43.73	2026-07-04 23:34:43.73	\N	country_ae	\N
dealer-sharjah-001	sh-user-001	Sharjah Auto Mall	sharjah-auto-mall	Sharjah largest multi-brand auto mall with 50+ dealers under one roof. Industrial Area 18, Sharjah. Over 2,000 vehicles in stock. All makes and models. Export services from Sharjah Port. Free valuation service.	\N	\N	+97165000000	+971556001234	info@sharjahautomall.ae	https://www.sharjahautomall.ae	Industrial Area 18, Near Hamdan Street, Sharjah, UAE	SAIF-2024-SAM001	{en,ar,ur,hi,ml}	{GCC,"South Asia","East Africa",Africa}	{}	t	\N	4.50	678	enterprise	\N	\N	2026-07-04 23:34:43.731	2026-07-04 23:34:43.731	\N	country_ae	\N
dealer-sharjah-003	sh-user-003	Gulf Line Auto Trading	gulf-line-auto-trading-sharjah	Sharjah Auto Zone dealer specializing in American muscle cars and pickups. Ford Mustang, Dodge Challenger, Chevrolet Camaro and Corvette. Pickup trucks: F-150, Silverado, Tundra export specialists. WhatsApp orders welcome.	\N	\N	+97165333222	+971556789012	sales@gulfline.ae	\N	Sharjah Industrial Area 12, Auto Zone, Sharjah, UAE	SAIF-2024-GLA003	{en,ar}	{GCC,Africa,Americas}	{}	t	\N	4.50	134	pro	\N	\N	2026-07-04 23:34:43.731	2026-07-04 23:34:43.731	\N	country_ae	\N
dealer-sharjah-004	sh-user-004	Al Hamraia Auto Sharjah	al-hamraia-auto-sharjah	Established 2001 in Sharjah Industrial Zone. Commercial vehicles and light trucks specialist. Mitsubishi Fuso, Isuzu, Hino — box trucks and refrigerated vehicles. African market expertise. Export documents in 48 hours.	\N	\N	+97165678901	+97165678901	export@alhamraiauto.ae	https://www.alhamraiauto.ae	Industrial Area 6, Near Sharjah Airport, Sharjah, UAE	SAIF-2024-AHA004	{en,ar,fr,sw}	{"East Africa","West Africa","Central Africa"}	{}	t	\N	4.40	156	pro	\N	\N	2026-07-04 23:34:43.731	2026-07-04 23:34:43.731	\N	country_ae	\N
dealer-sharjah-005	sh-user-005	SHJ Auto Export	shj-auto-export	Volume used car exporter based in Sharjah. 500+ vehicles in open-air compound. Specializing in large volume orders for dealers in Nigeria, Ghana, Tanzania, Uganda. Best prices in the market. Free container loading.	\N	\N	+97165500000	+971504567890	info@shjauto.ae	\N	Used Car Complex, Industrial Area 18, Sharjah, UAE	SAIF-2024-SHA005	{en,ar,fr,yo}	{Nigeria,Ghana,Tanzania,Uganda,Kenya}	{}	t	\N	4.50	289	pro	\N	\N	2026-07-04 23:34:43.731	2026-07-04 23:34:43.731	\N	country_ae	\N
dealer-sharjah-006	sh-user-006	Al Khail Motors Sharjah	al-khail-motors-sharjah	Family business since 1995. Sharjah Industrial Area 17. Japanese used cars specialist: Toyota, Nissan, Honda, Mazda, Subaru. Fresh Japan and UAE stock available simultaneously. Mechanical inspection included.	\N	\N	+97165345678	+97165345678	trading@alkhail.ae	\N	Industrial Area 17, Block 5, Sharjah, UAE	SAIF-2024-AKM006	{en,ar,ur,hi}	{GCC,"South Asia","East Africa"}	{}	t	\N	4.30	89	starter	\N	\N	2026-07-04 23:34:43.731	2026-07-04 23:34:43.731	\N	country_ae	\N
dealer-sharjah-007	sh-user-007	Shindagha Export Cars	shindagha-export-cars	Chinese brand export specialist in Sharjah. BYD Atto 3, Seal, Han. MG4, ZS EV. Haval Jolion, H6. New stock arriving weekly from China. Best EV prices in UAE for export to Africa. Battery warranty documentation included.	\N	\N	+97165222111	+971557890123	cars@shindaghaexport.ae	https://www.shindaghaexport.ae	Industrial Area 18, Chinese Auto District, Sharjah, UAE	SAIF-2024-SEC007	{en,ar,zh,fr}	{Africa,"South East Asia","Middle East"}	{}	t	\N	4.60	123	pro	\N	\N	2026-07-04 23:34:43.731	2026-07-04 23:34:43.731	\N	country_ae	\N
dealer-sharjah-008	sh-user-008	Nasser Auto Trading	nasser-auto-trading-sharjah	Sharjah-based broker and dealer network connector. 20+ years matching buyers and sellers across the UAE and globally. Sourcing service: tell us what you need, we find it. Commission-based for bulk buyers.	\N	\N	+97165234567	+97165234567	info@nasserauto.ae	\N	King Abdul Aziz Street, Al Nahda, Sharjah, UAE	SAIF-2024-NAT008	{en,ar,ur,fa}	{GCC,Iran,Pakistan,India}	{}	f	\N	4.20	45	starter	\N	\N	2026-07-04 23:34:43.731	2026-07-04 23:34:43.731	\N	country_ae	\N
dealer-sharjah-009	sh-user-009	Emirates Trade Auto	emirates-trade-auto-sharjah	Sharjah multi-brand dealer. New and used vehicles. European brands specialist for local Sharjah market and GCC export. BMW, Audi, Mercedes sourcing from Europe with duty-free import. Competitive rates.	\N	\N	+97165456789	+971505678901	export@emiratestrade.ae	\N	Al Wahda Street, Al Qasimia, Sharjah, UAE	SAIF-2024-ETA009	{en,ar,de,fr}	{GCC,"North Africa",Europe}	{}	t	\N	4.30	67	starter	\N	\N	2026-07-04 23:34:43.731	2026-07-04 23:34:43.731	\N	country_ae	\N
dealer-sharjah-010	sh-user-010	Sharjah Export Motors	sharjah-export-motors	Sharjah-based export company with direct shipping from Sharjah and Khor Fakkan ports. Competitive RoRo rates. Weekly sailings to East Africa, India, Pakistan. Toyota HiAce minibuses specialist — new and used.	\N	\N	+97165901234	+97165901234	sales@sharjahexport.ae	https://www.sharjahexport.ae	Mina Road, Near Sharjah Port, Sharjah, UAE	SAIF-2024-SEM010	{en,ar,ur,sw,hi}	{"East Africa","South Asia","Indian Ocean Islands"}	{}	t	\N	4.50	198	pro	\N	\N	2026-07-04 23:34:43.731	2026-07-04 23:34:43.731	\N	country_ae	\N
\.


--
-- Data for Name: favorites; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.favorites (user_id, vehicle_id, created_at) FROM stdin;
\.


--
-- Data for Name: feature_flag_logs; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.feature_flag_logs (id, flag_id, flag_key, action, old_value, new_value, actor, created_at) FROM stdin;
\.


--
-- Data for Name: feature_flags; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.feature_flags (id, key, name, description, category, icon, is_enabled, rollout_pct, target_plans, target_roles, target_zones, enabled_at, scheduled_on, scheduled_off, tags, notes, created_by, updated_by, created_at, updated_at) FROM stdin;
a3dba53f-f64c-4c41-a0fa-eb72356485b4	marketplace_search	Marketplace Search	Main vehicle search with filters	marketplace	🔍	t	100	{}	{}	{}	\N	\N	\N	{core,launch}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
55ab467b-4c05-414c-95b2-5cef1a259895	vehicle_listings	Vehicle Listings	Browse vehicle cards in marketplace	marketplace	🚗	t	100	{}	{}	{}	\N	\N	\N	{core,launch}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
7a9dbdda-f4b7-4010-9ba4-2ea2464cd70f	price_alerts	Price Drop Alerts	Notify buyers when a vehicle price drops	marketplace	🔔	f	0	{}	{buyer}	{}	\N	\N	\N	{engagement,phase2}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
323e3c49-9a89-4082-a83a-cf12a49e0838	saved_searches	Saved Searches	Buyers can save and rerun their search	marketplace	💾	f	0	{}	{buyer}	{}	\N	\N	\N	{engagement,phase2}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
63e0bfe4-6ccf-4589-9c6b-428f1d6a55ce	compare_vehicles	Compare Vehicles	Side-by-side comparison of up to 4 vehicles	marketplace	⚖️	f	0	{}	{}	{}	\N	\N	\N	{ux,phase2}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
6035bc2f-8de1-4b7c-9dcd-a51774949e3b	featured_listings	Featured / Promoted Listings	Dealers can boost visibility with paid promotion	marketplace	⭐	f	0	{pro,enterprise}	{dealer}	{}	\N	\N	\N	{monetization,phase3}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
f0577174-54b4-4718-8adb-df86b84bf3d4	market_trends	Market Trend Charts	Price history charts on vehicle pages	marketplace	📈	f	0	{}	{}	{}	\N	\N	\N	{analytics,phase3}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
87a7d72b-10e6-4432-8554-7795c6950a5f	export_calculator	Export Cost Calculator	Estimate shipping + duties for export buyers	marketplace	✈️	f	0	{}	{buyer}	{}	\N	\N	\N	{export,phase3}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
2f3cd8be-1dd8-4d7d-9050-2928e1b25ff4	dealer_dashboard	Dealer Dashboard	Full dealer inventory management panel	dealer	📊	t	100	{}	{dealer}	{}	\N	\N	\N	{core,launch}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
ef8c354f-19d3-4e38-a864-3d4ca6a25376	ai_autofill	AI Photo Auto-Fill	AI reads vehicle photos and fills listing form	dealer	🤖	t	100	{}	{dealer}	{}	\N	\N	\N	{ai,launch}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
c588975a-1d17-481c-935b-b5555a07303d	ai_description	AI Description Generator	Generate listing description from vehicle specs	dealer	✍️	t	100	{}	{dealer}	{}	\N	\N	\N	{ai,launch}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
6c880741-7c46-4a19-9997-91e0044c98bf	smart_scan	Smart Scan	QR / VIN / Plate scan to update stock status	dealer	📷	t	100	{pro,enterprise}	{dealer}	{}	\N	\N	\N	{mobile,phase1}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
6c1880d2-35dd-4182-b5ff-12177a3d3fec	one_tap_sale	One-Tap Sale	Mark vehicle sold in 1 tap from scan/widget	dealer	⚡	t	100	{pro,enterprise}	{dealer}	{}	\N	\N	\N	{mobile,phase1}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
28e284be-12dc-47a0-8669-05497e905189	shared_inventory	Shared Inventory Network	Share stock with other dealers in the network	dealer	🔗	t	100	{pro,enterprise}	{dealer}	{}	\N	\N	\N	{collaboration,phase1}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
01205978-1ced-4221-bb69-039a78a80e43	vehicle_timeline	Vehicle Timeline	Full event history per vehicle	dealer	⏱	t	100	{}	{dealer}	{}	\N	\N	\N	{core,launch}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
4535ac13-b419-4eb2-a46a-d73dddb5f4ac	stock_quantity	Multi-Unit Stock Quantity	Manage bulk stock quantities per listing	dealer	📦	t	100	{}	{dealer}	{}	\N	\N	\N	{core,launch}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
2f062408-5fa5-4e16-98fc-447a6cdf4de3	bulk_upload	Bulk Vehicle Import	Import vehicles from Excel / CSV file	dealer	📥	f	0	{pro,enterprise}	{dealer}	{}	\N	\N	\N	{efficiency,phase2}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
b5301aa6-78cd-4c6a-b813-116046823259	crm_module	CRM & Lead Management	Manage buyer leads and follow-ups	dealer	👥	f	0	{pro,enterprise}	{dealer}	{}	\N	\N	\N	{crm,phase2}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
a3c88c39-37f3-4745-af92-fe57c329ce28	whatsapp_integration	WhatsApp Business Integration	Auto-send vehicle info via WhatsApp Business API	dealer	💚	f	0	{pro,enterprise}	{dealer}	{}	\N	\N	\N	{social,phase3}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
3bc6ebb2-f8b2-49f3-b567-dfe02ab653fb	price_intelligence	AI Pricing Intelligence	Compare prices vs live Dubizzle UAE market data	dealer	💡	t	100	{pro,enterprise}	{dealer}	{}	\N	\N	\N	{ai,phase1}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
cd022a66-80f7-4f15-a8eb-82e8ca87a0b9	export_reports	Export Reports (PDF/Excel)	Download inventory and sales reports	dealer	📤	f	0	{pro,enterprise}	{dealer}	{}	\N	\N	\N	{export,phase2}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
1ef16ee5-0b7a-496d-a327-1b967dff8a51	dealer_verification	Verified Dealer Badge	Display verified badge after KYC completion	dealer	✅	f	0	{pro,enterprise}	{dealer}	{}	\N	\N	\N	{trust,phase2}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
ad41f02a-7c39-45e9-861a-96807d7a038e	ios_widget	iOS Home Screen Widget	One-tap sale widget for iPhone home/lock screen	mobile	📱	t	100	{pro,enterprise}	{dealer}	{}	\N	\N	\N	{mobile,phase1}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
619b5d76-4e14-4dc7-9456-435281f4bc1a	android_widget	Android Home Screen Widget	Widget for Android dealers	mobile	🤖	f	0	{pro,enterprise}	{dealer}	{}	\N	\N	\N	{mobile,phase2}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
05718ac6-2047-460b-9694-a957ec742649	pwa_install	Install App Prompt	Prompt users to install DubaiAuto as PWA	mobile	⬇️	f	0	{}	{}	{}	\N	\N	\N	{mobile,phase2}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
b613f115-6257-4814-b937-13131e0cda49	push_notifications	Push Notifications	Browser/mobile push for price alerts and messages	mobile	🔔	f	0	{}	{}	{}	\N	\N	\N	{mobile,engagement,phase2}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
a0d8a435-d75d-49f1-9e6a-2e7dab9042b2	nfc_scan	NFC Tag Scanning	Tap NFC tag on vehicle key to get quick actions	mobile	📡	f	0	{enterprise}	{dealer}	{}	\N	\N	\N	{mobile,phase3}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
e8867c98-cdba-4e9a-bf18-f8bd260516e6	siri_shortcut	Siri / Google Assistant	Voice command: "Mark Land Cruiser as sold"	mobile	🎙	f	0	{enterprise}	{dealer}	{}	\N	\N	\N	{mobile,phase4}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
bdc353b6-e932-49b7-990e-4a077ede7f51	live_activities	iOS Live Activities	Dynamic Island shows active reservations	mobile	✨	f	0	{enterprise}	{dealer}	{}	\N	\N	\N	{mobile,phase4}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
c40351df-452e-46d7-9679-e0e66cf048f3	broker_programme	Broker Programme	Affiliate broker registration and dashboard	broker	🤝	t	100	{}	{}	{}	\N	\N	\N	{monetization,phase1}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
89b250ff-9826-4adc-b973-78f7ea5c37cb	broker_b2b	Broker-to-Broker Network	Sub-broker referral programme and passive income	broker	🔄	f	0	{}	{broker}	{}	\N	\N	\N	{monetization,phase3}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
bd76eaf2-df35-410c-8a1a-04bff74efda2	dealer_affiliate	Dealer Affiliate Programme	Dealers earn by referring other dealers	broker	🏢	t	100	{}	{dealer}	{}	\N	\N	\N	{monetization,phase1}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
467921ea-3b15-484d-84a5-0aa7c50afd43	affiliate_marketplace	Affiliate Banner in Marketplace	Show referred broker info in marketplace	broker	🏷	t	100	{}	{}	{}	\N	\N	\N	{monetization,phase1}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
5448dff5-ce51-4b1f-8743-030ad2aef16d	ai_market_intelligence	AI Market Intelligence	AI analyses portfolio vs Dubizzle market weekly	ai	🧠	f	0	{enterprise}	{dealer}	{}	\N	\N	\N	{ai,phase3}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
3137e71a-d419-4832-b5d2-8e11780c99a1	ai_price_prediction	AI Price Prediction	Predict best selling price based on historical data	ai	🔮	f	0	{enterprise}	{dealer}	{}	\N	\N	\N	{ai,phase3}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
61519c1c-f990-4e1b-a08a-50d8a19a92c1	ai_auto_detect_sold	AI Auto-Detect Sale	AI monitors payment signals and auto-marks sold	ai	🤖	f	0	{enterprise}	{dealer}	{}	\N	\N	\N	{ai,phase4}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
33350cd8-8384-4a4e-8905-0007bff9ed7e	ai_chat_assistant	AI Chat Assistant	Buyer-facing AI chat to help find the right vehicle	ai	💬	f	0	{}	{}	{}	\N	\N	\N	{ai,phase3}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
e393d862-0e25-4ec7-8807-ddc50b0faff1	dealer_reviews	Dealer Reviews	Buyers can rate and review dealers publicly	social	⭐	f	0	{}	{}	{}	\N	\N	\N	{trust,phase2}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
9b78c90f-6fc5-430a-9f08-78864bd9cb2e	user_profiles	Buyer Public Profiles	Buyers have a public profile with history	social	👤	f	0	{}	{buyer}	{}	\N	\N	\N	{community,phase3}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
50ba0923-a3d7-427e-b759-5159b6fd3c97	vehicle_wishlist	Vehicle Wishlist	Buyers save vehicles to a public or private wishlist	social	❤️	f	0	{}	{buyer}	{}	\N	\N	\N	{engagement,phase2}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
3026b293-5a69-48a9-840a-9c8d20fcd4bd	referral_rewards	Buyer Referral Rewards	Buyers earn credits for referring friends	social	🎁	f	0	{}	{buyer}	{}	\N	\N	\N	{growth,phase3}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
edc2bc34-d328-4276-a213-e6268fa37ce6	subscription_plans	SaaS Subscription Plans	Free / Pro / Enterprise dealer plans	payment	💳	t	100	{}	{dealer}	{}	\N	\N	\N	{monetization,launch}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
e1e627bd-f01d-4807-84bc-845829f4afb0	stripe_payments	Stripe Payment Gateway	Accept card payments for subscriptions	payment	💳	f	0	{}	{dealer}	{}	\N	\N	\N	{payment,phase2}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
990e8b96-904b-4ff2-9b29-b7fc38672c63	tabby_bnpl	Tabby Buy Now Pay Later	Split subscription cost over 4 payments	payment	📅	f	0	{}	{dealer}	{}	\N	\N	\N	{payment,phase3}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
5c20fb03-0e4c-4fcc-b185-1c5a9e3593a6	coupon_system	Coupon & Promo Codes	Admin creates discount codes for subscriptions	payment	🎟	t	100	{}	{admin}	{}	\N	\N	\N	{monetization,phase1}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
9968ab0d-7a05-4bbf-9140-583dd7046618	admin_analytics	Admin Analytics Dashboard	Platform-wide stats for super admin	admin	📊	t	100	{}	{admin}	{}	\N	\N	\N	{admin,launch}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
ff34b92a-eed7-4eb3-a159-b9bb80b1745b	feature_flags_admin	Feature Flag Manager	This feature flags control panel	admin	🚩	t	100	{}	{admin}	{}	\N	\N	\N	{admin,launch}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
2cfd695d-7d43-47bc-8ca1-175df2d46c81	audit_logs	Audit Logs	Full audit trail of all admin actions	admin	📋	f	0	{}	{admin}	{}	\N	\N	\N	{admin,phase2}	\N	\N	\N	2026-07-04 23:34:43.321	2026-07-04 23:34:43.321
\.


--
-- Data for Name: free_zones; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.free_zones (id, country_id, name, code, city, is_active, created_at) FROM stdin;
fz_ae_jafza	country_ae	Jebel Ali Free Zone (JAFZA)	jafza	Dubai	t	2026-07-04 23:34:49.589
fz_ae_dmcc	country_ae	Dubai Multi Commodities Centre (DMCC)	dmcc	Dubai	t	2026-07-04 23:34:49.589
fz_ae_dafza	country_ae	Dubai Airport Free Zone (DAFZA)	dafza	Dubai	t	2026-07-04 23:34:49.589
fz_ae_ducamz	country_ae	Dubai Car and Automotive Zone (DUCAMZ)	ducamz	Dubai	t	2026-07-04 23:34:49.589
fz_ae_saif	country_ae	Sharjah Airport International Free Zone	saif	Sharjah	t	2026-07-04 23:34:49.589
fz_ae_hamriyah	country_ae	Hamriyah Free Zone	hamriyah	Sharjah	t	2026-07-04 23:34:49.589
fz_ae_ajman	country_ae	Ajman Free Zone	ajman	Ajman	t	2026-07-04 23:34:49.589
fz_ae_rakez	country_ae	RAK Economic Zone (RAKEZ)	rakez	Ras Al Khaimah	t	2026-07-04 23:34:49.589
fz_ae_fujairah	country_ae	Fujairah Free Zone	fujairah	Fujairah	t	2026-07-04 23:34:49.589
fz_ae_kizad	country_ae	Khalifa Industrial Zone Abu Dhabi (KIZAD)	kizad	Abu Dhabi	t	2026-07-04 23:34:49.589
fz_sa_kaec	country_sa	King Abdullah Economic City (KAEC)	kaec	Rabigh	t	2026-07-04 23:34:49.594
fz_sa_silz	country_sa	Special Integrated Logistics Zone (SILZ)	silz	Riyadh	t	2026-07-04 23:34:49.594
fz_sa_jazan	country_sa	Jazan Economic City	jazan	Jazan	t	2026-07-04 23:34:49.594
fz_sa_raskhair	country_sa	Ras Al-Khair Special Economic Zone	raskhair	Ras Al-Khair	t	2026-07-04 23:34:49.594
fz_qa_rasbufontas	country_qa	Ras Bufontas Free Zone	ras-bufontas	Doha	t	2026-07-04 23:34:49.598
fz_qa_umalhoul	country_qa	Umm Alhoul Free Zone	umm-alhoul	Doha	t	2026-07-04 23:34:49.598
fz_bh_blz	country_bh	Bahrain Logistics Zone (BLZ)	blz	Manama	t	2026-07-04 23:34:49.599
fz_bh_biip	country_bh	Bahrain International Investment Park	biip	Manama	t	2026-07-04 23:34:49.599
fz_kw_kftz	country_kw	Kuwait Free Trade Zone (KFTZ)	kftz	Shuwaikh	t	2026-07-04 23:34:49.6
fz_om_salalah	country_om	Salalah Free Zone	salalah	Salalah	t	2026-07-04 23:34:49.602
fz_om_sohar	country_om	Sohar Free Zone	sohar	Sohar	t	2026-07-04 23:34:49.602
fz_om_duqm	country_om	Duqm Special Economic Zone (SEZAD)	duqm	Duqm	t	2026-07-04 23:34:49.602
fz_om_almazunah	country_om	Al Mazunah Free Zone	al-mazunah	Salalah	t	2026-07-04 23:34:49.602
\.


--
-- Data for Name: invoice_line_items; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.invoice_line_items (id, invoice_id, description, quantity, unit_price, total) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.invoices (id, dealer_id, broker_id, vehicle_id, quote_id, buyer_name, buyer_email, buyer_phone, buyer_country, invoice_number, status, currency, subtotal_aed, discount_aed, tax_aed, total_aed, due_date, paid_at, sent_at, notes, terms, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lead_activities; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.lead_activities (id, lead_id, type, note, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.leads (id, dealer_id, vehicle_id, buyer_name, buyer_email, buyer_phone, buyer_whatsapp, stage, channel, notes, offer_price, source_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: market_analysis_config; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.market_analysis_config (id, enabled, sources, auto_refresh_enabled, refresh_interval_hours, min_confidence_pct, tracked_models, last_refreshed_at, last_refresh_status, last_refresh_summary, ai_model, updated_by, updated_at) FROM stdin;
default	t	["dubizzle", "dubicars"]	t	24	60	[{"make": "Toyota", "model": "Land Cruiser", "year_range": [2020, 2026]}, {"make": "Toyota", "model": "Prado", "year_range": [2022, 2024]}, {"make": "Toyota", "model": "Hilux", "year_range": [2023, 2025]}, {"make": "Toyota", "model": "Fortuner", "year_range": [2024, 2025]}, {"make": "Toyota", "model": "Camry", "year_range": [2025, 2025]}, {"make": "Nissan", "model": "Patrol", "year_range": [2021, 2025]}, {"make": "Mercedes-Benz", "model": "G-Class", "year_range": [2024, 2025]}, {"make": "Mercedes-Benz", "model": "GLE", "year_range": [2024, 2024]}, {"make": "BMW", "model": "X5", "year_range": [2025, 2025]}, {"make": "Ford", "model": "F-150", "year_range": [2025, 2025]}, {"make": "BYD", "model": "Atto 3", "year_range": [2025, 2025]}, {"make": "Tesla", "model": "Model Y", "year_range": [2025, 2025]}, {"make": "Lexus", "model": "LX 600", "year_range": [2024, 2024]}]	\N	never_run	\N	claude-sonnet-4-6	\N	2026-07-04 23:34:43.411
\.


--
-- Data for Name: market_analysis_runs; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.market_analysis_runs (id, triggered_by, status, models_requested, models_updated, models_failed, sources_used, summary, error_detail, started_at, completed_at) FROM stdin;
cmr70w6wj0000rx0ctzrl58ls	auto	failed	1	0	1	["dubizzle", "dubicars"]	\N	401 {"type":"error","error":{"type":"authentication_error","message":"invalid x-api-key"},"request_id":"req_011CchvaD6EDigtQvCypK3WZ"}	2026-07-04 23:58:18.355	2026-07-04 23:58:18.734
cmr70w6wj0001rx0c50nw8qh6	auto	failed	1	0	1	["dubizzle", "dubicars"]	\N	401 {"type":"error","error":{"type":"authentication_error","message":"invalid x-api-key"},"request_id":"req_011CchvaCzmVwKV2yKoBLbXs"}	2026-07-04 23:58:18.356	2026-07-04 23:58:18.715
\.


--
-- Data for Name: market_competitor_data; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.market_competitor_data (id, make, model, year, source, avg_price_aed, min_price_aed, max_price_aed, listing_count, avg_days_listed, demand_level, trend_pct, confidence_pct, source_url, raw_ai_notes, fetched_at, expires_at, is_active) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.notifications (id, dealer_id, broker_id, type, category, title, body, data, read_at, created_at) FROM stdin;
a0116a98-abf7-482f-809f-f0b33b7648af	\N	broker-001	reservation_created	reservation	🔖 Reservation confirmed	Your 24h hold on this vehicle is active.	{"vehicle_id": "3cd9030e-2276-47e9-a76d-c7aabc763db7", "reservation_id": "99487f14-3b19-48bc-9260-bc64057b7c95"}	\N	2026-07-04 23:34:43.911
\.


--
-- Data for Name: plan_features; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.plan_features (id, plan_id, feature_id, enabled, limit_value, created_at) FROM stdin;
da92a36c-7810-4068-a2c3-2e2ccee8a147	plan-free	73c69f5d-966e-4c99-b8d2-bdee5a6fee21	t	\N	2026-07-04 23:34:43.279
7777be12-4d5a-4e9d-a011-7a2f6ecabf11	plan-free	c401805d-5955-4656-80a8-20d9f3a84ecc	t	\N	2026-07-04 23:34:43.279
d3e83c1d-74f5-4d99-a8e1-2347404dafc8	plan-free	97ab08f5-6016-464e-bcee-80abeb0cc78b	t	\N	2026-07-04 23:34:43.279
13651b19-555c-449e-a819-423e8c25d11e	plan-free	6c13a851-52be-48a6-9c6c-cce76e014b2d	t	10	2026-07-04 23:34:43.279
1c29852e-12d4-4c79-aa37-6517633ea2b0	plan-free	04eafda9-737c-40ab-975c-c2483753e944	t	10	2026-07-04 23:34:43.279
09b65b79-768a-4dc6-b55c-01704703657e	plan-free	acc999fb-b1a3-4f6e-8aa2-8ad71698b43f	t	\N	2026-07-04 23:34:43.279
e3929a31-9fc7-4385-bdf7-70e88694f3e5	plan-free	f198e7f3-b3e3-4354-b4dd-f3133a137a23	t	\N	2026-07-04 23:34:43.279
e204ab19-fb79-404e-bbb4-94db1c164bcb	plan-free	3c2fe9be-36c0-4d94-bad0-c705899b4f46	t	\N	2026-07-04 23:34:43.279
c883005f-8ddd-41e3-9434-254e2ea4a8d6	plan-free	a5f81270-1086-4d05-898c-18ed1aecbc52	t	\N	2026-07-04 23:34:43.279
c686cac5-4923-45c0-8156-c25f47fdfab3	plan-free	9f7aa2b5-b3ed-467a-90dd-9f3b22a0d95e	t	\N	2026-07-04 23:34:43.279
e530478d-d94e-429c-9e6b-6c3546e6b925	plan-pro	73c69f5d-966e-4c99-b8d2-bdee5a6fee21	t	\N	2026-07-04 23:34:43.282
082c37b2-aa2d-424d-895a-1c6042c8a51f	plan-pro	c401805d-5955-4656-80a8-20d9f3a84ecc	t	\N	2026-07-04 23:34:43.282
1fcb69be-357b-4b42-a575-aa92e2dad245	plan-pro	97ab08f5-6016-464e-bcee-80abeb0cc78b	t	\N	2026-07-04 23:34:43.282
9014bde8-14c3-4d92-99f1-594e69ccc25c	plan-pro	6c13a851-52be-48a6-9c6c-cce76e014b2d	t	\N	2026-07-04 23:34:43.282
6fc11cbf-36f0-4bc3-b937-eb803974c5be	plan-pro	04eafda9-737c-40ab-975c-c2483753e944	t	\N	2026-07-04 23:34:43.282
8dc2009d-2c22-4ea8-ac79-154d04f28bb2	plan-pro	acc999fb-b1a3-4f6e-8aa2-8ad71698b43f	t	\N	2026-07-04 23:34:43.282
9b7b8b3c-44fa-4bed-8802-38383bfb4518	plan-pro	f198e7f3-b3e3-4354-b4dd-f3133a137a23	t	\N	2026-07-04 23:34:43.282
2ad1f9bb-24cd-4908-a788-b181fc998f3e	plan-pro	3c2fe9be-36c0-4d94-bad0-c705899b4f46	t	\N	2026-07-04 23:34:43.282
9cb6dc3f-3529-486f-984d-524638a4c523	plan-pro	a5f81270-1086-4d05-898c-18ed1aecbc52	t	\N	2026-07-04 23:34:43.282
e18f94c9-2fb9-4f71-9345-2b02a34aa193	plan-pro	9f7aa2b5-b3ed-467a-90dd-9f3b22a0d95e	t	\N	2026-07-04 23:34:43.282
521cf107-b093-4731-b088-fdba4b3e5f05	plan-pro	62e1a6a4-0ad1-4f0d-bcc8-20d15a191dbb	t	\N	2026-07-04 23:34:43.282
bb4ad742-f8c4-43f5-b6bc-0942bfeea69e	plan-pro	f873b265-4a3b-49e2-b7cd-47ea619b7403	t	\N	2026-07-04 23:34:43.282
89e632e6-a59b-4c05-9434-40e79c3c31e5	plan-pro	96c848b1-6b41-4b32-b554-fb9d68213e46	t	\N	2026-07-04 23:34:43.282
ef271f39-697c-4ab7-91fa-3515fc52e400	plan-pro	ca07e6df-5282-4fca-9f11-47322cf45da4	t	\N	2026-07-04 23:34:43.282
f4ec52e4-4a95-47be-9ec4-679684ba2d6e	plan-pro	bd044cdf-1739-4a98-a255-724fff508e82	t	\N	2026-07-04 23:34:43.282
bcf0cefc-f45b-47ee-b4ca-b7889748e347	plan-pro	08df340a-1a8d-4bd7-9d83-36d9958eaafb	t	\N	2026-07-04 23:34:43.282
c438437c-942c-4b09-9aee-e9f9a7be5647	plan-pro	4989b975-5fb4-4be6-a84d-6d0a7a5baa49	t	\N	2026-07-04 23:34:43.282
d8a0b382-6907-4b66-9e96-5e23ba7c1cd9	plan-pro	b5d2998c-a8cc-403a-a319-a7ab208251f1	t	\N	2026-07-04 23:34:43.282
3a45b84d-fe0f-4a5d-9e68-6279f1855575	plan-pro	29e3860a-0bbc-42d9-9ad0-5a50f89f3ecc	t	\N	2026-07-04 23:34:43.282
e6cb6af0-86b7-4f4d-a3e4-f45f67c91519	plan-pro	917fe3d0-99bb-4755-90b6-0c7c49ede720	t	\N	2026-07-04 23:34:43.282
5f2b0178-8f41-439a-bf4c-5145b42a56cb	plan-pro	8abcf53c-41ab-409a-be0b-79f901c67ec6	t	\N	2026-07-04 23:34:43.282
1645d7c1-e58e-479e-8851-8886a0d035be	plan-pro	932c2961-93f0-4fc9-9fa2-42c044850fbd	t	\N	2026-07-04 23:34:43.282
6d41af18-a4b1-4eb4-9d27-c85324dba2d8	plan-pro	6cd52b44-3985-4593-9832-1d25582f5c22	t	\N	2026-07-04 23:34:43.282
f7ce8321-2262-4128-9d0f-0e1067f0ad1b	plan-pro	13c371d4-8520-456f-8eeb-edf20c42ef84	t	\N	2026-07-04 23:34:43.282
b0f7a825-65f6-4cc7-976a-6b6aefe41f3d	plan-pro	4cc3bff4-6eff-453f-9f01-07e2ec92a5e2	t	\N	2026-07-04 23:34:43.282
c47b4f6f-fc52-47bf-a37e-3ee25ec82554	plan-pro	dc5da6ce-999f-4580-b965-5997a41a4431	t	\N	2026-07-04 23:34:43.282
f9fedf30-a99b-4b65-a8c0-d3b161bf9e78	plan-pro	623705d2-29f5-4c93-8d5d-ca65baea5c4c	t	\N	2026-07-04 23:34:43.282
0c35ae4b-ff24-43b1-bde1-780f62e29079	plan-pro	893a1cf4-4aed-4a16-827f-49f7d92ef7ea	t	\N	2026-07-04 23:34:43.282
72dc06fa-553a-4995-af75-f1eba61ac171	plan-pro	a130ac53-0a80-474e-913c-2395c319ba49	t	\N	2026-07-04 23:34:43.282
8f474e79-bd77-4d93-89e5-b67cebc88205	plan-enterprise	73c69f5d-966e-4c99-b8d2-bdee5a6fee21	t	\N	2026-07-04 23:34:43.284
e0f98b61-e4c7-4a76-a4af-5cee96908dde	plan-enterprise	c401805d-5955-4656-80a8-20d9f3a84ecc	t	\N	2026-07-04 23:34:43.284
82f6df49-4c53-4853-be60-228dcc59bfb0	plan-enterprise	97ab08f5-6016-464e-bcee-80abeb0cc78b	t	\N	2026-07-04 23:34:43.284
74cb177f-2db6-40a1-8a54-7eeb4896c001	plan-enterprise	6c13a851-52be-48a6-9c6c-cce76e014b2d	t	\N	2026-07-04 23:34:43.284
7b7b7bac-caaa-4b84-a58d-4843051d0999	plan-enterprise	04eafda9-737c-40ab-975c-c2483753e944	t	\N	2026-07-04 23:34:43.284
b22b364b-7388-4e41-a91a-c1527f05de2f	plan-enterprise	acc999fb-b1a3-4f6e-8aa2-8ad71698b43f	t	\N	2026-07-04 23:34:43.284
48edf7a5-6d2e-4f14-8f63-0b7255ac0ca0	plan-enterprise	f198e7f3-b3e3-4354-b4dd-f3133a137a23	t	\N	2026-07-04 23:34:43.284
154b5427-2a7d-4508-a85a-bfa56aa22ff5	plan-enterprise	3c2fe9be-36c0-4d94-bad0-c705899b4f46	t	\N	2026-07-04 23:34:43.284
bdb1c68b-d919-46c4-adac-e9db46200403	plan-enterprise	a5f81270-1086-4d05-898c-18ed1aecbc52	t	\N	2026-07-04 23:34:43.284
cc35049d-c6da-4f9c-a3a2-ba044cb88e2c	plan-enterprise	9f7aa2b5-b3ed-467a-90dd-9f3b22a0d95e	t	\N	2026-07-04 23:34:43.284
d1f7b7c9-20f8-4b25-9183-7d979fd0633f	plan-enterprise	62e1a6a4-0ad1-4f0d-bcc8-20d15a191dbb	t	\N	2026-07-04 23:34:43.284
cd13034d-ed44-4bc8-8f6f-16f6289b53c3	plan-enterprise	f873b265-4a3b-49e2-b7cd-47ea619b7403	t	\N	2026-07-04 23:34:43.284
2c62c456-11c0-4312-8d65-188c29ae7ab6	plan-enterprise	96c848b1-6b41-4b32-b554-fb9d68213e46	t	\N	2026-07-04 23:34:43.284
1ab8aa1d-c975-4dff-b33a-8eed23c636a8	plan-enterprise	ca07e6df-5282-4fca-9f11-47322cf45da4	t	\N	2026-07-04 23:34:43.284
f2a59768-481d-4d82-8c40-fcc15076b947	plan-enterprise	bd044cdf-1739-4a98-a255-724fff508e82	t	\N	2026-07-04 23:34:43.284
a3f888a0-275d-41d5-8b03-e43edacbbe6a	plan-enterprise	08df340a-1a8d-4bd7-9d83-36d9958eaafb	t	\N	2026-07-04 23:34:43.284
f07c2e97-dfd1-4141-9bcb-f019d76b9219	plan-enterprise	4989b975-5fb4-4be6-a84d-6d0a7a5baa49	t	\N	2026-07-04 23:34:43.284
c2ce508f-080e-4717-98e2-d9ed726e27af	plan-enterprise	b5d2998c-a8cc-403a-a319-a7ab208251f1	t	\N	2026-07-04 23:34:43.284
863cd459-5a1c-45d1-96fe-6a0baa435351	plan-enterprise	29e3860a-0bbc-42d9-9ad0-5a50f89f3ecc	t	\N	2026-07-04 23:34:43.284
171ad0e2-aa51-4042-976e-42e623107ed1	plan-enterprise	917fe3d0-99bb-4755-90b6-0c7c49ede720	t	\N	2026-07-04 23:34:43.284
cc5fcbc5-881d-496d-a0f2-0ed63f91897e	plan-enterprise	8abcf53c-41ab-409a-be0b-79f901c67ec6	t	\N	2026-07-04 23:34:43.284
5f2320e1-2223-4628-b651-defc65402771	plan-enterprise	932c2961-93f0-4fc9-9fa2-42c044850fbd	t	\N	2026-07-04 23:34:43.284
8ac80ce7-a1f5-4af8-8b2e-ec5a53b3f69a	plan-enterprise	6cd52b44-3985-4593-9832-1d25582f5c22	t	\N	2026-07-04 23:34:43.284
7dfbfa13-8de9-469d-9b2c-b53b95768a06	plan-enterprise	13c371d4-8520-456f-8eeb-edf20c42ef84	t	\N	2026-07-04 23:34:43.284
1395ca20-ac94-4635-9c4f-aa2f673c9bb3	plan-enterprise	4cc3bff4-6eff-453f-9f01-07e2ec92a5e2	t	\N	2026-07-04 23:34:43.284
c393b30d-b30c-49b8-9c3e-5055f69ef048	plan-enterprise	dc5da6ce-999f-4580-b965-5997a41a4431	t	\N	2026-07-04 23:34:43.284
960dcea0-480b-40fc-8f8a-53702505f545	plan-enterprise	623705d2-29f5-4c93-8d5d-ca65baea5c4c	t	\N	2026-07-04 23:34:43.284
f8464493-e250-4518-8419-cae18aca4c97	plan-enterprise	893a1cf4-4aed-4a16-827f-49f7d92ef7ea	t	\N	2026-07-04 23:34:43.284
6ee5663b-26a6-455e-8c79-ab10582db550	plan-enterprise	a130ac53-0a80-474e-913c-2395c319ba49	t	\N	2026-07-04 23:34:43.284
dbd1ddbc-d703-4497-b47a-607e9faca1fc	plan-enterprise	de2f2ba6-3ac8-4f1b-9b84-c3f980fc5d8f	t	\N	2026-07-04 23:34:43.284
354cc372-546a-454f-997f-9b7788bac46e	plan-enterprise	f1c57261-945c-42d8-9920-e0052e171408	t	\N	2026-07-04 23:34:43.284
894804f3-0860-4337-bdf2-4ea6a5ac7636	plan-enterprise	700191a8-353d-458c-b473-84e7adca8f95	t	\N	2026-07-04 23:34:43.284
12c1ffde-b351-4ef3-b7b4-602cd835cd1e	plan-enterprise	856fe841-2906-454e-a019-e6615231464c	t	\N	2026-07-04 23:34:43.284
a4cf7a70-c6a8-4dc8-babb-9c8329f68681	plan-enterprise	71ee095c-c9cf-4195-88cd-888bd76d9150	t	\N	2026-07-04 23:34:43.284
ec236131-c407-452c-a480-2433aa194344	plan-enterprise	b1b4c489-3b51-4988-995d-93a3bb4ef60e	t	\N	2026-07-04 23:34:43.284
f5d538db-8749-4544-b9aa-da0d257b0875	plan-enterprise	90679a89-02fa-42f0-ab17-d14ede7f6672	t	\N	2026-07-04 23:34:43.284
81d90d45-aece-4fc2-bd28-6b7dd70ee6ed	plan-enterprise	fb63e962-4ea2-4695-853c-de47421d0e0f	t	\N	2026-07-04 23:34:43.284
23806ce1-c4a2-444c-a9cb-38a26b4b01bb	plan-enterprise	2a54e5ff-a732-401d-bf12-28d6f697c117	t	\N	2026-07-04 23:34:43.284
1c7331c9-3d84-411d-9f84-a8d990438986	plan-enterprise	81f72b1f-6125-42be-9bd1-52fe45474806	t	\N	2026-07-04 23:34:43.284
200c0bf9-4179-400b-b3d8-14c0e5025d83	plan-enterprise	3c63027e-4115-4749-8979-9e4f8b9386bb	t	\N	2026-07-04 23:34:43.284
\.


--
-- Data for Name: plan_limits; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.plan_limits (id, plan_id, limit_key, limit_name, limit_value, created_at) FROM stdin;
06f8d5df-c13d-4a23-abd2-63983fd6f5a0	plan-free	max_vehicles	Max Active Vehicles	20	2026-07-04 23:34:43.287
b60a5933-5f18-43c7-975a-d6580f8e2768	plan-free	max_users	Max Staff Users	1	2026-07-04 23:34:43.287
75746779-d8d1-4e51-8f3e-8197c825daf4	plan-free	ai_scans_monthly	AI Scans per Month	10	2026-07-04 23:34:43.287
468f333a-632c-42c9-914b-9e875df1ec29	plan-free	max_photos	Photos per Vehicle	10	2026-07-04 23:34:43.287
769bbc28-ae95-42f5-a64b-994118b7faa5	plan-free	max_shares	Shared Vehicles	0	2026-07-04 23:34:43.287
4261f740-8fbf-4afe-b8ec-5578d193d49d	plan-pro	max_vehicles	Max Active Vehicles	500	2026-07-04 23:34:43.287
b3c581fe-1710-4032-8a53-6917071f5c9e	plan-pro	max_users	Max Staff Users	5	2026-07-04 23:34:43.287
cd635abc-77a6-489f-b82e-72313c0b1aab	plan-pro	ai_scans_monthly	AI Scans per Month	-1	2026-07-04 23:34:43.287
8fa448ae-31fc-475c-96b8-204ea5599440	plan-pro	max_photos	Photos per Vehicle	30	2026-07-04 23:34:43.287
d9ee4e89-3aee-4b29-93de-4dc0114e2260	plan-pro	max_shares	Shared Vehicles	-1	2026-07-04 23:34:43.287
0d405643-15a2-47db-8a22-0be2c4af216b	plan-enterprise	max_vehicles	Max Active Vehicles	-1	2026-07-04 23:34:43.287
fa8ed018-0f41-437f-aaa5-c6c953062baa	plan-enterprise	max_users	Max Staff Users	-1	2026-07-04 23:34:43.287
0aca6ea8-06ea-4123-b2be-40cfcfedffe7	plan-enterprise	ai_scans_monthly	AI Scans per Month	-1	2026-07-04 23:34:43.287
66ede104-a8f3-4b92-83c8-944bc8cc39f5	plan-enterprise	max_photos	Photos per Vehicle	-1	2026-07-04 23:34:43.287
d7b97192-87b3-4ebe-b816-d80ffe3e62bb	plan-enterprise	max_shares	Shared Vehicles	-1	2026-07-04 23:34:43.287
\.


--
-- Data for Name: price_history; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.price_history (id, vehicle_id, price_aed, changed_by, changed_at) FROM stdin;
\.


--
-- Data for Name: promotions; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.promotions (id, dealer_id, vehicle_id, type, original_price, promo_price, label, starts_at, ends_at, active, created_at) FROM stdin;
\.


--
-- Data for Name: quote_line_items; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.quote_line_items (id, quote_id, description, quantity, unit_price, total) FROM stdin;
\.


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.quotes (id, dealer_id, broker_id, vehicle_id, buyer_name, buyer_email, buyer_phone, buyer_country, quote_number, status, currency, subtotal_aed, discount_pct, discount_aed, tax_pct, tax_aed, total_aed, valid_until, notes, terms, sent_at, accepted_at, rejected_at, converted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: scan_events; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.scan_events (id, vehicle_id, dealer_id, scan_type, scan_data, action_taken, source, lat, lng, scanned_at) FROM stdin;
\.


--
-- Data for Name: share_permissions; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.share_permissions (id, share_id, dealer_id, can_view, can_propose, can_reserve, can_transfer, can_negotiate, starts_at, ends_at, revoked_at, revoked_by, created_at) FROM stdin;
\.


--
-- Data for Name: stock_transactions; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.stock_transactions (id, vehicle_id, dealer_id, txn_type, quantity, quantity_before, quantity_after, note, actor_id, source, occurred_at) FROM stdin;
3c368791-9e9d-4463-b5af-c86965c4b32b	2c99cd74-83b9-42a3-bc4a-2ee2f9ded6d1	dealer-jafza-001	stock_in	5	0	5	Initial stock entry	\N	import	2026-07-04 23:34:43.801
3d0aeb4e-c883-4da4-95cc-1fa8a91e389e	f7afa24d-8a00-48b4-9431-f7c0ee22e218	dealer-jafza-001	stock_in	10	0	10	Initial stock entry	\N	import	2026-07-04 23:34:43.801
ec159b6d-4b06-4796-bf18-8069378124fa	ea906d46-0ab9-44f6-a051-e0b0f759fdae	dealer-dubai-003	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
38ba4f9e-f1a7-4bfa-be9e-1c397540a3f1	d1070bd0-a930-483b-9d7f-c19e3aa310c6	dealer-dubai-012	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
d9c2d670-28bd-43bd-abbf-f2318d6773af	fa499d0c-8ed9-4b88-95b7-cf2187cdc563	dealer-dubai-007	stock_in	20	0	20	Initial stock entry	\N	import	2026-07-04 23:34:43.801
aa635c62-c6e1-4699-bf31-a21edf7e1249	3a9ad8a2-a8d7-498f-b0a1-d03ad86921b5	dealer-dubai-007	stock_in	8	0	8	Initial stock entry	\N	import	2026-07-04 23:34:43.801
9c83d96c-c320-4401-a6ee-d65f9dc1735c	8b834a10-0e03-4f3a-8de4-22a484d10a8a	dealer-dubai-003	stock_in	2	0	2	Initial stock entry	\N	import	2026-07-04 23:34:43.801
a3a3f3e5-aa64-4117-ba25-bd06271685fc	fd448f66-fe5f-4499-95c6-58a397499c8a	dealer-dubai-003	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
c083e1b4-2cf0-4a0a-8141-b2b954df0014	0a7034f3-5474-4959-bbd0-3e3246fb0f31	dealer-dubai-007	stock_in	30	0	30	Initial stock entry	\N	import	2026-07-04 23:34:43.801
b46ed2eb-a9b0-4cb0-86b6-4f2ba1ff9421	60d13bc8-7b6f-4998-9c5f-69ef47f8ccb0	dealer-dubai-007	stock_in	6	0	6	Initial stock entry	\N	import	2026-07-04 23:34:43.801
e8a15e0a-9c20-4c99-9357-fd3e5cfef180	b14d24f4-99c6-40e1-b388-f9a63002d9b3	dealer-dubai-003	stock_in	4	0	4	Initial stock entry	\N	import	2026-07-04 23:34:43.801
0dc8ff81-229d-4cff-b1d6-244f88fac0c2	dd28411c-2c9c-431f-bc6b-8962789c90ed	dealer-dubai-003	stock_in	3	0	3	Initial stock entry	\N	import	2026-07-04 23:34:43.801
9f14eba8-4e55-4391-a53f-afd6899819f3	7805b542-cdbe-421e-bbd9-bcd2068d4166	dealer-dubai-003	stock_in	5	0	5	Initial stock entry	\N	import	2026-07-04 23:34:43.801
99465267-2ea8-43a7-b03f-150ad70cb777	47e041df-1cca-468a-9522-c887550935a7	dealer-dubai-012	stock_in	8	0	8	Initial stock entry	\N	import	2026-07-04 23:34:43.801
58274f31-24b5-48a3-ac38-47b789c27664	b71161ab-f1e7-47da-9dac-664ee6c91b4f	dealer-jafza-001	stock_in	5	0	5	Initial stock entry	\N	import	2026-07-04 23:34:43.801
83c62409-9c03-4072-9534-e605f41f97aa	7fd2bfce-efab-40a0-935c-f02e74e95b36	dealer-dubai-003	stock_in	2	0	2	Initial stock entry	\N	import	2026-07-04 23:34:43.801
3bb1e1ca-0da6-474a-a20d-d4a333d52a54	09530e8c-f5b0-4afc-8972-ae1423549577	dealer-dubai-012	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
8a24584f-ff03-4498-9364-9480d73c1e40	350ba3df-a901-4146-8afa-e07e332cb437	dealer-sharjah-001	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
fdae036f-7ae7-433b-b359-e2c9b42715fb	8302e004-2c27-47e7-9d20-457d545c0407	dealer-dubai-007	stock_in	8	0	8	Initial stock entry	\N	import	2026-07-04 23:34:43.801
3b87e73c-93f7-4fd9-9c01-65fc834f4412	f27b4317-c7b1-4c4d-bada-d11b58283bfc	dealer-dubai-008	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
9c9f7d55-b0c4-48be-a060-e80cec0a60bd	a74b991f-35d4-43a7-a341-32ea980654ba	dealer-dubai-008	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
3cbcd4ce-d4f6-48d7-bf73-ac25b2c800fe	2ff37f58-aff5-4708-8df1-186798d4dda3	dealer-dubai-008	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
62c9e4b9-c5a9-497a-b3d0-a0203d7fbbab	9f9bc0e4-26da-47fc-8abe-4b6de6f5ca31	dealer-dubai-008	stock_in	2	0	2	Initial stock entry	\N	import	2026-07-04 23:34:43.801
b88b860c-358c-4b15-8a4c-0edf32625064	a32a93d4-5f0e-4230-9166-b44ffc7ad614	dealer-dubai-008	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
81a516fd-5a07-4a0a-b659-081d2545addd	b9c660c0-35f8-42ba-8292-1b4c647d2827	dealer-dubai-004	stock_in	2	0	2	Initial stock entry	\N	import	2026-07-04 23:34:43.801
cfb759bc-d4e8-4ef6-be47-5ac4ae41b141	9ef70305-8950-4db5-994d-6a35667fbdd8	dealer-dubai-004	stock_in	3	0	3	Initial stock entry	\N	import	2026-07-04 23:34:43.801
84802cd5-1384-4396-b349-a1c3e4e3c816	10330160-fe46-4556-84b7-875d309f94cb	dealer-dubai-004	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
64365218-01b1-4c3e-9efc-a806c0808a1d	a196e677-b147-49ef-b0a0-cc632b16d4b8	dealer-dubai-006	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
7127f40d-2f21-4bec-8964-63d4231cfe56	403ac4c9-bd33-4400-8bc6-feb997570b7a	dealer-dubai-006	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
dc168b25-4343-491c-bbbd-fe895ad07436	50a86a5a-8ebb-423a-88d9-8bf86159d6d4	dealer-dubai-006	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
0f323136-415c-4636-ade7-f89a891d5c13	6c323335-3a79-4c46-93e0-9aed48c291af	dealer-dubai-010	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
aa7ca66e-cee7-4725-b214-7cf975ff1e82	4b908e5e-22eb-43db-a99d-92eff641cf00	dealer-dubai-010	stock_in	2	0	2	Initial stock entry	\N	import	2026-07-04 23:34:43.801
8b9fc327-0dac-48e0-8934-b16602ede513	93c65022-610c-49c8-b758-53d3ea32a864	dealer-dubai-003	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
d3830169-bcdd-4ba5-8de8-10ae22ca8b53	27ccf09b-dcd9-4f3c-97ca-22801766aa4a	dealer-dubai-010	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
8ea4d412-2714-4fb3-9a8b-071a6dda7257	b694a5a7-bd24-47ff-a296-49b7c0e42e60	dealer-sharjah-001	stock_in	2	0	2	Initial stock entry	\N	import	2026-07-04 23:34:43.801
2c46b18c-d736-4aaa-a91c-3c2dfe236679	e36b6e3b-aac1-41f8-ae31-be463811e6d1	dealer-sharjah-001	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
9b8b560b-6957-41c4-a4bb-13cd2f906f52	54d91553-bfee-4493-b156-13898de7bed4	dealer-dubai-003	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
b32fb8f4-ee4f-4189-b0cc-2d682a01471e	9403f4a3-317d-4493-97ee-c0592fd3f570	dealer-dubai-003	stock_in	8	0	8	Initial stock entry	\N	import	2026-07-04 23:34:43.801
a0fadd2d-85ee-425a-9ab5-c3b807052b74	5714a9a8-f570-477b-8a96-5d034af3d09a	dealer-dubai-003	stock_in	4	0	4	Initial stock entry	\N	import	2026-07-04 23:34:43.801
2707dfdb-848c-40fb-9bde-0188ddeed768	c3660888-5420-40ff-9231-c41973e481a4	dealer-dubai-003	stock_in	3	0	3	Initial stock entry	\N	import	2026-07-04 23:34:43.801
429bd640-2192-4f31-8add-b5c30947c391	ede6deb3-392d-408c-93ff-0f4547320a2b	dealer-dubai-011	stock_in	10	0	10	Initial stock entry	\N	import	2026-07-04 23:34:43.801
634a01cf-f5f0-45ed-af3f-cb2a725aa228	5c50c019-3f0b-4de9-934a-1bfc56edb751	dealer-dubai-011	stock_in	5	0	5	Initial stock entry	\N	import	2026-07-04 23:34:43.801
f631a345-4a01-4879-aff8-50e98a608c17	2cc8e1ee-0d54-4d55-b25d-2b752c175641	dealer-dubai-011	stock_in	15	0	15	Initial stock entry	\N	import	2026-07-04 23:34:43.801
1c6cb84b-d5f9-411a-84a0-0a1b02744f37	1a4f0e9a-59d3-433c-bbae-9c32fec56d28	dealer-dubai-011	stock_in	3	0	3	Initial stock entry	\N	import	2026-07-04 23:34:43.801
1b0fbff6-1ae4-47fe-aec7-f8d5f653b356	f1801b24-8091-4e9d-ae5f-359bb259166f	dealer-dubai-003	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
647bcde7-1118-4b57-9f14-2b02854bb486	e3883903-d086-45b7-83d1-8a694c200668	dealer-dubai-003	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
19490f7d-9264-44da-8eb1-ebba4bd34722	b73a3eeb-4081-42db-ba82-0fba008aa35a	dealer-sharjah-005	stock_in	2	0	2	Initial stock entry	\N	import	2026-07-04 23:34:43.801
bd6c2cf4-25bd-4978-94b8-83a47c5a7c27	660f98d1-3843-48aa-82aa-df26339a7ad4	dealer-sharjah-005	stock_in	3	0	3	Initial stock entry	\N	import	2026-07-04 23:34:43.801
8ae0211a-4dd7-4eec-88e9-3554015e1039	abc5e13e-be1b-450e-8bcc-c4f00bdaf7a6	dealer-sharjah-001	stock_in	1	0	1	Initial stock entry	\N	import	2026-07-04 23:34:43.801
94522303-96e8-4731-b7b8-b4b5fde75ab7	07382ead-6327-48bf-b26e-b611be286ebf	dealer-jafza-002	stock_in	3	0	3	Initial stock entry	\N	import	2026-07-04 23:34:43.801
2a4b3a74-6f29-405b-be3e-c1599bd5cb67	91bf7582-1105-4963-b582-c2433e35422c	dealer-jafza-002	stock_in	2	0	2	Initial stock entry	\N	import	2026-07-04 23:34:43.801
c942c271-5880-4b40-acd8-52926f89b209	7af4fdc0-40b8-476a-93d5-c69d57f1db6f	dealer-jafza-002	stock_in	5	0	5	Initial stock entry	\N	import	2026-07-04 23:34:43.801
edc2ab98-9317-4c19-82ea-70ed7d827cab	3dd72110-0cab-4b0c-b701-962ab4ab93dd	dealer-jafza-002	stock_in	4	0	4	Initial stock entry	\N	import	2026-07-04 23:34:43.801
\.


--
-- Data for Name: subscription_coupons; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.subscription_coupons (id, code, name, discount_type, discount_value, max_uses, current_uses, valid_from, valid_until, min_amount, applicable_plans, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: subscription_features; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.subscription_features (id, key, name, description, icon, category, is_active, is_premium, is_visible, sort_order, created_at) FROM stdin;
73c69f5d-966e-4c99-b8d2-bdee5a6fee21	dealer_profile	Dealer Profile	\N	🏢	core	t	f	t	1	2026-07-04 23:34:43.275
c401805d-5955-4656-80a8-20d9f3a84ecc	public_page	Public Company Page	\N	🌐	core	t	f	t	2	2026-07-04 23:34:43.275
97ab08f5-6016-464e-bcee-80abeb0cc78b	vehicle_listing	Vehicle Listings	\N	🚗	core	t	f	t	3	2026-07-04 23:34:43.275
6c13a851-52be-48a6-9c6c-cce76e014b2d	ai_recognition	AI Vehicle Recognition	\N	🤖	ai	t	f	t	4	2026-07-04 23:34:43.275
04eafda9-737c-40ab-975c-c2483753e944	ai_description	AI Description Generation	\N	✍️	ai	t	f	t	5	2026-07-04 23:34:43.275
acc999fb-b1a3-4f6e-8aa2-8ad71698b43f	vehicle_gallery	Vehicle Photo Gallery	\N	📸	core	t	f	t	6	2026-07-04 23:34:43.275
f198e7f3-b3e3-4354-b4dd-f3133a137a23	marketplace_search	Marketplace Search	\N	🔍	core	t	f	t	7	2026-07-04 23:34:43.275
3c2fe9be-36c0-4d94-bad0-c705899b4f46	buyer_inquiries	Receive Buyer Inquiries	\N	💬	core	t	f	t	8	2026-07-04 23:34:43.275
a5f81270-1086-4d05-898c-18ed1aecbc52	basic_dashboard	Basic Dashboard	\N	📊	core	t	f	t	9	2026-07-04 23:34:43.275
9f7aa2b5-b3ed-467a-90dd-9f3b22a0d95e	email_notifications	Email Notifications	\N	📧	core	t	f	t	10	2026-07-04 23:34:43.275
62e1a6a4-0ad1-4f0d-bcc8-20d15a191dbb	excel_import	Excel Import	\N	📥	import	t	t	t	11	2026-07-04 23:34:43.275
f873b265-4a3b-49e2-b7cd-47ea619b7403	csv_import	CSV Import	\N	📄	import	t	t	t	12	2026-07-04 23:34:43.275
96c848b1-6b41-4b32-b554-fb9d68213e46	bulk_upload	Bulk Vehicle Upload	\N	⬆️	import	t	t	t	13	2026-07-04 23:34:43.275
ca07e6df-5282-4fca-9f11-47322cf45da4	ocr_vin	OCR VIN Detection	\N	🔲	scan	t	t	t	14	2026-07-04 23:34:43.275
bd044cdf-1739-4a98-a255-724fff508e82	qr_scan	QR Code Scan	\N	📱	scan	t	t	t	15	2026-07-04 23:34:43.275
08df340a-1a8d-4bd7-9d83-36d9958eaafb	crm	CRM Module	\N	👥	business	t	t	t	16	2026-07-04 23:34:43.275
4989b975-5fb4-4be6-a84d-6d0a7a5baa49	buyer_management	Buyer Management	\N	🤝	business	t	t	t	17	2026-07-04 23:34:43.275
b5d2998c-a8cc-403a-a319-a7ab208251f1	whatsapp_integration	WhatsApp Business	\N	💚	business	t	t	t	18	2026-07-04 23:34:43.275
29e3860a-0bbc-42d9-9ad0-5a50f89f3ecc	price_alerts	Price Alerts	\N	🔔	alerts	t	t	t	19	2026-07-04 23:34:43.275
917fe3d0-99bb-4755-90b6-0c7c49ede720	promotions	Promotion Campaigns	\N	🎯	marketing	t	t	t	20	2026-07-04 23:34:43.275
8abcf53c-41ab-409a-be0b-79f901c67ec6	inventory_analytics	Inventory Analytics	\N	📈	analytics	t	t	t	21	2026-07-04 23:34:43.275
932c2961-93f0-4fc9-9fa2-42c044850fbd	sales_dashboard	Sales Dashboard	\N	💰	analytics	t	t	t	22	2026-07-04 23:34:43.275
6cd52b44-3985-4593-9832-1d25582f5c22	price_history	Price History	\N	📉	analytics	t	t	t	23	2026-07-04 23:34:43.275
13c371d4-8520-456f-8eeb-edf20c42ef84	export_reports	Export Reports PDF/Excel	\N	📤	export	t	t	t	24	2026-07-04 23:34:43.275
4cc3bff4-6eff-453f-9f01-07e2ec92a5e2	verification_badge	Verified Dealer Badge	\N	✅	trust	t	t	t	25	2026-07-04 23:34:43.275
dc5da6ce-999f-4580-b965-5997a41a4431	seo_optimization	SEO Optimization	\N	🔎	marketing	t	t	t	26	2026-07-04 23:34:43.275
623705d2-29f5-4c93-8d5d-ca65baea5c4c	api_basic	API Basic Access	\N	🔌	api	t	t	t	27	2026-07-04 23:34:43.275
893a1cf4-4aed-4a16-827f-49f7d92ef7ea	shared_inventory	Shared Inventory Network	\N	🔗	collaboration	t	t	t	28	2026-07-04 23:34:43.275
a130ac53-0a80-474e-913c-2395c319ba49	smart_scan	Smart Scan & One-Tap Sale	\N	⚡	collaboration	t	t	t	29	2026-07-04 23:34:43.275
de2f2ba6-3ac8-4f1b-9b84-c3f980fc5d8f	multi_branch	Multi-Branch Management	\N	🏗	enterprise	t	t	t	30	2026-07-04 23:34:43.275
f1c57261-945c-42d8-9920-e0052e171408	multi_currency	Multi-Currency	\N	💱	enterprise	t	t	t	31	2026-07-04 23:34:43.275
700191a8-353d-458c-b473-84e7adca8f95	api_full	Full API Access	\N	⚙️	api	t	t	t	32	2026-07-04 23:34:43.275
856fe841-2906-454e-a019-e6615231464c	erp_integration	ERP Integration	\N	🏭	enterprise	t	t	t	33	2026-07-04 23:34:43.275
71ee095c-c9cf-4195-88cd-888bd76d9150	white_label	White Label	\N	🎨	enterprise	t	t	t	34	2026-07-04 23:34:43.275
b1b4c489-3b51-4988-995d-93a3bb4ef60e	ai_market_intelligence	AI Market Intelligence	\N	🧠	ai	t	t	t	35	2026-07-04 23:34:43.275
90679a89-02fa-42f0-ab17-d14ede7f6672	ai_price_prediction	AI Price Prediction	\N	💡	ai	t	t	t	36	2026-07-04 23:34:43.275
fb63e962-4ea2-4695-853c-de47421d0e0f	workflow_automation	Workflow Automation	\N	🔄	enterprise	t	t	t	37	2026-07-04 23:34:43.275
2a54e5ff-a732-401d-bf12-28d6f697c117	team_permissions	Team Permissions	\N	🔐	enterprise	t	t	t	38	2026-07-04 23:34:43.275
81f72b1f-6125-42be-9bd1-52fe45474806	dedicated_support	Dedicated Support	\N	🎯	support	t	t	t	39	2026-07-04 23:34:43.275
3c63027e-4115-4749-8979-9e4f8b9386bb	sla_priority	SLA Priority	\N	⚡	support	t	t	t	40	2026-07-04 23:34:43.275
\.


--
-- Data for Name: subscription_history; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.subscription_history (id, dealer_id, subscription_id, event_type, from_plan_id, to_plan_id, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: subscription_invoices; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.subscription_invoices (id, subscription_id, dealer_id, invoice_number, status, amount_subtotal, amount_discount, amount_tax, amount_total, currency, billing_cycle, period_start, period_end, paid_at, due_date, stripe_invoice_id, pdf_url, created_at) FROM stdin;
\.


--
-- Data for Name: subscription_payments; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.subscription_payments (id, invoice_id, dealer_id, amount, currency, status, gateway, gateway_payment_id, gateway_response, failure_reason, refunded_at, created_at) FROM stdin;
\.


--
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.subscription_plans (id, name, slug, description, tagline, color, badge, is_active, is_visible, sort_order, price_monthly, price_quarterly, price_yearly, currency, trial_days, stripe_price_monthly_id, stripe_price_yearly_id, created_at, updated_at) FROM stdin;
plan-free	Free	free	Start your journey on DubaiAuto at zero cost.	Perfect for new dealers	#6B7280	\N	t	t	1	0.00	0.00	0.00	AED	0	\N	\N	2026-07-04 23:34:43.273	2026-07-04 23:34:43.273
plan-pro	Pro	pro	Everything a professional dealer needs to grow.	Most popular for active traders	#C1272D	Most Popular	t	t	2	499.00	1299.00	4799.00	AED	0	\N	\N	2026-07-04 23:34:43.273	2026-07-04 23:34:43.273
plan-enterprise	Enterprise	enterprise	Unlimited power for large dealership groups.	For dealer networks & groups	#007A3D	Best Value	t	t	3	1999.00	5499.00	19999.00	AED	0	\N	\N	2026-07-04 23:34:43.273	2026-07-04 23:34:43.273
\.


--
-- Data for Name: subscription_usage; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.subscription_usage (id, dealer_id, usage_key, period_year, period_month, value, reset_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.users (id, email, password_hash, full_name, phone, whatsapp, avatar_url, role, mfa_secret, mfa_enabled, email_verified, preferred_lang, last_login_at, created_at, updated_at) FROM stdin;
dealer-user-001	dealer@demo.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Mohammed Al Rashid	+971501234567	+971501234567	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.021	2026-07-04 23:34:43.021
buyer-user-001	buyer@demo.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Sara Al Mazrouei	\N	\N	\N	buyer	\N	f	t	en	\N	2026-07-04 23:34:43.024	2026-07-04 23:34:43.024
du-user-001	info@alnabooda.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Al Nabooda Automobiles	+97143408000	+97143408000	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.722	2026-07-04 23:34:43.722
du-user-002	sales@alhabtoor.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Al Habtoor Motors	+97143242000	+97143242000	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.722	2026-07-04 23:34:43.722
du-user-003	cars@alain.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Al Ain Class Automobiles	+97142663555	+97142663555	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.722	2026-07-04 23:34:43.722
du-user-004	info@agmc.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	AGMC BMW	+97143430000	+97143430000	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.722	2026-07-04 23:34:43.722
du-user-005	export@manheim.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Manheim Middle East	+97148118000	+97148118000	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.722	2026-07-04 23:34:43.722
du-user-006	info@alfardan.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Al Fardan Automobiles	+97144558555	+97144558555	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.722	2026-07-04 23:34:43.722
du-user-007	sales@premiummotors.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Premier Motors Dubai	+971501234789	+971501234789	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.722	2026-07-04 23:34:43.722
du-user-008	export@gargash.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Gargash Enterprises	+97143377777	+97143377777	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.722	2026-07-04 23:34:43.722
du-user-009	cars@alrostamani.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Al Rostamani Automobiles	+97142954444	+97142954444	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.722	2026-07-04 23:34:43.722
du-user-010	info@emiratesmotors.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Emirates Motors	+97142822000	+97142822000	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.722	2026-07-04 23:34:43.722
du-user-011	sales@autozone.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	AutoZone Dubai	+971554123456	+971554123456	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.722	2026-07-04 23:34:43.722
du-user-012	info@dubaiexportcars.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Dubai Export Cars	+971505678901	+971505678901	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.722	2026-07-04 23:34:43.722
du-user-013	trading@almasaood.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Al Masaood Automobiles	+97126214444	+97126214444	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.722	2026-07-04 23:34:43.722
du-user-014	info@luxurywheels.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Luxury Wheels Dubai	+971558901234	+971558901234	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.722	2026-07-04 23:34:43.722
du-user-015	sales@cars4export.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Cars4Export DMCC	+971506789012	+971506789012	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.722	2026-07-04 23:34:43.722
ja-user-001	export@jafzaauto.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	JAFZA Auto Export	+97148836000	+97148836000	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.724	2026-07-04 23:34:43.724
ja-user-002	info@gulfjapanauto.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Gulf Japan Auto Trading	+971554987654	+971554987654	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.724	2026-07-04 23:34:43.724
ja-user-003	sales@arabianstars.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Arabian Stars Auto	+971507654321	+971507654321	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.724	2026-07-04 23:34:43.724
ja-user-004	cars@mideastexport.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Mid East Auto Export	+97148812345	+97148812345	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.724	2026-07-04 23:34:43.724
ja-user-005	info@pacificmotors.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Pacific Motors JAFZA	+971502345678	+971502345678	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.724	2026-07-04 23:34:43.724
ja-user-006	trading@alwafaauto.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Al Wafa Auto Trading	+97148833444	+97148833444	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.724	2026-07-04 23:34:43.724
ja-user-007	info@continentalauto.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Continental Auto JAFZA	+971555432198	+971555432198	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.724	2026-07-04 23:34:43.724
ja-user-008	export@triangleauto.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Triangle Auto Export	+971508765432	+971508765432	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.724	2026-07-04 23:34:43.724
ja-user-009	info@globalcarstrading.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Global Cars Trading LLC	+97148845678	+97148845678	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.724	2026-07-04 23:34:43.724
ja-user-010	sales@desertauto.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Desert Auto Export JAFZA	+971503456789	+971503456789	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.724	2026-07-04 23:34:43.724
sh-user-001	info@sharjahautomall.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Sharjah Auto Mall	+97165000000	+97165000000	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.725	2026-07-04 23:34:43.725
sh-user-002	cars@almajidauto.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Al Majid Motors Sharjah	+97165444333	+97165444333	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.725	2026-07-04 23:34:43.725
sh-user-003	sales@gulfline.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Gulf Line Auto Trading	+971556789012	+971556789012	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.725	2026-07-04 23:34:43.725
sh-user-004	export@alhamraiauto.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Al Hamraia Auto Sharjah	+97165678901	+97165678901	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.725	2026-07-04 23:34:43.725
sh-user-005	info@shjauto.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	SHJ Auto Export	+971504567890	+971504567890	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.725	2026-07-04 23:34:43.725
sh-user-006	trading@alkhail.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Al Khail Motors	+97165345678	+97165345678	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.725	2026-07-04 23:34:43.725
sh-user-007	cars@shindaghaexport.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Shindagha Export Cars	+971557890123	+971557890123	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.725	2026-07-04 23:34:43.725
sh-user-008	info@nasserauto.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Nasser Auto Trading	+97165234567	+97165234567	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.725	2026-07-04 23:34:43.725
sh-user-009	export@emiratestrade.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Emirates Trade Auto	+971505678901	+971505678901	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.725	2026-07-04 23:34:43.725
sh-user-010	sales@sharjahexport.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Sharjah Export Motors	+97165901234	+97165901234	\N	dealer	\N	f	t	en	\N	2026-07-04 23:34:43.725	2026-07-04 23:34:43.725
broker-user-001	ahmed@dubaiauto.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Ahmed Al Mansouri	+971501234567	+971501234567	\N	broker	\N	f	t	en	\N	2026-07-04 23:34:43.883	2026-07-04 23:34:43.883
admin-user-001	admin@dubaiauto.ae	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMRJbre3kdnXKwjFrw0V.OU3Pu	Platform Admin	\N	\N	\N	admin	\N	f	t	en	\N	2026-07-04 23:34:43.019	2026-07-04 23:34:52.394
\.


--
-- Data for Name: valuation_config; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.valuation_config (id, weight_mileage, weight_year, weight_market_demand, weight_comparable_sales, weight_condition, depreciation_year1, depreciation_year2, depreciation_year3, depreciation_year4plus, mileage_baseline_km, mileage_penalty_pct, excellent_deal_below, good_deal_below, fair_price_below, above_market_below, active_currencies, active_countries, updated_at) FROM stdin;
default	0.200	0.150	0.250	0.300	0.100	0.150	0.120	0.100	0.080	15000	0.020	0.880	0.950	1.050	1.150	{AED,USD,EUR,GBP,NGN}	{UAE,Nigeria,Ghana,Kenya,UK,France}	2026-07-04 23:34:43.367
\.


--
-- Data for Name: vehicle_images; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.vehicle_images (id, vehicle_id, s3_key, cdn_url, thumb_url, is_primary, "position", created_at) FROM stdin;
\.


--
-- Data for Name: vehicle_qr_codes; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.vehicle_qr_codes (id, vehicle_id, qr_token, qr_url, created_at) FROM stdin;
\.


--
-- Data for Name: vehicle_reservations; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.vehicle_reservations (id, vehicle_id, dealer_id, broker_id, reserved_by_name, reserved_by_contact, status, note, expires_at, cancelled_at, converted_at, created_at) FROM stdin;
99487f14-3b19-48bc-9260-bc64057b7c95	3cd9030e-2276-47e9-a76d-c7aabc763db7	dealer-dubai-003	broker-001	Yusuf Bello	+2348012345678	active	\N	2026-07-05 23:34:43.9	\N	\N	2026-07-04 23:34:43.9
\.


--
-- Data for Name: vehicle_shares; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.vehicle_shares (id, vehicle_id, owner_dealer_id, visibility, group_id, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: vehicle_timeline; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.vehicle_timeline (id, vehicle_id, event_type, event_data, actor_id, actor_type, note, occurred_at) FROM stdin;
\.


--
-- Data for Name: vehicle_valuations; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.vehicle_valuations (id, vehicle_id, make, model, year, "trim", mileage_km, estimated_value_aed, value_min_aed, value_max_aed, confidence_score, deal_rating, deal_score, market_demand, demand_score, avg_days_to_sell, price_trend_pct, price_trend_direction, market_score, investment_score, dealer_confidence, export_score, comparable_count, comparable_sources, ai_reasoning, ai_strengths, ai_risks, computed_at, expires_at, is_stale) FROM stdin;
cmr70w77b0003rx0cbddis31i	e89b8d96-69c8-465b-b186-8c9d5d3786d3	Toyota	RAV4	2023	Adventure AWD	22000	106200.00	97704.00	114696.00	52	overpriced	5	medium	55	35	0.00	stable	51	37	98	92	0	{}	2023 Toyota RAV4 is listed at AED 125,000, 18% above the estimated market value of AED 106,200. AI market data pending first refresh.	["Top export vehicle — strong Africa/Asia demand"]	["18% above estimated market — may deter buyers"]	2026-07-04 23:58:18.743	2026-07-05 23:58:18.742	f
cmr70w78g0005rx0c5igrq61p	e89b8d96-69c8-465b-b186-8c9d5d3786d3	Toyota	RAV4	2023	Adventure AWD	22000	106200.00	97704.00	114696.00	52	overpriced	5	medium	55	35	0.00	stable	51	37	98	92	0	{}	2023 Toyota RAV4 is listed at AED 125,000, 18% above the estimated market value of AED 106,200. AI market data pending first refresh.	["Top export vehicle — strong Africa/Asia demand"]	["18% above estimated market — may deter buyers"]	2026-07-04 23:58:18.784	2026-07-05 23:58:18.783	f
\.


--
-- Data for Name: vehicles; Type: TABLE DATA; Schema: public; Owner: dubaiauto
--

COPY public.vehicles (id, dealer_id, vin, make, model, year, generation, "trim", body_type, fuel_type, transmission, engine, horsepower, torque, doors, seats, mileage_km, color_exterior, color_interior, wheels, country_origin, specs, features, price_aed, price_min_aed, price_suggested_aed, negotiable, status, export_eligible, title, description, seo_keywords, ai_confidence, ai_raw_result, duplicate_hash, view_count, favorite_count, es_indexed_at, created_at, updated_at, stock_quantity, plate_number, specs_origin, currency, sold_units) FROM stdin;
f7afa24d-8a00-48b4-9431-f7c0ee22e218	dealer-jafza-001	\N	Toyota	Land Cruiser	2026	\N	GXR V6	SUV	petrol	automatic	4.0L V6 271hp	\N	\N	\N	\N	0	White Pearl	Beige	\N	\N	{}	{}	228000.00	\N	235000.00	t	available	t	2026 Toyota Land Cruiser GXR V6 — JAFZA New Stock	NEW 2026 LC GXR V6, JAFZA. 10 units available. FOB Jebel Ali. Weekly RoRo to West Africa.	\N	\N	\N	\N	3400	312	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	10	\N	GCC	AED	0
ea906d46-0ab9-44f6-a051-e0b0f759fdae	dealer-dubai-003	\N	Toyota	Land Cruiser	2022	\N	GR Sport 3.5TT	SUV	petrol	automatic	3.5L V6 Twin-Turbo 415hp	\N	\N	\N	\N	92618	Nori Green Pearl	Red Leather	\N	\N	{}	{}	269990.00	\N	260000.00	t	available	t	2022 Toyota Land Cruiser GR Sport — 92k km First Owner	LC GR Sport 2022, 92,618 km, GCC spec, first owner, original paint, no accidents. Park Lane Motors Al Quoz.	\N	\N	\N	\N	987	89	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
d1070bd0-a930-483b-9d7f-c19e3aa310c6	dealer-dubai-012	\N	Toyota	Land Cruiser	2022	\N	VXR 5.7 V8	SUV	petrol	automatic	5.7L V8 381hp	\N	\N	\N	\N	136000	White	Beige	\N	\N	{}	{}	259000.00	\N	245000.00	t	available	t	2022 Toyota Land Cruiser VXR V8 — No Paint No Accident	LC VXR 2022, 136,000 km, GCC spec, no paint, no accidents. Full service history. Export eligible.	\N	\N	\N	\N	1234	98	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
fa499d0c-8ed9-4b88-95b7-cf2187cdc563	dealer-dubai-007	\N	Toyota	Land Cruiser 70	2025	\N	Pick-up SC 4x4	Pickup	petrol	manual	4.0L V6 202hp	\N	\N	\N	\N	0	White	Grey	\N	\N	{}	{}	128500.00	\N	135000.00	t	available	t	2025 Toyota LC70 Pickup — Africa Export New	NEW LC70 Pickup 2025, manual 4x4. Most exported Toyota to Africa. 20 units. RoRo from JAFZA weekly.	\N	\N	\N	\N	4200	387	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	20	\N	GCC	AED	0
3a9ad8a2-a8d7-498f-b0a1-d03ad86921b5	dealer-dubai-007	\N	Toyota	Land Cruiser 70	2024	\N	Hardtop 4-Door	SUV	petrol	manual	4.0L V6 202hp	\N	\N	\N	\N	18000	White	Grey	\N	\N	{}	{}	115000.00	\N	122000.00	t	available	t	2024 Toyota LC70 Hardtop 4-Door Manual	LC70 Hardtop 2024, 4-door, manual, 18,000 km. Ideal for mining, oil field, safari. Bulk orders.	\N	\N	\N	\N	1890	156	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	8	\N	GCC	AED	0
8b834a10-0e03-4f3a-8de4-22a484d10a8a	dealer-dubai-003	\N	Toyota	Prado	2024	\N	VXL 4.0L	SUV	petrol	automatic	4.0L V6 282hp	\N	\N	\N	\N	8000	Pearl White	Beige	\N	\N	{}	{}	155000.00	\N	162000.00	t	available	t	2024 Toyota Prado VXL 4.0L — Full Options	Prado VXL 2024, 4.0L V6, 8,000 km. Panoramic roof, JBL, 3rd row, LED, GCC. Single owner.	\N	\N	\N	\N	1650	134	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	2	\N	GCC	AED	0
fd448f66-fe5f-4499-95c6-58a397499c8a	dealer-dubai-003	\N	Toyota	Prado	2023	\N	TXL	SUV	petrol	automatic	4.0L V6 282hp	\N	\N	\N	\N	42000	Grey	Beige	\N	\N	{}	{}	118000.00	\N	112000.00	t	available	t	2023 Toyota Prado TXL — Low Price Export	Prado TXL 2023, 42,000 km, GCC spec, clean. Export ready.	\N	\N	\N	\N	890	67	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
0a7034f3-5474-4959-bbd0-3e3246fb0f31	dealer-dubai-007	\N	Toyota	Hilux	2025	\N	Revo DC 2.8 Diesel	Pickup	diesel	manual	2.8L 204hp Turbo Diesel	\N	\N	\N	\N	0	White	Black	\N	\N	{}	{}	92000.00	\N	98000.00	t	available	t	2025 Toyota Hilux Revo 2.8D DC — New Africa Export	NEW Hilux Revo 2025, diesel, double cab, 4x4. Top export pickup. 30 units. RoRo weekly.	\N	\N	\N	\N	2100	198	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	30	\N	GCC	AED	0
60d13bc8-7b6f-4998-9c5f-69ef47f8ccb0	dealer-dubai-007	\N	Toyota	Hilux	2024	\N	GLX DC Petrol	Pickup	petrol	automatic	2.7L 164hp	\N	\N	\N	\N	22000	White	Grey	\N	\N	{}	{}	78000.00	\N	82000.00	t	available	t	2024 Toyota Hilux GLX Automatic — Export Popular	Hilux GLX 2024, auto, 22,000 km. Popular in Nigeria, Ghana, Kenya. 6 units. Ship from Sharjah.	\N	\N	\N	\N	1340	112	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	6	\N	GCC	AED	0
b14d24f4-99c6-40e1-b388-f9a63002d9b3	dealer-dubai-003	\N	Toyota	Fortuner	2025	\N	EXR 2.7L	SUV	petrol	automatic	2.7L 164hp	\N	\N	\N	\N	5000	White	Beige	\N	\N	{}	{}	98000.00	\N	105000.00	t	available	t	2025 Toyota Fortuner EXR — Export to East Africa	Fortuner 2025, 5,000 km, GCC spec. High demand Tanzania, Uganda, Kenya. 4 units available.	\N	\N	\N	\N	1230	98	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	4	\N	GCC	AED	0
dd28411c-2c9c-431f-bc6b-8962789c90ed	dealer-dubai-003	\N	Toyota	Camry	2025	\N	SE 2.5L	Sedan	petrol	automatic	2.5L 209hp	\N	\N	\N	\N	3000	Midnight Black	Black	\N	\N	{}	{}	92000.00	\N	96000.00	t	available	f	2025 Toyota Camry SE 2.5 — Family Sedan	Camry SE 2025, 2.5L, 3,000 km. LED, Apple CarPlay, 18" alloys. GCC spec.	\N	\N	\N	\N	876	65	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	3	\N	GCC	AED	0
7805b542-cdbe-421e-bbd9-bcd2068d4166	dealer-dubai-003	\N	Toyota	Corolla	2025	\N	SE 2.0L	Sedan	petrol	automatic	2.0L 172hp	\N	\N	\N	\N	6000	Silver	Black	\N	\N	{}	{}	72000.00	\N	76000.00	t	available	f	2025 Toyota Corolla SE 2.0L — Best Seller	Corolla SE 2025, 8,000 km. UAE most reliable daily driver.	\N	\N	\N	\N	654	45	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	5	\N	GCC	AED	0
47e041df-1cca-468a-9522-c887550935a7	dealer-dubai-012	\N	Toyota	HiAce	2024	\N	High Roof GL 13-seat	Van	diesel	manual	2.8L 144hp Diesel	\N	\N	\N	\N	28000	White	Grey	\N	\N	{}	{}	72000.00	\N	76000.00	t	available	t	2024 Toyota HiAce 13-Seat Diesel — Export Asia/Africa	HiAce 13-seat 2024, diesel, 28,000 km. Top export van to Pacific Islands, East Africa, South Asia.	\N	\N	\N	\N	1670	145	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	8	\N	GCC	AED	0
b71161ab-f1e7-47da-9dac-664ee6c91b4f	dealer-jafza-001	\N	Nissan	Patrol	2024	\N	Platinum V8	SUV	petrol	automatic	5.6L V8 400hp	\N	\N	\N	\N	0	White	Beige	\N	\N	{}	{}	239900.00	\N	245000.00	t	available	t	2024 Nissan Patrol Platinum V8 — JAFZA New	NEW Patrol Platinum V8 2024, JAFZA. GCC spec. 5 units. Export West Africa weekly.	\N	\N	\N	\N	2100	198	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	5	\N	GCC	AED	0
7fd2bfce-efab-40a0-935c-f02e74e95b36	dealer-dubai-003	\N	Nissan	Patrol	2023	\N	SE	SUV	petrol	automatic	4.0L V6 272hp	\N	\N	\N	\N	9000	White	Beige	\N	\N	{}	{}	204900.00	\N	210000.00	t	available	t	2023 Nissan Patrol SE — 9km Near New — Jebel Ali	Patrol SE 2023, GCC, 9,000 km. Near new condition. Jebel Ali dealer. Great value.	\N	\N	\N	\N	1450	123	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	2	\N	GCC	AED	0
09530e8c-f5b0-4afc-8972-ae1423549577	dealer-dubai-012	\N	Nissan	Patrol	2022	\N	SE	SUV	petrol	automatic	4.0L V6 272hp	\N	\N	\N	\N	53000	White	Grey	\N	\N	{}	{}	199000.00	\N	192000.00	t	available	t	2022 Nissan Patrol SE 53k — Export Ready	Patrol SE 2022, 53,000 km, GCC, no accidents. Export from Ras Al Khor.	\N	\N	\N	\N	987	76	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
350ba3df-a901-4146-8afa-e07e332cb437	dealer-sharjah-001	\N	Nissan	Patrol	2021	\N	XE	SUV	petrol	automatic	4.0L V6 272hp	\N	\N	\N	\N	108638	Silver	Grey	\N	\N	{}	{}	199000.00	\N	188000.00	t	available	t	2021 Nissan Patrol XE — Al Quoz Dubai — Low Price	Patrol XE 2021, 108,638 km, GCC, Al Quoz dealer. Accident free. Export eligible.	\N	\N	\N	\N	876	67	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
8302e004-2c27-47e7-9d20-457d545c0407	dealer-dubai-007	\N	Nissan	Navara	2025	\N	SE Double Cab	Pickup	diesel	manual	2.5L dCi 190hp	\N	\N	\N	\N	4000	White	Black	\N	\N	{}	{}	88000.00	\N	95000.00	t	available	t	2025 Nissan Navara SE Diesel 4x4 Double Cab	Navara 2025, diesel, 4x4. Popular Africa export. 8 units available.	\N	\N	\N	\N	1230	98	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	8	\N	GCC	AED	0
f27b4317-c7b1-4c4d-bada-d11b58283bfc	dealer-dubai-008	\N	Mercedes-Benz	GLE	2022	\N	GLE 53 AMG 4Matic	SUV	petrol	automatic	3.0L Inline-6 Mild Hybrid 435hp	\N	\N	\N	\N	59928	Selenite Grey	Black	\N	\N	{}	{}	259000.00	\N	268000.00	t	available	f	2022 Mercedes-Benz GLE 53 AMG — Al Quoz — GCC	GLE 53 AMG 2022, 59,928 km, GCC, full options. Burmester, panoramic, 22" AMG wheels.	\N	\N	\N	\N	1560	134	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
a74b991f-35d4-43a7-a341-32ea980654ba	dealer-dubai-008	\N	Mercedes-Benz	G-Class	2025	\N	G 63 AMG	SUV	petrol	automatic	4.0L V8 BiTurbo 585hp	\N	\N	\N	\N	2000	Obsidian Black	Full Black Nappa	\N	\N	{}	{}	695000.00	\N	712000.00	t	available	f	2025 Mercedes-Benz G63 AMG — Gargash Official	G63 AMG 2025, 2,000 km, Gargash service history. Full carbon package, Manufaktur.	\N	\N	\N	\N	2340	234	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
2ff37f58-aff5-4708-8df1-186798d4dda3	dealer-dubai-008	\N	Mercedes-Benz	E-Class	2024	\N	E 300 AMG Line	Sedan	petrol	automatic	2.0L Turbo 258hp	\N	\N	\N	\N	38000	Polar White	Beige	\N	\N	{}	{}	186999.00	\N	178000.00	t	available	f	2024 Mercedes-Benz E300 AMG Line — GCC Spec	E300 2024, 38,000 km, AMG Line, panoramic. Full service at Gargash.	\N	\N	\N	\N	765	56	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
9f9bc0e4-26da-47fc-8abe-4b6de6f5ca31	dealer-dubai-008	\N	Mercedes-Benz	C-Class	2024	\N	C 300 AMG Line	Sedan	petrol	automatic	2.0L Turbo 258hp	\N	\N	\N	\N	38	Polar White	Black	\N	\N	{}	{}	189000.00	\N	195000.00	t	available	f	2024 Mercedes-Benz C300 AMG — 38km Brand New — Jebel Ali	C300 2024, 38 km only! Jebel Ali dealer, GCC spec. AMG Line, Night package. 2-year warranty.	\N	\N	\N	\N	878	78	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	2	\N	GCC	AED	0
a32a93d4-5f0e-4230-9166-b44ffc7ad614	dealer-dubai-008	\N	Mercedes-Benz	S-Class	2024	\N	S 500 4Matic L	Sedan	petrol	automatic	3.0L Inline-6 Mild Hybrid 435hp	\N	\N	\N	\N	5500	Obsidian Black	Nappa Mahogany	\N	\N	{}	{}	498000.00	\N	512000.00	t	available	f	2024 Mercedes-Benz S500 4Matic L Long Wheelbase	S500 L 2024, 5,500 km. Executive rear, Burmester 3D, Energizing. UAE official.	\N	\N	\N	\N	987	98	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
b9c660c0-35f8-42ba-8292-1b4c647d2827	dealer-dubai-004	\N	BMW	X5	2025	\N	xDrive30d M Sport	SUV	diesel	automatic	3.0L Diesel 298hp	\N	\N	\N	\N	5000	Carbon Black	Black	\N	\N	{}	{}	298000.00	\N	308000.00	t	available	f	2025 BMW X5 30d M Sport — AGMC Official	X5 30d 2025, diesel, 5,000 km. M Sport package, Comfort seats, 21" M wheels. Factory warranty.	\N	\N	\N	\N	987	89	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	2	\N	GCC	AED	0
9ef70305-8950-4db5-994d-6a35667fbdd8	dealer-dubai-004	\N	BMW	5 Series	2025	\N	530i M Sport	Sedan	petrol	automatic	2.0L TwinPower 245hp	\N	\N	\N	\N	4000	Alpine White	Black	\N	\N	{}	{}	218000.00	\N	225000.00	t	available	f	2025 BMW 530i M Sport G60 — New Generation	All-new G60 530i 2025, 4,000 km. Curved display, Harman Kardon, M Sport.	\N	\N	\N	\N	876	67	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	3	\N	GCC	AED	0
10330160-fe46-4556-84b7-875d309f94cb	dealer-dubai-004	\N	BMW	4 Series	2023	\N	420i M Sport Coupe	Coupe	petrol	automatic	2.0L TwinPower 184hp	\N	\N	\N	\N	54000	Alpine White	Black	\N	\N	{}	{}	154999.00	\N	148000.00	t	available	f	2023 BMW 420i M Sport Coupe — 54k km GCC	420i M Sport 2023, 54,000 km. Accident free, full AGMC service. Heated seats.	\N	\N	\N	\N	876	65	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
a196e677-b147-49ef-b0a0-cc632b16d4b8	dealer-dubai-006	\N	Ferrari	812	2020	\N	812 GTS Convertible	Convertible	petrol	automatic	6.5L V12 789hp	\N	\N	\N	\N	8200	Rosso Corsa	Nero	\N	\N	{}	{}	1849000.00	\N	1890000.00	t	available	f	2020 Ferrari 812 GTS — Dubai Marina — 8,200km	812 GTS 2020, V12 NA 789hp, 8,200 km. Full Ferrari service. Dubai Marina dealer. Stunning.	\N	\N	\N	\N	456	89	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
403ac4c9-bd33-4400-8bc6-feb997570b7a	dealer-dubai-006	\N	Porsche	Cayenne	2019	\N	Cayenne S	SUV	petrol	automatic	2.9L V6 BiTurbo 440hp	\N	\N	\N	\N	35528	White	Black	\N	\N	{}	{}	254900.00	\N	245000.00	t	available	f	2019 Porsche Cayenne S — Jebel Ali — 35k km	Cayenne S 2019, 35,528 km, GCC, full Porsche service. Air suspension, Bose, Pano. Great value.	\N	\N	\N	\N	765	56	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
50a86a5a-8ebb-423a-88d9-8bf86159d6d4	dealer-dubai-006	\N	Range Rover	Range Rover	2023	\N	P400 SE	SUV	petrol	automatic	3.0L Inline-6 Mild Hybrid 400hp	\N	\N	\N	\N	23000	Eiger Grey	Ebony	\N	\N	{}	{}	689000.00	\N	695000.00	t	available	f	2023 Range Rover P400 SE — Dubai Marina — 23k km	Range Rover P400 2023, 23,000 km, GCC. Air suspension, Meridian, 22" wheels. Dubai Marina.	\N	\N	\N	\N	1234	112	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
6c323335-3a79-4c46-93e0-9aed48c291af	dealer-dubai-010	\N	Ram	1500	2023	\N	TRX Crew Cab	Pickup	petrol	automatic	6.2L V8 Supercharged 702hp	\N	\N	\N	\N	68	Billet Silver	Black	\N	\N	{}	{}	229900.00	\N	238000.00	t	available	t	2023 RAM 1500 TRX — Jebel Ali — 68km Near New	RAM TRX 2023, 702hp, 68 km only! Jebel Ali dealer, GCC spec. Most powerful pickup.	\N	\N	\N	\N	1890	178	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
4b908e5e-22eb-43db-a99d-92eff641cf00	dealer-dubai-010	\N	Ford	F-150	2025	\N	Raptor SuperCrew	Pickup	petrol	automatic	3.5L EcoBoost V6 400hp	\N	\N	\N	\N	6000	Rapid Red	Black	\N	\N	{}	{}	298000.00	\N	312000.00	t	available	t	2025 Ford F-150 Raptor — UAE Official Emirates Motors	Raptor 2025, 6,000 km. Fox Racing suspension, 35" tires, 37" available. UAE spec.	\N	\N	\N	\N	1560	145	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	2	\N	GCC	AED	0
93c65022-610c-49c8-b758-53d3ea32a864	dealer-dubai-003	\N	Lexus	GX 460	2022	\N	GX 460 Luxury	SUV	petrol	automatic	4.6L V8 301hp	\N	\N	\N	\N	21414	Nebula Grey Pearl	Ecru	\N	\N	{}	{}	211900.00	\N	205000.00	t	available	t	2022 Lexus GX 460 Luxury — Jebel Ali — 21k km	GX 460 Luxury 2022, 21,414 km, GCC. Mark Levinson, sunroof, cooled seats. Export eligible.	\N	\N	\N	\N	987	89	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
27ccf09b-dcd9-4f3c-97ca-22801766aa4a	dealer-dubai-010	\N	Cadillac	Escalade	2022	\N	Sport Platinum	SUV	petrol	automatic	6.2L V8 420hp	\N	\N	\N	\N	108000	Black Raven	Jet Black	\N	\N	{}	{}	229999.00	\N	215000.00	t	available	t	2022 Cadillac Escalade Sport Platinum — 108k km	Escalade Sport Platinum 2022, 108,000 km. 38" curved OLED, AKG sound. Export ready.	\N	\N	\N	\N	987	89	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
b694a5a7-bd24-47ff-a296-49b7c0e42e60	dealer-sharjah-001	\N	Hyundai	Tucson	2023	\N	1.6T Smart AWD	SUV	petrol	automatic	1.6L Turbo 177hp	\N	\N	\N	\N	7949	Phantom Black	Black	\N	\N	{}	{}	97900.00	\N	102000.00	t	available	f	2023 Hyundai Tucson Smart 1.6T — Jebel Ali — 8k km	Tucson Smart 2023, 7,949 km. Wireless CarPlay, 10.25" screen, digital cluster. GCC spec.	\N	\N	\N	\N	765	56	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	2	\N	GCC	AED	0
e36b6e3b-aac1-41f8-ae31-be463811e6d1	dealer-sharjah-001	\N	Kia	Sorento	2023	\N	EXR V6 7-Seat	SUV	petrol	automatic	3.5L V6 280hp	\N	\N	\N	\N	28000	Snow White Pearl	Beige	\N	\N	{}	{}	118000.00	\N	112000.00	t	available	f	2023 Kia Sorento EXR V6 7-Seat — Full Options	Sorento 2023, V6, 7-seater, 28,000 km. Panoramic, BOSE, nappa. GCC spec.	\N	\N	\N	\N	765	56	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
54d91553-bfee-4493-b156-13898de7bed4	dealer-dubai-003	\N	Honda	Accord	2021	\N	2.0T Sport	Sedan	petrol	automatic	2.0L VTEC Turbo 192hp	\N	\N	\N	\N	48056	Sonic Grey Pearl	Black	\N	\N	{}	{}	94900.00	\N	88000.00	t	available	f	2021 Honda Accord Sport 2.0T — 48k km GCC	Accord Sport 2021, 48,056 km, GCC, Honda service. Honda Sensing, 19" wheels.	\N	\N	\N	\N	654	45	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
9403f4a3-317d-4493-97ee-c0592fd3f570	dealer-dubai-003	\N	Nissan	Sunny	2024	\N	SV	Sedan	petrol	automatic	1.6L 118hp	\N	\N	\N	\N	0	White	Grey	\N	\N	{}	{}	49500.00	\N	52000.00	t	available	f	2024 Nissan Sunny SV — New GCC — Budget Sedan	Nissan Sunny 2024 new, GCC spec. Most affordable reliable sedan. 5-year warranty.	\N	\N	\N	\N	345	23	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	8	\N	GCC	AED	0
5714a9a8-f570-477b-8a96-5d034af3d09a	dealer-dubai-003	\N	Nissan	Kicks	2024	\N	SV	SUV	petrol	automatic	1.6L 117hp	\N	\N	\N	\N	16	Vivid Blue	Black	\N	\N	{}	{}	71900.00	\N	75000.00	t	available	f	2024 Nissan Kicks SV — 16km Near New — Jebel Ali	Kicks SV 2024, 16 km. Crossover, FWD, digital cluster, 8" display. GCC spec.	\N	\N	\N	\N	456	34	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	4	\N	GCC	AED	0
c3660888-5420-40ff-9231-c41973e481a4	dealer-dubai-003	\N	Toyota	RAV4	2024	\N	Adventure AWD	SUV	petrol	automatic	2.5L 203hp	\N	\N	\N	\N	0	Super White	Black	\N	\N	{}	{}	145000.00	\N	150000.00	t	available	f	2024 Toyota RAV4 Adventure AWD — New GCC Stock	RAV4 Adventure 2024, brand new, AWD, 8-speed. Adventure spec, 18" wheels. Ras Al Khor dealer.	\N	\N	\N	\N	876	67	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	3	\N	GCC	AED	0
ede6deb3-392d-408c-93ff-0f4547320a2b	dealer-dubai-011	\N	BYD	Atto 3	2025	\N	Extended Range	SUV	electric	automatic	Single Motor 204hp 60.5kWh	\N	\N	\N	\N	6000	Ski White	Grey	\N	\N	{}	{}	112000.00	\N	118000.00	t	available	t	2025 BYD Atto 3 Extended Range — Export Africa	Atto 3 2025, 480km range, 6,000 km. Fast export to Africa. 10 units. V2L charging.	\N	\N	\N	\N	1234	112	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	10	\N	Chinese	AED	0
5c50c019-3f0b-4de9-934a-1bfc56edb751	dealer-dubai-011	\N	BYD	Seal	2025	\N	Performance AWD	Sedan	electric	automatic	Dual Motor 523hp 82.6kWh	\N	\N	\N	\N	4000	Aurora White	Grey	\N	\N	{}	{}	165000.00	\N	172000.00	t	available	t	2025 BYD Seal AWD — Sports EV UAE Stock	BYD Seal 2025, 523hp, 4,000 km. UAE fastest growing EV. Export popular Europe & Asia.	\N	\N	\N	\N	987	98	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	5	\N	Chinese	AED	0
2cc8e1ee-0d54-4d55-b25d-2b752c175641	dealer-dubai-011	\N	MG	MG4 EV	2025	\N	Luxury 77kWh	Hatchback	electric	automatic	204hp 77kWh	\N	\N	\N	\N	5000	Camden Grey	Black	\N	\N	{}	{}	95000.00	\N	99000.00	t	available	t	2025 MG4 EV Luxury — Bulk Export Stock	MG4 EV 2025, 530km range, 5,000 km. Fast charger, export to Africa. 15 units available.	\N	\N	\N	\N	1560	134	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	15	\N	Chinese	AED	0
1a4f0e9a-59d3-433c-bbae-9c32fec56d28	dealer-dubai-011	\N	Tesla	Model Y	2025	\N	Long Range AWD	SUV	electric	automatic	Dual Motor 518hp 82kWh	\N	\N	\N	\N	4000	Pearl White	Black	\N	\N	{}	{}	192000.00	\N	198000.00	t	available	t	2025 Tesla Model Y Long Range — UAE Spec	Model Y 2025, 533km range, 4,000 km. FSD, OTA, 15" screen. UAE spec. 3 units.	\N	\N	\N	\N	1456	134	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	3	\N	American	AED	0
f1801b24-8091-4e9d-ae5f-359bb259166f	dealer-dubai-003	\N	Audi	Q8	2023	\N	55 TFSI Quattro S Line	SUV	petrol	automatic	3.0L Turbo 340hp	\N	\N	\N	\N	10936	Glacier White Metallic	Black	\N	\N	{}	{}	379000.00	\N	368000.00	t	available	f	2023 Audi Q8 S Line — 10k km — Al Quoz GCC	Q8 55 TFSI 2023, 10,936 km, GCC. S Line, 360 camera, B&O sound, air suspension.	\N	\N	\N	\N	1234	112	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
e3883903-d086-45b7-83d1-8a694c200668	dealer-dubai-003	\N	Audi	A5	2021	\N	45 TFSI Quattro S Line	Coupe	petrol	automatic	2.0L Turbo 265hp	\N	\N	\N	\N	76404	Florett Silver	Black	\N	\N	{}	{}	179000.00	\N	165000.00	t	available	f	2021 Audi A5 S Line Quattro — 76k km GCC — Al Quoz	A5 45 TFSI Coupe 2021, 76,404 km, GCC. S Line, virtual cockpit, B&O, sunroof.	\N	\N	\N	\N	765	56	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
b73a3eeb-4081-42db-ba82-0fba008aa35a	dealer-sharjah-005	\N	Toyota	Land Cruiser	2016	\N	GXR V6	SUV	petrol	automatic	4.0L V6 271hp	\N	\N	\N	\N	208000	White	Beige	\N	\N	{}	{}	160000.00	\N	148000.00	t	available	t	2016 Toyota Land Cruiser GXR — Sharjah SAIF — Export	LC GXR 2016, 208,000 km. Export grade, clean car. Sharjah SAIF Zone. Best price for bulk.	\N	\N	\N	\N	1120	89	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	2	\N	GCC	AED	0
660f98d1-3843-48aa-82aa-df26339a7ad4	dealer-sharjah-005	\N	Nissan	Patrol	2016	\N	SE	SUV	petrol	automatic	4.0L V6 272hp	\N	\N	\N	\N	173000	White	Grey	\N	\N	{}	{}	100000.00	\N	92000.00	t	available	t	2016 Nissan Patrol SE — Sharjah — 173k km Export	Patrol SE 2016, 173,000 km. GCC, clean. Sharjah SAIF Zone export stock. 3 units.	\N	\N	\N	\N	876	67	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	3	\N	GCC	AED	0
abc5e13e-be1b-450e-8bcc-c4f00bdaf7a6	dealer-sharjah-001	\N	Nissan	Patrol	2017	\N	SE	SUV	petrol	automatic	4.0L V6 272hp	\N	\N	\N	\N	90000	Grey	Beige	\N	\N	{}	{}	119500.00	\N	112000.00	t	available	t	2017 Nissan Patrol SE — Sharjah Al Majaz Export	Patrol 2017, 90,000 km. GCC spec. Al Majaz Sharjah. Export eligible.	\N	\N	\N	\N	654	52	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	1	\N	GCC	AED	0
07382ead-6327-48bf-b26e-b611be286ebf	dealer-jafza-002	\N	Mitsubishi	Pajero	2023	\N	Final Edition GLS	SUV	petrol	automatic	3.8L V6 250hp	\N	\N	\N	\N	28000	White Pearl	Beige	\N	\N	{}	{}	132000.00	\N	138000.00	t	available	t	2023 Mitsubishi Pajero Final Edition — Japan Import	Pajero Final Edition 2023, Japan auction grade 4.5, 28,000 km. Last production year. Collector.	\N	\N	\N	\N	1230	112	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	3	\N	Japanese	AED	0
91bf7582-1105-4963-b582-c2433e35422c	dealer-jafza-002	\N	Toyota	Land Cruiser	2022	\N	GX	SUV	petrol	automatic	4.0L V6 271hp	\N	\N	\N	\N	45000	White	Grey	\N	\N	{}	{}	178000.00	\N	168000.00	t	available	t	2022 Toyota LC GX Japan Import — Auction Grade 4	LC GX 2022, Japan auction grade 4, 45,000 km. Fresh import, clean auction sheets.	\N	\N	\N	\N	1450	123	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	2	\N	Japanese	AED	0
7af4fdc0-40b8-476a-93d5-c69d57f1db6f	dealer-jafza-002	\N	Isuzu	D-Max	2024	\N	LS DC 4x4 Diesel	Pickup	diesel	automatic	3.0L Diesel 188hp	\N	\N	\N	\N	8000	White	Black	\N	\N	{}	{}	88000.00	\N	95000.00	t	available	t	2024 Isuzu D-Max LS Diesel 4x4 — JAFZA	D-Max 2024, diesel, 8,000 km. Mining, oil field spec. Africa and Pacific export. 5 units.	\N	\N	\N	\N	1120	98	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	5	\N	GCC	AED	0
3dd72110-0cab-4b0c-b701-962ab4ab93dd	dealer-jafza-002	\N	Toyota	HiAce	2023	\N	Commuter High Roof	Van	diesel	manual	2.8L 144hp Diesel	\N	\N	\N	\N	35000	White	Grey	\N	\N	{}	{}	68000.00	\N	72000.00	t	available	t	2023 Toyota HiAce Commuter HR Diesel — Japan Import	HiAce 2023, Japan import, 35,000 km. 15-seat. Popular Pacific Islands export.	\N	\N	\N	\N	1340	112	\N	2026-07-04 23:34:43.795	2026-07-04 23:34:43.795	4	\N	Japanese	AED	0
da7e6bb6-8fa6-45d5-966b-6c94c95e956f	dealer-dubai-003	\N	Toyota	Land Cruiser	2023	\N	GXR V6	SUV	petrol	automatic	4.0L V6 271hp	\N	\N	\N	\N	45000	Silver Metallic	Beige	\N	\N	{}	{}	198000.00	\N	192000.00	t	available	t	2023 Toyota Land Cruiser GXR 45k km	GXR V6 2023, 45,000 km, accident free, service at Al Futtaim Toyota. Export ready.	\N	\N	\N	\N	987	78	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
741dcbb2-9712-443e-bb17-d9f123abcec7	dealer-dubai-003	\N	Toyota	Land Cruiser	2021	\N	GXR V8	SUV	petrol	automatic	5.7L V8 381hp	\N	\N	\N	\N	78000	White	Beige	\N	\N	{}	{}	178000.00	\N	168000.00	t	available	t	2021 Toyota Land Cruiser GXR V8 — 78k km Export	LC GXR V8 2021, 78,000 km, 2 keys, full service. Strong export demand. Negotiable.	\N	\N	\N	\N	1234	98	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
61d9ac44-4605-4bd0-97b5-788ad3d0546e	dealer-dubai-003	\N	Toyota	Land Cruiser	2020	\N	VXR V8	SUV	petrol	automatic	5.7L V8 381hp	\N	\N	\N	\N	112000	White	Beige	\N	\N	{}	{}	175000.00	\N	162000.00	t	available	t	2020 Toyota Land Cruiser VXR V8 — Export Grade	LC VXR 2020, 112,000 km. GCC spec, clean. Africa export popular. JAFZA delivery available.	\N	\N	\N	\N	1120	89	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	2	\N	GCC	AED	0
9ae7c252-c502-4ca4-aa40-ef855e5c6ec2	dealer-jafza-001	\N	Toyota	Land Cruiser	2023	\N	GXR V6 Export	SUV	petrol	automatic	4.0L V6 271hp	\N	\N	\N	\N	0	White Pearl	Beige	\N	\N	{}	{}	220000.00	\N	228000.00	t	available	t	2023 Toyota LC GXR — JAFZA New Export Stock	New 2023 LC GXR, JAFZA. 5 units. FOB Jebel Ali pricing. Africa RoRo weekly.	\N	\N	\N	\N	2340	212	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	5	\N	GCC	AED	0
2c0445af-bcff-406e-b4c5-f88980ab5d18	dealer-sharjah-001	\N	Toyota	Land Cruiser	2019	\N	GXR V6	SUV	petrol	automatic	4.0L V6 271hp	\N	\N	\N	\N	145000	White	Beige	\N	\N	{}	{}	155000.00	\N	142000.00	t	available	t	2019 Toyota Land Cruiser GXR — Sharjah 145k km	LC GXR 2019, 145,000 km. Well maintained, full service history. Export Sharjah.	\N	\N	\N	\N	876	67	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
f0240297-e5db-49bb-837e-7c5daa673916	dealer-dubai-007	\N	Toyota	Land Cruiser 70	2023	\N	Pick-up 4x4	Pickup	petrol	manual	4.0L V6 202hp	\N	\N	\N	\N	12000	White	Grey	\N	\N	{}	{}	112000.00	\N	118000.00	t	available	t	2023 Toyota LC70 Pickup — 12k km Manual 4x4	LC70 2023, manual, 12,000 km. 3 units. Africa export specialist. Best FOB price.	\N	\N	\N	\N	1560	134	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	3	\N	GCC	AED	0
58e31cd8-1b55-4370-932e-df5ec07f4a8e	dealer-dubai-007	\N	Toyota	Hilux	2023	\N	Revo DC Diesel	Pickup	diesel	manual	2.8L 204hp	\N	\N	\N	\N	8000	White	Black	\N	\N	{}	{}	88000.00	\N	94000.00	t	available	t	2023 Toyota Hilux Revo Diesel — 8k km Export	Hilux Revo 2023, diesel, 8,000 km. 5 units available. RoRo export weekly.	\N	\N	\N	\N	1340	112	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	5	\N	GCC	AED	0
647bb213-de66-458c-9cc6-beda4d382a4b	dealer-dubai-007	\N	Toyota	Hilux	2022	\N	GLX DC Petrol	Pickup	petrol	automatic	2.7L 164hp	\N	\N	\N	\N	42000	White	Grey	\N	\N	{}	{}	72000.00	\N	76000.00	t	available	t	2022 Toyota Hilux GLX Auto — 42k km	Hilux GLX 2022, automatic, 42,000 km. GCC spec, clean. 2 units.	\N	\N	\N	\N	876	67	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	2	\N	GCC	AED	0
7dfcfc15-2bd2-4c3f-9ee5-4732829a17c3	dealer-dubai-003	\N	Toyota	Prado	2022	\N	TXL 4.0L	SUV	petrol	automatic	4.0L V6 282hp	\N	\N	\N	\N	65000	Bronze	Beige	\N	\N	{}	{}	115000.00	\N	108000.00	t	available	t	2022 Toyota Prado TXL — 65k km Single Owner	Prado 2022, 65,000 km, single owner, full Toyota service. Sunroof, JBL.	\N	\N	\N	\N	765	56	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
a9a986b8-fc89-438c-aac1-b0833e274ce3	dealer-dubai-003	\N	Toyota	Prado	2020	\N	VXL	SUV	petrol	automatic	4.0L V6 282hp	\N	\N	\N	\N	88000	White Pearl	Beige	\N	\N	{}	{}	108000.00	\N	98000.00	t	available	t	2020 Toyota Prado VXL — 88k km Export Ready	Prado VXL 2020, 88,000 km, GCC, accident free. Export ready from Dubai.	\N	\N	\N	\N	654	45	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
908440ed-8c41-431c-a032-ac4d86f9ee3f	dealer-dubai-003	\N	Toyota	Fortuner	2023	\N	EXR 2.7	SUV	petrol	automatic	2.7L 164hp	\N	\N	\N	\N	28000	White	Beige	\N	\N	{}	{}	88000.00	\N	92000.00	t	available	t	2023 Toyota Fortuner EXR — 28k km Low Mileage	Fortuner 2023, 28,000 km, GCC spec. 2 units available.	\N	\N	\N	\N	876	67	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	2	\N	GCC	AED	0
2ee849b7-b5f8-46b3-bb76-efa727d1d936	dealer-dubai-003	\N	Toyota	Fortuner	2021	\N	EXR V6	SUV	petrol	automatic	4.0L V6 282hp	\N	\N	\N	\N	72000	Silver	Beige	\N	\N	{}	{}	82000.00	\N	76000.00	t	available	t	2021 Toyota Fortuner EXR V6 — 72k km	Fortuner V6 2021, 72,000 km, GCC. Export popular East Africa.	\N	\N	\N	\N	654	45	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
67b375b3-53e8-4470-bb80-6b3f370473b2	dealer-dubai-003	\N	Toyota	Camry	2024	\N	XSE V6	Sedan	petrol	automatic	3.5L V6 302hp	\N	\N	\N	\N	12000	Midnight Black	Black	\N	\N	{}	{}	108000.00	\N	112000.00	t	available	f	2024 Toyota Camry XSE V6 — Sport Package	Camry XSE V6 2024, 12,000 km. Sport package, 19" wheels, JBL. GCC spec.	\N	\N	\N	\N	765	56	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	2	\N	GCC	AED	0
444a4773-c27d-44ed-bf20-f11d377d44bf	dealer-dubai-003	\N	Nissan	Patrol	2025	\N	Platinum V8 SE	SUV	petrol	automatic	5.6L V8 400hp	\N	\N	\N	\N	2000	White Pearl	Premium Beige	\N	\N	{}	{}	245000.00	\N	252000.00	t	available	t	2025 Nissan Patrol Platinum V8 SE — Near New	Patrol Platinum 2025, 2,000 km, full options, massage seats, TV. Export eligible.	\N	\N	\N	\N	2100	198	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
a61d74c9-0ee3-464c-9eec-a85650bb9c2f	dealer-dubai-003	\N	Nissan	Patrol	2020	\N	SE	SUV	petrol	automatic	4.0L V6 272hp	\N	\N	\N	\N	98000	White	Grey	\N	\N	{}	{}	145000.00	\N	135000.00	t	available	t	2020 Nissan Patrol SE — 98k km Export Grade	Patrol SE 2020, 98,000 km. GCC, 2 keys, full service. Export popular West Africa.	\N	\N	\N	\N	987	78	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
bfe6b291-df83-4bc7-b965-dab9d2af484d	dealer-sharjah-001	\N	Nissan	Patrol	2019	\N	SE	SUV	petrol	automatic	4.0L V6 272hp	\N	\N	\N	\N	122000	White	Beige	\N	\N	{}	{}	128000.00	\N	118000.00	t	available	t	2019 Nissan Patrol SE — Sharjah 122k km Export	Patrol 2019, 122,000 km. SAIF Zone Sharjah. Export stock.	\N	\N	\N	\N	876	67	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	2	\N	GCC	AED	0
5b45122a-0b2c-4f7d-a55f-c039074b2388	dealer-dubai-003	\N	Nissan	Patrol	2018	\N	Platinum V8	SUV	petrol	automatic	5.6L V8 400hp	\N	\N	\N	\N	145000	Black	Black	\N	\N	{}	{}	139000.00	\N	128000.00	t	available	t	2018 Nissan Patrol Platinum V8 — 145k Export	Patrol Platinum 2018, V8, 145,000 km. Nigeria Ghana popular. Priced to move.	\N	\N	\N	\N	765	56	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
28d729e6-ad6a-43b6-8293-ff9f6eef1e12	dealer-dubai-007	\N	Nissan	Navara	2024	\N	SE Double Cab Diesel	Pickup	diesel	manual	2.5L 190hp	\N	\N	\N	\N	6000	White	Black	\N	\N	{}	{}	85000.00	\N	90000.00	t	available	t	2024 Nissan Navara Diesel — 6k km 4x4	Navara 2024, diesel, 6,000 km, 4x4. 3 units. Africa export specialist.	\N	\N	\N	\N	987	78	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	3	\N	GCC	AED	0
52043e33-2006-46a4-95ee-2ac96b336fb8	dealer-dubai-010	\N	GMC	Yukon	2024	\N	SLE	SUV	petrol	automatic	5.3L V8 355hp	\N	\N	\N	\N	18000	White	Jet Black	\N	\N	{}	{}	275000.00	\N	268000.00	t	available	t	2024 GMC Yukon SLE — 18k km GCC	Yukon SLE 2024, V8, 18,000 km. 7-seat, sunroof, Captain chairs. Export ready.	\N	\N	\N	\N	987	89	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
a0fa1997-01d2-4230-9940-e2d7bce4dcb9	dealer-dubai-010	\N	GMC	Yukon XL	2023	\N	Denali	SUV	petrol	automatic	6.2L V8 420hp	\N	\N	\N	\N	32000	Black	Jet Black Leather	\N	\N	{}	{}	310000.00	\N	295000.00	t	available	t	2023 GMC Yukon XL Denali — 32k km Full Size	Yukon XL Denali 2023, V8, 32,000 km. Long wheelbase, massaging seats, Bose.	\N	\N	\N	\N	1120	98	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
4eeab065-66dc-4d13-8d85-bb69aa0bc0f6	dealer-dubai-010	\N	Chevrolet	Tahoe	2024	\N	LTZ	SUV	petrol	automatic	5.3L V8 355hp	\N	\N	\N	\N	22000	White	Dark Espresso	\N	\N	{}	{}	265000.00	\N	258000.00	t	available	t	2024 Chevrolet Tahoe LTZ — 22k km	Tahoe LTZ 2024, V8, 22,000 km. Magnetic Ride Control, Bose 8-speaker.	\N	\N	\N	\N	876	78	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
40acae5c-aa21-4ef7-927b-eccbd5c8ee02	dealer-dubai-010	\N	Chevrolet	Suburban	2022	\N	RST	SUV	petrol	automatic	5.3L V8 355hp	\N	\N	\N	\N	58000	Black	Jet Black	\N	\N	{}	{}	198000.00	\N	188000.00	t	available	t	2022 Chevrolet Suburban RST — 58k km Sport	Suburban RST 2022, V8, 58,000 km. Sport appearance, 22" wheels, 8-seat.	\N	\N	\N	\N	987	89	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
a8a9361c-1674-42d7-b433-ede7d168d204	dealer-dubai-012	\N	Chevrolet	Tahoe	2021	\N	LT	SUV	petrol	automatic	5.3L V8 355hp	\N	\N	\N	\N	88000	White	Jet Black	\N	\N	{}	{}	175000.00	\N	162000.00	t	available	t	2021 Chevrolet Tahoe LT — 88k km Export	Tahoe LT 2021, V8, 88,000 km. Export stock Dubai. Nigeria, Ghana buyers welcome.	\N	\N	\N	\N	876	67	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	2	\N	GCC	AED	0
df90f8cc-3d35-4c9b-9e95-3026b5d74194	dealer-dubai-010	\N	Ford	Expedition	2024	\N	Platinum Max	SUV	petrol	automatic	3.5L EcoBoost V6 400hp	\N	\N	\N	\N	12000	Star White	Platinum	\N	\N	{}	{}	285000.00	\N	295000.00	t	available	t	2024 Ford Expedition Platinum Max — 12k km	Expedition Platinum Max 2024, 12,000 km. Extended wheelbase, massaging seats.	\N	\N	\N	\N	876	78	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
ad7b34d0-e4f1-495d-b05b-9f65295577bb	dealer-dubai-010	\N	Ford	Expedition	2022	\N	Limited	SUV	petrol	automatic	3.5L EcoBoost V6 400hp	\N	\N	\N	\N	55000	Antimatter Blue	Ebony	\N	\N	{}	{}	198000.00	\N	188000.00	t	available	t	2022 Ford Expedition Limited — 55k km	Expedition Limited 2022, 55,000 km. 8-seat, B&O sound, panoramic.	\N	\N	\N	\N	765	56	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
ab4131e3-f147-4679-9a93-42ebf8c8f4d4	dealer-dubai-010	\N	Ford	Bronco	2023	\N	Wildtrak	SUV	petrol	automatic	2.3L EcoBoost 315hp	\N	\N	\N	\N	18000	Eruption Green	Black	\N	\N	{}	{}	188000.00	\N	195000.00	t	available	t	2023 Ford Bronco Wildtrak — 18k km Off-Road	Bronco Wildtrak 2023, 18,000 km. Sasquatch package, 35" tires, hard top.	\N	\N	\N	\N	987	89	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
83cbc7cd-4ce3-4a82-b4ce-db2dfcd3d5d8	dealer-dubai-008	\N	Mercedes-Benz	GLS	2024	\N	GLS 450 AMG Line	SUV	petrol	automatic	3.0L Inline-6 MHEV 367hp	\N	\N	\N	\N	8000	Polar White	Black	\N	\N	{}	{}	398000.00	\N	412000.00	t	available	f	2024 Mercedes-Benz GLS 450 AMG Line — 8k km	GLS 450 2024, 8,000 km. 7-seat flagship SUV, air suspension, Burmester 3D.	\N	\N	\N	\N	1120	98	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
6d4e9cc6-647b-435d-932c-7dc13eb4e29b	dealer-dubai-008	\N	Mercedes-Benz	GLC	2024	\N	GLC 300 AMG Line	SUV	petrol	automatic	2.0L Turbo 258hp	\N	\N	\N	\N	12000	Selenite Grey	Black	\N	\N	{}	{}	225000.00	\N	232000.00	t	available	f	2024 Mercedes-Benz GLC 300 AMG — 12k km	All-new GLC 300 2024, 12,000 km. MBUX 11.9" screen, panoramic, AMG.	\N	\N	\N	\N	876	78	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
78a74e93-a40f-4119-8231-4efe8ebcc442	dealer-dubai-008	\N	Mercedes-Benz	CLA	2024	\N	CLA 220 AMG Line	Coupe	petrol	automatic	2.0L Turbo 190hp	\N	\N	\N	\N	15000	Mountain Grey	Black	\N	\N	{}	{}	175000.00	\N	182000.00	t	available	f	2024 Mercedes-Benz CLA 220 AMG — 15k km	CLA 220 AMG 2024, 15,000 km. AMG Line, Night package, 19" AMG wheels.	\N	\N	\N	\N	765	56	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
7ce65429-bfd3-4c7b-b543-bf2d65f6f53a	dealer-dubai-006	\N	Mercedes-Benz	G-Class	2023	\N	G 500	SUV	petrol	automatic	4.0L V8 422hp	\N	\N	\N	\N	28000	Obsidian Black	Black Leather	\N	\N	{}	{}	448000.00	\N	438000.00	t	available	f	2023 Mercedes-Benz G500 — 28k km Al Fardan	G500 2023, 28,000 km, AMG body kit, 21" AMG wheels. Al Fardan dealer.	\N	\N	\N	\N	1560	134	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
ed4945ca-4306-41a7-a257-ffff10ba95f7	dealer-dubai-004	\N	BMW	X7	2023	\N	xDrive40i M Sport	SUV	petrol	automatic	3.0L Inline-6 340hp	\N	\N	\N	\N	22000	Carbon Black	Cognac	\N	\N	{}	{}	375000.00	\N	362000.00	t	available	f	2023 BMW X7 40i M Sport — 22k km	X7 M Sport 2023, 7-seat, 22,000 km. Sky Lounge panoramic, HUD, Bowers & Wilkins.	\N	\N	\N	\N	987	89	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
5f9cb42f-76bb-4e26-88c2-7e6829f8f5ae	dealer-dubai-004	\N	BMW	X6	2023	\N	M50i	Coupe	petrol	automatic	4.4L V8 530hp	\N	\N	\N	\N	18000	Carbon Black	Black Merino	\N	\N	{}	{}	348000.00	\N	338000.00	t	available	f	2023 BMW X6 M50i — 18k km Sport SAV	X6 M50i 2023, 18,000 km. M suspension, 22" M wheels, Bowers & Wilkins.	\N	\N	\N	\N	876	78	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
85305525-e2ef-44a9-aa45-d382bb3e4f86	dealer-dubai-004	\N	BMW	M4	2023	\N	Competition M xDrive	Coupe	petrol	automatic	3.0L TwinPower Turbo 510hp	\N	\N	\N	\N	12000	Isle of Men Green	Full Merino	\N	\N	{}	{}	348000.00	\N	358000.00	t	available	f	2023 BMW M4 Competition xDrive — 12k km	M4 Competition 2023, 510hp, 12,000 km. M Sport seats, carbon roof, HUD.	\N	\N	\N	\N	765	67	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
9420d805-2fe8-4482-b474-01dc79854eea	dealer-dubai-004	\N	BMW	3 Series	2023	\N	320i M Sport	Sedan	petrol	automatic	2.0L TwinPower 184hp	\N	\N	\N	\N	32000	Alpine White	Black	\N	\N	{}	{}	155000.00	\N	148000.00	t	available	f	2023 BMW 320i M Sport — 32k km GCC	320i M Sport 2023, 32,000 km. M Sport, Harman Kardon, Live Cockpit Pro.	\N	\N	\N	\N	654	45	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
572fbc97-4106-4d9f-8abf-4918ac61d376	dealer-dubai-006	\N	Range Rover	Range Rover Sport	2024	\N	P400 HSE Dynamic	SUV	petrol	automatic	3.0L MHEV 400hp	\N	\N	\N	\N	12000	Santorini Black	Ebony	\N	\N	{}	{}	425000.00	\N	438000.00	t	available	f	2024 Range Rover Sport P400 HSE Dynamic — 12k km	RR Sport P400 2024, 12,000 km. Dynamic pack, 22" wheels, Meridian sound.	\N	\N	\N	\N	1120	98	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
8a762132-93fb-4529-81e9-5d50cb7c79bd	dealer-dubai-006	\N	Range Rover	Defender	2023	\N	90 V8	SUV	petrol	automatic	5.0L V8 525hp	\N	\N	\N	\N	18000	Gondwana Stone	Ebony	\N	\N	{}	{}	448000.00	\N	462000.00	t	available	f	2023 Land Rover Defender 90 V8 — 18k km	Defender 90 V8 2023, 525hp, 18,000 km. Air suspension, off-road pack.	\N	\N	\N	\N	876	78	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
5ea555f8-69b9-417a-b329-53887a446ad9	dealer-dubai-006	\N	Range Rover	Discovery	2024	\N	R-Dynamic S D300	SUV	diesel	automatic	3.0L Diesel 300hp	\N	\N	\N	\N	8000	Eiger Grey	Ebony	\N	\N	{}	{}	278000.00	\N	288000.00	t	available	f	2024 Land Rover Discovery R-Dynamic D300	Discovery D300 2024, diesel, 8,000 km. 7-seat, air suspension, Pivi Pro.	\N	\N	\N	\N	876	78	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
240f0d24-2a96-4852-ac34-f0a64bfbd793	dealer-dubai-006	\N	Porsche	Cayenne	2023	\N	Cayenne S	SUV	petrol	automatic	2.9L V6 BiTurbo 440hp	\N	\N	\N	\N	18000	Mahogany Metallic	Black	\N	\N	{}	{}	348000.00	\N	358000.00	t	available	f	2023 Porsche Cayenne S — 18k km Gargash	Cayenne S 2023, 18,000 km, Sport Chrono, PASM, air suspension. Full Porsche.	\N	\N	\N	\N	876	78	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
3ad6f309-b810-44b6-b504-e88a9522c67d	dealer-dubai-006	\N	Porsche	Panamera	2023	\N	4 E-Hybrid Sport Turismo	Wagon	phev	automatic	2.9L V6 PHEV 462hp	\N	\N	\N	\N	12000	Biscay Blue Metallic	Black	\N	\N	{}	{}	395000.00	\N	408000.00	t	available	f	2023 Porsche Panamera 4 E-Hybrid Sport Turismo	Panamera PHEV 2023, wagon, 12,000 km. 50km EV range. Sport Chrono, Bose.	\N	\N	\N	\N	765	67	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
24f664f4-fefd-453d-83c3-57d4ed512062	dealer-dubai-003	\N	Lexus	LX 600	2024	\N	VIP	SUV	petrol	automatic	3.5L V6 Twin-Turbo 416hp	\N	\N	\N	\N	8000	Sonic Titanium	Chestnut	\N	\N	{}	{}	445000.00	\N	458000.00	t	available	t	2024 Lexus LX 600 VIP — 8k km	LX 600 VIP 2024, 4-seat VIP interior, massage seats, refrigerator. Export eligible.	\N	\N	\N	\N	1230	112	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
a43df1ff-c347-44d1-bb82-82d75234268a	dealer-dubai-003	\N	Lexus	LX 600	2022	\N	Sport	SUV	petrol	automatic	3.5L V6 Twin-Turbo 416hp	\N	\N	\N	\N	45000	Sonic Quartz White	Black	\N	\N	{}	{}	385000.00	\N	368000.00	t	available	t	2022 Lexus LX 600 Sport — 45k km GCC	LX 600 Sport 2022, 45,000 km, GCC spec. Sport tuned suspension, 22" wheels.	\N	\N	\N	\N	987	89	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
366c58fb-af5e-4e53-b817-b1f4b7a43bb8	dealer-dubai-003	\N	Lexus	GX 460	2023	\N	Luxury	SUV	petrol	automatic	4.6L V8 301hp	\N	\N	\N	\N	18000	Starfire Pearl	Ecru	\N	\N	{}	{}	228000.00	\N	235000.00	t	available	t	2023 Lexus GX 460 Luxury — 18k km	GX 460 Luxury 2023, V8, 18,000 km. Mark Levinson 17-speaker, cooled seats.	\N	\N	\N	\N	876	78	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
224846a6-29be-4e57-98e2-534b49618712	dealer-dubai-003	\N	Lexus	ES 350	2024	\N	Premier	Sedan	petrol	automatic	3.5L V6 302hp	\N	\N	\N	\N	12000	Sonic Crystal White	Black	\N	\N	{}	{}	188000.00	\N	195000.00	t	available	f	2024 Lexus ES 350 Premier — 12k km	ES 350 Premier 2024, 12,000 km. Mark Levinson, sunroof, 18" alloys.	\N	\N	\N	\N	765	56	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	2	\N	GCC	AED	0
6703556f-8cc5-4a35-ae21-ae7071fb49f0	dealer-dubai-001	\N	Audi	Q8 e-tron	2024	\N	55 quattro S Line	SUV	electric	automatic	Dual Motor 408hp 114kWh	\N	\N	\N	\N	12000	Chronos Grey	Black	\N	\N	{}	{}	368000.00	\N	378000.00	t	available	f	2024 Audi Q8 e-tron 55 S Line — 12k km	Q8 e-tron 2024, 600km range, 12,000 km. S Line, B&O Premium 3D, virtual mirrors.	\N	\N	\N	\N	765	67	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
93b96ddc-c934-402f-b6b8-6e1e4ae25368	dealer-dubai-001	\N	Audi	Q5	2023	\N	45 TFSI Quattro S Line	SUV	petrol	automatic	2.0L Turbo 249hp	\N	\N	\N	\N	28000	Manhattan Grey	Black	\N	\N	{}	{}	178000.00	\N	172000.00	t	available	f	2023 Audi Q5 45 TFSI S Line — 28k km	Q5 S Line 2023, 28,000 km. Virtual cockpit, panoramic, B&O, 20" wheels.	\N	\N	\N	\N	654	45	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
54b21789-5bbd-41bb-8e2a-a6b23815d7b6	dealer-dubai-001	\N	Audi	A8 L	2022	\N	55 TFSI Quattro	Sedan	petrol	automatic	3.0L Turbo 340hp	\N	\N	\N	\N	52000	Daytona Grey Pearl	Beige	\N	\N	{}	{}	248000.00	\N	235000.00	t	available	f	2022 Audi A8 L 55 TFSI — 52k km Al Quoz	A8 L 2022, 52,000 km. Massage seats, rear entertainment, air suspension.	\N	\N	\N	\N	876	78	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
b8e0ea89-5415-48b6-a334-c0af23464a08	dealer-dubai-010	\N	Cadillac	Escalade	2023	\N	Premium Luxury Platinum ESV	SUV	petrol	automatic	6.2L V8 420hp	\N	\N	\N	\N	28000	Black Raven	Jet Black	\N	\N	{}	{}	358000.00	\N	345000.00	t	available	t	2023 Cadillac Escalade ESV Platinum — 28k km	Escalade ESV Platinum 2023, extended, 28,000 km. 38" OLED, AKG 36-speaker.	\N	\N	\N	\N	1120	98	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
57a93fe1-42b9-4133-8a18-f9c98f038604	dealer-dubai-010	\N	Lincoln	Navigator	2022	\N	Black Label Reserve	SUV	petrol	automatic	3.5L EcoBoost V6 440hp	\N	\N	\N	\N	42000	Monochromatic Black	Black Label	\N	\N	{}	{}	225000.00	\N	212000.00	t	available	t	2022 Lincoln Navigator Black Label — 42k km	Navigator Black Label 2022, 42,000 km. Black Label interior, panoramic, 22" wheels.	\N	\N	\N	\N	876	78	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
ade192be-8651-4df7-ad68-2cc5bb1b7308	dealer-sharjah-001	\N	Hyundai	Palisade	2023	\N	Calligraphy AWD	SUV	petrol	automatic	3.8L V6 291hp	\N	\N	\N	\N	28000	Abyss Black Pearl	Black Nappa	\N	\N	{}	{}	152000.00	\N	158000.00	t	available	f	2023 Hyundai Palisade Calligraphy AWD — 28k km	Palisade Calligraphy 2023, AWD, 8-seat, 28,000 km. Nappa leather, HUD, BOSE.	\N	\N	\N	\N	876	78	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
7128d3c2-2d78-4d73-aeb1-d8d9ca7ecefc	dealer-sharjah-001	\N	Kia	Telluride	2023	\N	SX-Prestige AWD	SUV	petrol	automatic	3.8L V6 291hp	\N	\N	\N	\N	32000	Gravity Grey	Black	\N	\N	{}	{}	152000.00	\N	145000.00	t	available	f	2023 Kia Telluride SX-Prestige AWD — 32k km	Telluride SX-Prestige 2023, 8-seat, 32,000 km. BOSE, heated 2nd row, HUD.	\N	\N	\N	\N	765	56	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
61ea8cd0-f6a7-4114-ab2c-bc1c6d98d79d	dealer-sharjah-001	\N	Kia	Carnival	2023	\N	SX Premium	Van	petrol	automatic	3.5L V6 290hp	\N	\N	\N	\N	22000	Runway Red	Nappa Black	\N	\N	{}	{}	128000.00	\N	122000.00	t	available	f	2023 Kia Carnival SX Premium — 22k km 8-seat	Carnival SX Premium 2023, 8-seat, 22,000 km. Reclining rear seats, BOSE, power doors.	\N	\N	\N	\N	654	45	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	2	\N	GCC	AED	0
040d2d4e-82f3-40ee-806b-a5502d6d22b0	dealer-dubai-003	\N	Hyundai	Tucson	2024	\N	1.6T Ultimate HTRAC AWD	SUV	petrol	automatic	1.6L Turbo 178hp	\N	\N	\N	\N	8000	Sunset Red	Black	\N	\N	{}	{}	118000.00	\N	122000.00	t	available	f	2024 Hyundai Tucson Ultimate AWD — 8k km	Tucson Ultimate AWD 2024, 8,000 km. Panoramic, Bose, heated seats, 19" alloys.	\N	\N	\N	\N	654	45	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	2	\N	GCC	AED	0
ba834315-b55b-4d88-ac95-d01f685ebedb	dealer-dubai-011	\N	BYD	Tang	2024	\N	EV Premium AWD	SUV	electric	automatic	Dual Motor 456hp 108.8kWh	\N	\N	\N	\N	8000	Atlantis Grey	Nappa Brown	\N	\N	{}	{}	198000.00	\N	205000.00	t	available	t	2024 BYD Tang EV Premium AWD — 8k km	Tang EV 2024, 100kWh, 530km range, AWD, 8k km. Panoramic, massage seats, 5-screen.	\N	\N	\N	\N	876	78	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	2	\N	Chinese	AED	0
69ade2db-a921-46cb-b36c-5d5c44161263	dealer-dubai-011	\N	BYD	Han	2024	\N	EV Premium	Sedan	electric	automatic	Dual Motor 517hp 85.4kWh	\N	\N	\N	\N	12000	Jade Green	Black	\N	\N	{}	{}	185000.00	\N	192000.00	t	available	t	2024 BYD Han EV Premium — 12k km	BYD Han EV 2024, 517hp, 12,000 km. 0-100 in 3.9s. Luxury electric sedan. Export growing.	\N	\N	\N	\N	765	67	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	2	\N	Chinese	AED	0
7e781c06-bcb9-45a8-9502-3144561a27e1	dealer-dubai-011	\N	MG	HS	2024	\N	Trophy Turbo AWD	SUV	petrol	automatic	2.0T 261hp	\N	\N	\N	\N	12000	Pearl White	Black	\N	\N	{}	{}	118000.00	\N	122000.00	t	available	t	2024 MG HS Trophy Turbo AWD — 12k km	MG HS Trophy 2024, AWD, 12,000 km. Panoramic, leather, 19" alloys. Export ready.	\N	\N	\N	\N	654	45	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	3	\N	Chinese	AED	0
14b6a44e-563b-4e97-a012-2dfbc80ff9ea	dealer-dubai-011	\N	MG	EHS	2024	\N	PHEV Trophy	SUV	phev	automatic	1.5T PHEV 258hp	\N	\N	\N	\N	8000	Camden Grey	Black	\N	\N	{}	{}	138000.00	\N	142000.00	t	available	t	2024 MG EHS PHEV Trophy — 8k km Plug-In Hybrid	MG EHS PHEV 2024, 60km EV range, 8,000 km. Lowest running cost SUV in UAE.	\N	\N	\N	\N	765	56	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	2	\N	Chinese	AED	0
40fdf80e-1830-435c-995f-9c1fffd346d7	dealer-dubai-011	\N	Tesla	Model 3	2024	\N	Long Range AWD	Sedan	electric	automatic	Dual Motor 358hp 82kWh	\N	\N	\N	\N	8000	Pearl White	Black	\N	\N	{}	{}	178000.00	\N	185000.00	t	available	t	2024 Tesla Model 3 Long Range AWD — Highland	New Model 3 Highland 2024, 8,000 km. 629km range, FSD available, OTA updates.	\N	\N	\N	\N	987	89	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	2	\N	American	AED	0
4cc14f6d-4e4a-45e2-9c2e-fc85924079db	dealer-jafza-002	\N	Mitsubishi	L200	2025	\N	Triton Athlete DC	Pickup	diesel	automatic	2.4L Diesel 181hp	\N	\N	\N	\N	5000	White Diamond	Black	\N	\N	{}	{}	92000.00	\N	98000.00	t	available	t	2025 Mitsubishi L200 Triton Athlete DC — 5k km	L200 Triton 2025, diesel auto, 5,000 km. Tanzania, Uganda, Kenya popular. 3 units.	\N	\N	\N	\N	876	78	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	3	\N	Japanese	AED	0
1b9840c5-6619-4401-a306-1b36e39fc0be	dealer-jafza-002	\N	Mitsubishi	Pajero	2022	\N	GLS Mid	SUV	petrol	automatic	3.8L V6 250hp	\N	\N	\N	\N	42000	White Pearl	Beige	\N	\N	{}	{}	118000.00	\N	112000.00	t	available	t	2022 Mitsubishi Pajero GLS Mid — 42k km Japan Import	Pajero GLS 2022, Japan import, grade 4, 42,000 km. Ideal Africa/Asia export.	\N	\N	\N	\N	765	56	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	2	\N	Japanese	AED	0
cfa03754-f3ba-4d04-ad29-048af140af59	dealer-dubai-006	\N	Rolls-Royce	Cullinan	2022	\N	Black Badge	SUV	petrol	automatic	6.75L V12 BiTurbo 600hp	\N	\N	\N	\N	18000	Forester Brown	Black	\N	\N	{}	{}	2450000.00	\N	2580000.00	t	available	f	2022 Rolls-Royce Cullinan Black Badge — 18k km	Cullinan Black Badge 2022, 18,000 km. Darkened brightware, 23" alloys, starlight.	\N	\N	\N	\N	345	67	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
41bb2e8e-f4ea-4332-bbfc-dc30dd87f898	dealer-dubai-006	\N	Lamborghini	Urus S	2023	\N	Urus S	SUV	petrol	automatic	4.0L V8 BiTurbo 666hp	\N	\N	\N	\N	12000	Bianco Monocerus	Black Alcantara	\N	\N	{}	{}	875000.00	\N	895000.00	t	available	f	2023 Lamborghini Urus S — 12k km Al Fardan	Urus S 2023, 666hp, 12,000 km. Carbon pack, titanium exhaust, carbon ceramics.	\N	\N	\N	\N	456	78	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
68973741-f939-4379-89e4-3246c6f7a6b7	dealer-dubai-006	\N	Bentley	Flying Spur	2022	\N	W12 Mulliner	Sedan	petrol	automatic	6.0L W12 635hp	\N	\N	\N	\N	22000	White Sand	Linen/Claret	\N	\N	{}	{}	985000.00	\N	1020000.00	t	available	f	2022 Bentley Flying Spur Mulliner W12 — 22k km	Flying Spur Mulliner 2022, W12, 22,000 km. Mulliner driving spec, 22" alloys, rear screens.	\N	\N	\N	\N	345	56	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
69871577-8087-4f40-b675-b28d663f8932	dealer-dubai-012	\N	Toyota	Land Cruiser	2008	\N	GXR V8	SUV	petrol	automatic	4.7L V8 238hp	\N	\N	\N	\N	188000	White	Beige	\N	\N	{}	{}	45000.00	\N	42000.00	t	available	t	2008 Toyota Land Cruiser GXR V8 — Export Grade	LC GXR 2008, V8, 188,000 km. Running condition, export grade. West Africa popular.	\N	\N	\N	\N	654	45	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	3	\N	GCC	AED	0
2f3fa970-242f-4e14-ac08-24fd9da11356	dealer-sharjah-005	\N	Toyota	Land Cruiser	2012	\N	GXR V6	SUV	petrol	automatic	4.0L V6 271hp	\N	\N	\N	\N	162000	White	Beige	\N	\N	{}	{}	62000.00	\N	58000.00	t	available	t	2012 Toyota Land Cruiser GXR — 162k km Export	LC GXR 2012, 162,000 km. Export from Sharjah. 2 units. Nigeria, Congo buyers.	\N	\N	\N	\N	543	34	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	2	\N	GCC	AED	0
4dccf0e6-372b-40c0-a909-5002118c99c5	dealer-sharjah-005	\N	Nissan	Patrol	2014	\N	SE	SUV	petrol	automatic	4.0L V6 272hp	\N	\N	\N	\N	134000	White	Beige	\N	\N	{}	{}	78000.00	\N	72000.00	t	available	t	2014 Nissan Patrol SE — 134k km Sharjah Export	Patrol SE 2014, 134,000 km, GCC spec. Sharjah SAIF Zone. Export ready.	\N	\N	\N	\N	543	34	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	2	\N	GCC	AED	0
2c99cd74-83b9-42a3-bc4a-2ee2f9ded6d1	dealer-jafza-001	\N	Toyota	Land Cruiser	2026	\N	VXR 3.5TT Hybrid	SUV	hybrid	automatic	3.5L V6 Twin-Turbo Hybrid 409hp	\N	\N	\N	\N	10	Attitude Black Mica	Beige	\N	\N	{}	{}	415000.00	\N	425000.00	t	sold	t	2026 Toyota Land Cruiser VXR 3.5TT HEV — GCC Brand New	Brand new 2026 LC VXR Hybrid, 3.5TT. GCC spec, Al Futtaim warranty. JAFZA delivery. RoRo export ready.	\N	\N	\N	\N	2800	245	\N	2026-07-04 23:34:43.795	2026-07-01 23:34:43.819	5	\N	GCC	AED	0
3cd9030e-2276-47e9-a76d-c7aabc763db7	dealer-dubai-003	\N	Toyota	Land Cruiser	2024	\N	VXR V8 5.7	SUV	petrol	automatic	5.7L V8 381hp	\N	\N	\N	\N	18000	White Pearl	Beige	\N	\N	{}	{}	298000.00	\N	310000.00	t	reserved	t	2024 Toyota Land Cruiser VXR V8 — 18k km GCC	VXR V8 2024, 18,000 km, GCC spec, full options, 3-year warranty remaining. Export eligible.	\N	\N	\N	\N	1890	167	\N	2026-07-04 23:34:43.81	2026-07-04 23:34:43.81	1	\N	GCC	AED	0
e89b8d96-69c8-465b-b186-8c9d5d3786d3	dealer-dubai-003	\N	Toyota	RAV4	2023	\N	Adventure AWD	SUV	petrol	automatic	2.5L 203hp	\N	\N	\N	\N	22000	Army Green	Black	\N	\N	{}	{}	125000.00	\N	118000.00	t	available	f	2023 Toyota RAV4 Adventure AWD — 22k km	RAV4 Adventure 2023, AWD, 22,000 km. Off-road spec, 18" alloys. Single owner.	\N	\N	\N	\N	766	56	\N	2026-07-04 23:34:43.81	2026-07-04 23:58:18.21	1	\N	GCC	AED	0
\.


--
-- Name: AffiliatePayment AffiliatePayment_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."AffiliatePayment"
    ADD CONSTRAINT "AffiliatePayment_pkey" PRIMARY KEY (id);


--
-- Name: CrmActivity CrmActivity_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."CrmActivity"
    ADD CONSTRAINT "CrmActivity_pkey" PRIMARY KEY (id);


--
-- Name: CrmContact CrmContact_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."CrmContact"
    ADD CONSTRAINT "CrmContact_pkey" PRIMARY KEY (id);


--
-- Name: CrmDeal CrmDeal_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."CrmDeal"
    ADD CONSTRAINT "CrmDeal_pkey" PRIMARY KEY (id);


--
-- Name: EmailCampaign EmailCampaign_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."EmailCampaign"
    ADD CONSTRAINT "EmailCampaign_pkey" PRIMARY KEY (id);


--
-- Name: EmailLink EmailLink_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."EmailLink"
    ADD CONSTRAINT "EmailLink_pkey" PRIMARY KEY (id);


--
-- Name: EmailSend EmailSend_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."EmailSend"
    ADD CONSTRAINT "EmailSend_pkey" PRIMARY KEY (id);


--
-- Name: EmailTemplate EmailTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."EmailTemplate"
    ADD CONSTRAINT "EmailTemplate_pkey" PRIMARY KEY (id);


--
-- Name: EmailUnsubscribe EmailUnsubscribe_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."EmailUnsubscribe"
    ADD CONSTRAINT "EmailUnsubscribe_pkey" PRIMARY KEY (id);


--
-- Name: ExecMeeting ExecMeeting_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."ExecMeeting"
    ADD CONSTRAINT "ExecMeeting_pkey" PRIMARY KEY (id);


--
-- Name: ExecTask ExecTask_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."ExecTask"
    ADD CONSTRAINT "ExecTask_pkey" PRIMARY KEY (id);


--
-- Name: KpiSnapshot KpiSnapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."KpiSnapshot"
    ADD CONSTRAINT "KpiSnapshot_pkey" PRIMARY KEY (id);


--
-- Name: MarketingSpend MarketingSpend_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."MarketingSpend"
    ADD CONSTRAINT "MarketingSpend_pkey" PRIMARY KEY (id);


--
-- Name: PushCampaign PushCampaign_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."PushCampaign"
    ADD CONSTRAINT "PushCampaign_pkey" PRIMARY KEY (id);


--
-- Name: PushSend PushSend_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."PushSend"
    ADD CONSTRAINT "PushSend_pkey" PRIMARY KEY (id);


--
-- Name: active_sessions active_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.active_sessions
    ADD CONSTRAINT active_sessions_pkey PRIMARY KEY (id);


--
-- Name: active_sessions active_sessions_session_token_key; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.active_sessions
    ADD CONSTRAINT active_sessions_session_token_key UNIQUE (session_token);


--
-- Name: ai_credits ai_credits_dealer_id_key; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.ai_credits
    ADD CONSTRAINT ai_credits_dealer_id_key UNIQUE (dealer_id);


--
-- Name: ai_credits ai_credits_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.ai_credits
    ADD CONSTRAINT ai_credits_pkey PRIMARY KEY (id);


--
-- Name: alert_notifications alert_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.alert_notifications
    ADD CONSTRAINT alert_notifications_pkey PRIMARY KEY (id);


--
-- Name: alert_subscriptions alert_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.alert_subscriptions
    ADD CONSTRAINT alert_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: broker_deals broker_deals_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.broker_deals
    ADD CONSTRAINT broker_deals_pkey PRIMARY KEY (id);


--
-- Name: broker_referrals broker_referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.broker_referrals
    ADD CONSTRAINT broker_referrals_pkey PRIMARY KEY (id);


--
-- Name: brokers brokers_affiliate_code_key; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.brokers
    ADD CONSTRAINT brokers_affiliate_code_key UNIQUE (affiliate_code);


--
-- Name: brokers brokers_email_key; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.brokers
    ADD CONSTRAINT brokers_email_key UNIQUE (email);


--
-- Name: brokers brokers_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.brokers
    ADD CONSTRAINT brokers_pkey PRIMARY KEY (id);


--
-- Name: collaboration_messages collaboration_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.collaboration_messages
    ADD CONSTRAINT collaboration_messages_pkey PRIMARY KEY (id);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: dealer_group_members dealer_group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.dealer_group_members
    ADD CONSTRAINT dealer_group_members_pkey PRIMARY KEY (group_id, dealer_id);


--
-- Name: dealer_groups dealer_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.dealer_groups
    ADD CONSTRAINT dealer_groups_pkey PRIMARY KEY (id);


--
-- Name: dealer_reports dealer_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.dealer_reports
    ADD CONSTRAINT dealer_reports_pkey PRIMARY KEY (id);


--
-- Name: dealer_reviews dealer_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.dealer_reviews
    ADD CONSTRAINT dealer_reviews_pkey PRIMARY KEY (id);


--
-- Name: dealer_subscriptions dealer_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.dealer_subscriptions
    ADD CONSTRAINT dealer_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: dealers dealers_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.dealers
    ADD CONSTRAINT dealers_pkey PRIMARY KEY (id);


--
-- Name: dealers dealers_slug_key; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.dealers
    ADD CONSTRAINT dealers_slug_key UNIQUE (slug);


--
-- Name: favorites favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_pkey PRIMARY KEY (user_id, vehicle_id);


--
-- Name: feature_flag_logs feature_flag_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.feature_flag_logs
    ADD CONSTRAINT feature_flag_logs_pkey PRIMARY KEY (id);


--
-- Name: feature_flags feature_flags_key_key; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_key_key UNIQUE (key);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (id);


--
-- Name: free_zones free_zones_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.free_zones
    ADD CONSTRAINT free_zones_pkey PRIMARY KEY (id);


--
-- Name: invoice_line_items invoice_line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.invoice_line_items
    ADD CONSTRAINT invoice_line_items_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: lead_activities lead_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.lead_activities
    ADD CONSTRAINT lead_activities_pkey PRIMARY KEY (id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: market_analysis_config market_analysis_config_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.market_analysis_config
    ADD CONSTRAINT market_analysis_config_pkey PRIMARY KEY (id);


--
-- Name: market_analysis_runs market_analysis_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.market_analysis_runs
    ADD CONSTRAINT market_analysis_runs_pkey PRIMARY KEY (id);


--
-- Name: market_competitor_data market_competitor_data_make_model_year_source_key; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.market_competitor_data
    ADD CONSTRAINT market_competitor_data_make_model_year_source_key UNIQUE (make, model, year, source);


--
-- Name: market_competitor_data market_competitor_data_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.market_competitor_data
    ADD CONSTRAINT market_competitor_data_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: plan_features plan_features_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.plan_features
    ADD CONSTRAINT plan_features_pkey PRIMARY KEY (id);


--
-- Name: plan_features plan_features_plan_id_feature_id_key; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.plan_features
    ADD CONSTRAINT plan_features_plan_id_feature_id_key UNIQUE (plan_id, feature_id);


--
-- Name: plan_limits plan_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.plan_limits
    ADD CONSTRAINT plan_limits_pkey PRIMARY KEY (id);


--
-- Name: plan_limits plan_limits_plan_id_limit_key_key; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.plan_limits
    ADD CONSTRAINT plan_limits_plan_id_limit_key_key UNIQUE (plan_id, limit_key);


--
-- Name: price_history price_history_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_pkey PRIMARY KEY (id);


--
-- Name: promotions promotions_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.promotions
    ADD CONSTRAINT promotions_pkey PRIMARY KEY (id);


--
-- Name: quote_line_items quote_line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.quote_line_items
    ADD CONSTRAINT quote_line_items_pkey PRIMARY KEY (id);


--
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- Name: scan_events scan_events_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.scan_events
    ADD CONSTRAINT scan_events_pkey PRIMARY KEY (id);


--
-- Name: share_permissions share_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.share_permissions
    ADD CONSTRAINT share_permissions_pkey PRIMARY KEY (id);


--
-- Name: stock_transactions stock_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.stock_transactions
    ADD CONSTRAINT stock_transactions_pkey PRIMARY KEY (id);


--
-- Name: subscription_coupons subscription_coupons_code_key; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.subscription_coupons
    ADD CONSTRAINT subscription_coupons_code_key UNIQUE (code);


--
-- Name: subscription_coupons subscription_coupons_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.subscription_coupons
    ADD CONSTRAINT subscription_coupons_pkey PRIMARY KEY (id);


--
-- Name: subscription_features subscription_features_key_key; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.subscription_features
    ADD CONSTRAINT subscription_features_key_key UNIQUE (key);


--
-- Name: subscription_features subscription_features_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.subscription_features
    ADD CONSTRAINT subscription_features_pkey PRIMARY KEY (id);


--
-- Name: subscription_history subscription_history_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.subscription_history
    ADD CONSTRAINT subscription_history_pkey PRIMARY KEY (id);


--
-- Name: subscription_invoices subscription_invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.subscription_invoices
    ADD CONSTRAINT subscription_invoices_invoice_number_key UNIQUE (invoice_number);


--
-- Name: subscription_invoices subscription_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.subscription_invoices
    ADD CONSTRAINT subscription_invoices_pkey PRIMARY KEY (id);


--
-- Name: subscription_payments subscription_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT subscription_payments_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_slug_key; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_slug_key UNIQUE (slug);


--
-- Name: subscription_usage subscription_usage_dealer_id_usage_key_period_year_period_m_key; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.subscription_usage
    ADD CONSTRAINT subscription_usage_dealer_id_usage_key_period_year_period_m_key UNIQUE (dealer_id, usage_key, period_year, period_month);


--
-- Name: subscription_usage subscription_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.subscription_usage
    ADD CONSTRAINT subscription_usage_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: valuation_config valuation_config_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.valuation_config
    ADD CONSTRAINT valuation_config_pkey PRIMARY KEY (id);


--
-- Name: vehicle_images vehicle_images_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.vehicle_images
    ADD CONSTRAINT vehicle_images_pkey PRIMARY KEY (id);


--
-- Name: vehicle_qr_codes vehicle_qr_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.vehicle_qr_codes
    ADD CONSTRAINT vehicle_qr_codes_pkey PRIMARY KEY (id);


--
-- Name: vehicle_qr_codes vehicle_qr_codes_qr_token_key; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.vehicle_qr_codes
    ADD CONSTRAINT vehicle_qr_codes_qr_token_key UNIQUE (qr_token);


--
-- Name: vehicle_qr_codes vehicle_qr_codes_vehicle_id_key; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.vehicle_qr_codes
    ADD CONSTRAINT vehicle_qr_codes_vehicle_id_key UNIQUE (vehicle_id);


--
-- Name: vehicle_reservations vehicle_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.vehicle_reservations
    ADD CONSTRAINT vehicle_reservations_pkey PRIMARY KEY (id);


--
-- Name: vehicle_shares vehicle_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.vehicle_shares
    ADD CONSTRAINT vehicle_shares_pkey PRIMARY KEY (id);


--
-- Name: vehicle_timeline vehicle_timeline_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.vehicle_timeline
    ADD CONSTRAINT vehicle_timeline_pkey PRIMARY KEY (id);


--
-- Name: vehicle_valuations vehicle_valuations_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.vehicle_valuations
    ADD CONSTRAINT vehicle_valuations_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (id);


--
-- Name: EmailSend_tracking_id_key; Type: INDEX; Schema: public; Owner: dubaiauto
--

CREATE UNIQUE INDEX "EmailSend_tracking_id_key" ON public."EmailSend" USING btree (tracking_id);


--
-- Name: EmailUnsubscribe_email_key; Type: INDEX; Schema: public; Owner: dubaiauto
--

CREATE UNIQUE INDEX "EmailUnsubscribe_email_key" ON public."EmailUnsubscribe" USING btree (email);


--
-- Name: KpiSnapshot_date_key; Type: INDEX; Schema: public; Owner: dubaiauto
--

CREATE UNIQUE INDEX "KpiSnapshot_date_key" ON public."KpiSnapshot" USING btree (date);


--
-- Name: MarketingSpend_month_channel_key; Type: INDEX; Schema: public; Owner: dubaiauto
--

CREATE UNIQUE INDEX "MarketingSpend_month_channel_key" ON public."MarketingSpend" USING btree (month, channel);


--
-- Name: active_sessions_profile_type_last_seen_at_idx; Type: INDEX; Schema: public; Owner: dubaiauto
--

CREATE INDEX active_sessions_profile_type_last_seen_at_idx ON public.active_sessions USING btree (profile_type, last_seen_at);


--
-- Name: brokers_country_id_idx; Type: INDEX; Schema: public; Owner: dubaiauto
--

CREATE INDEX brokers_country_id_idx ON public.brokers USING btree (country_id);


--
-- Name: countries_code_key; Type: INDEX; Schema: public; Owner: dubaiauto
--

CREATE UNIQUE INDEX countries_code_key ON public.countries USING btree (code);


--
-- Name: dealers_country_id_idx; Type: INDEX; Schema: public; Owner: dubaiauto
--

CREATE INDEX dealers_country_id_idx ON public.dealers USING btree (country_id);


--
-- Name: dealers_free_zone_id_idx; Type: INDEX; Schema: public; Owner: dubaiauto
--

CREATE INDEX dealers_free_zone_id_idx ON public.dealers USING btree (free_zone_id);


--
-- Name: free_zones_country_id_code_key; Type: INDEX; Schema: public; Owner: dubaiauto
--

CREATE UNIQUE INDEX free_zones_country_id_code_key ON public.free_zones USING btree (country_id, code);


--
-- Name: idx_market_competitor_expiry; Type: INDEX; Schema: public; Owner: dubaiauto
--

CREATE INDEX idx_market_competitor_expiry ON public.market_competitor_data USING btree (expires_at) WHERE (is_active = true);


--
-- Name: idx_reservations_expiry; Type: INDEX; Schema: public; Owner: dubaiauto
--

CREATE INDEX idx_reservations_expiry ON public.vehicle_reservations USING btree (expires_at) WHERE (status = 'active'::text);


--
-- Name: idx_vehicles_vin; Type: INDEX; Schema: public; Owner: dubaiauto
--

CREATE INDEX idx_vehicles_vin ON public.vehicles USING btree (vin) WHERE (vin IS NOT NULL);


--
-- Name: invoices_invoice_number_key; Type: INDEX; Schema: public; Owner: dubaiauto
--

CREATE UNIQUE INDEX invoices_invoice_number_key ON public.invoices USING btree (invoice_number);


--
-- Name: invoices_quote_id_key; Type: INDEX; Schema: public; Owner: dubaiauto
--

CREATE UNIQUE INDEX invoices_quote_id_key ON public.invoices USING btree (quote_id);


--
-- Name: notifications_broker_id_read_at_idx; Type: INDEX; Schema: public; Owner: dubaiauto
--

CREATE INDEX notifications_broker_id_read_at_idx ON public.notifications USING btree (broker_id, read_at);


--
-- Name: notifications_dealer_id_read_at_idx; Type: INDEX; Schema: public; Owner: dubaiauto
--

CREATE INDEX notifications_dealer_id_read_at_idx ON public.notifications USING btree (dealer_id, read_at);


--
-- Name: quotes_quote_number_key; Type: INDEX; Schema: public; Owner: dubaiauto
--

CREATE UNIQUE INDEX quotes_quote_number_key ON public.quotes USING btree (quote_number);


--
-- Name: share_permissions_share_id_dealer_id_key; Type: INDEX; Schema: public; Owner: dubaiauto
--

CREATE UNIQUE INDEX share_permissions_share_id_dealer_id_key ON public.share_permissions USING btree (share_id, dealer_id);


--
-- Name: AffiliatePayment AffiliatePayment_broker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."AffiliatePayment"
    ADD CONSTRAINT "AffiliatePayment_broker_id_fkey" FOREIGN KEY (broker_id) REFERENCES public.brokers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CrmActivity CrmActivity_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."CrmActivity"
    ADD CONSTRAINT "CrmActivity_contact_id_fkey" FOREIGN KEY (contact_id) REFERENCES public."CrmContact"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CrmDeal CrmDeal_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."CrmDeal"
    ADD CONSTRAINT "CrmDeal_contact_id_fkey" FOREIGN KEY (contact_id) REFERENCES public."CrmContact"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EmailSend EmailSend_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."EmailSend"
    ADD CONSTRAINT "EmailSend_campaign_id_fkey" FOREIGN KEY (campaign_id) REFERENCES public."EmailCampaign"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PushSend PushSend_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public."PushSend"
    ADD CONSTRAINT "PushSend_campaign_id_fkey" FOREIGN KEY (campaign_id) REFERENCES public."PushCampaign"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: alert_notifications alert_notifications_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.alert_notifications
    ADD CONSTRAINT alert_notifications_alert_id_fkey FOREIGN KEY (alert_id) REFERENCES public.alert_subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: broker_deals broker_deals_broker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.broker_deals
    ADD CONSTRAINT broker_deals_broker_id_fkey FOREIGN KEY (broker_id) REFERENCES public.brokers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: broker_deals broker_deals_dealer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.broker_deals
    ADD CONSTRAINT broker_deals_dealer_id_fkey FOREIGN KEY (dealer_id) REFERENCES public.dealers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: broker_referrals broker_referrals_broker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.broker_referrals
    ADD CONSTRAINT broker_referrals_broker_id_fkey FOREIGN KEY (broker_id) REFERENCES public.brokers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: brokers brokers_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.brokers
    ADD CONSTRAINT brokers_country_id_fkey FOREIGN KEY (country_id) REFERENCES public.countries(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: collaboration_messages collaboration_messages_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.collaboration_messages
    ADD CONSTRAINT collaboration_messages_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dealer_group_members dealer_group_members_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.dealer_group_members
    ADD CONSTRAINT dealer_group_members_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.dealer_groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dealer_reports dealer_reports_dealer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.dealer_reports
    ADD CONSTRAINT dealer_reports_dealer_id_fkey FOREIGN KEY (dealer_id) REFERENCES public.dealers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dealer_reviews dealer_reviews_dealer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.dealer_reviews
    ADD CONSTRAINT dealer_reviews_dealer_id_fkey FOREIGN KEY (dealer_id) REFERENCES public.dealers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dealer_reviews dealer_reviews_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.dealer_reviews
    ADD CONSTRAINT dealer_reviews_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dealer_subscriptions dealer_subscriptions_dealer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.dealer_subscriptions
    ADD CONSTRAINT dealer_subscriptions_dealer_id_fkey FOREIGN KEY (dealer_id) REFERENCES public.dealers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dealer_subscriptions dealer_subscriptions_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.dealer_subscriptions
    ADD CONSTRAINT dealer_subscriptions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: dealers dealers_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.dealers
    ADD CONSTRAINT dealers_country_id_fkey FOREIGN KEY (country_id) REFERENCES public.countries(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dealers dealers_free_zone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.dealers
    ADD CONSTRAINT dealers_free_zone_id_fkey FOREIGN KEY (free_zone_id) REFERENCES public.free_zones(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dealers dealers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.dealers
    ADD CONSTRAINT dealers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: favorites favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: favorites favorites_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: feature_flag_logs feature_flag_logs_flag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.feature_flag_logs
    ADD CONSTRAINT feature_flag_logs_flag_id_fkey FOREIGN KEY (flag_id) REFERENCES public.feature_flags(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: free_zones free_zones_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.free_zones
    ADD CONSTRAINT free_zones_country_id_fkey FOREIGN KEY (country_id) REFERENCES public.countries(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoice_line_items invoice_line_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.invoice_line_items
    ADD CONSTRAINT invoice_line_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoices invoices_dealer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_dealer_id_fkey FOREIGN KEY (dealer_id) REFERENCES public.dealers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoices invoices_quote_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_quote_id_fkey FOREIGN KEY (quote_id) REFERENCES public.quotes(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: lead_activities lead_activities_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.lead_activities
    ADD CONSTRAINT lead_activities_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: lead_activities lead_activities_lead_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.lead_activities
    ADD CONSTRAINT lead_activities_lead_id_fkey FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: leads leads_dealer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_dealer_id_fkey FOREIGN KEY (dealer_id) REFERENCES public.dealers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: leads leads_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: notifications notifications_broker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_broker_id_fkey FOREIGN KEY (broker_id) REFERENCES public.brokers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_dealer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_dealer_id_fkey FOREIGN KEY (dealer_id) REFERENCES public.dealers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: plan_features plan_features_feature_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.plan_features
    ADD CONSTRAINT plan_features_feature_id_fkey FOREIGN KEY (feature_id) REFERENCES public.subscription_features(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: plan_features plan_features_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.plan_features
    ADD CONSTRAINT plan_features_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: plan_limits plan_limits_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.plan_limits
    ADD CONSTRAINT plan_limits_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: price_history price_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: price_history price_history_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: promotions promotions_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.promotions
    ADD CONSTRAINT promotions_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: quote_line_items quote_line_items_quote_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.quote_line_items
    ADD CONSTRAINT quote_line_items_quote_id_fkey FOREIGN KEY (quote_id) REFERENCES public.quotes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: quotes quotes_dealer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_dealer_id_fkey FOREIGN KEY (dealer_id) REFERENCES public.dealers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: quotes quotes_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: share_permissions share_permissions_dealer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.share_permissions
    ADD CONSTRAINT share_permissions_dealer_id_fkey FOREIGN KEY (dealer_id) REFERENCES public.dealers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: share_permissions share_permissions_share_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.share_permissions
    ADD CONSTRAINT share_permissions_share_id_fkey FOREIGN KEY (share_id) REFERENCES public.vehicle_shares(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_transactions stock_transactions_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.stock_transactions
    ADD CONSTRAINT stock_transactions_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subscription_history subscription_history_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.subscription_history
    ADD CONSTRAINT subscription_history_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.dealer_subscriptions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: subscription_invoices subscription_invoices_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.subscription_invoices
    ADD CONSTRAINT subscription_invoices_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.dealer_subscriptions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: subscription_payments subscription_payments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT subscription_payments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.subscription_invoices(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vehicle_images vehicle_images_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.vehicle_images
    ADD CONSTRAINT vehicle_images_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicle_qr_codes vehicle_qr_codes_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.vehicle_qr_codes
    ADD CONSTRAINT vehicle_qr_codes_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicle_reservations vehicle_reservations_broker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.vehicle_reservations
    ADD CONSTRAINT vehicle_reservations_broker_id_fkey FOREIGN KEY (broker_id) REFERENCES public.brokers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: vehicle_reservations vehicle_reservations_dealer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.vehicle_reservations
    ADD CONSTRAINT vehicle_reservations_dealer_id_fkey FOREIGN KEY (dealer_id) REFERENCES public.dealers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicle_reservations vehicle_reservations_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.vehicle_reservations
    ADD CONSTRAINT vehicle_reservations_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicle_shares vehicle_shares_owner_dealer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.vehicle_shares
    ADD CONSTRAINT vehicle_shares_owner_dealer_id_fkey FOREIGN KEY (owner_dealer_id) REFERENCES public.dealers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicle_shares vehicle_shares_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.vehicle_shares
    ADD CONSTRAINT vehicle_shares_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicle_timeline vehicle_timeline_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.vehicle_timeline
    ADD CONSTRAINT vehicle_timeline_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicle_valuations vehicle_valuations_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.vehicle_valuations
    ADD CONSTRAINT vehicle_valuations_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicles vehicles_dealer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dubaiauto
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_dealer_id_fkey FOREIGN KEY (dealer_id) REFERENCES public.dealers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict Kk8yphEyhgmKn5chdIRKGBttTXOmSWCVbTKIKnADYbv9zxnPhxZQAofttRBMVqt

